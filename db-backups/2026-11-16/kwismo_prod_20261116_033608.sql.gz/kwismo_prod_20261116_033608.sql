--
-- PostgreSQL database dump
--

\restrict he6fz7xJkMlEfySvhBIFTCjfJArhdizPo6kEW5tRdrcG4if0ltvuiaEkuKhN2sp

-- Dumped from database version 16.16
-- Dumped by pg_dump version 16.16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AccessRight; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AccessRight" (
    id text NOT NULL,
    "roleId" text NOT NULL,
    permission text NOT NULL,
    description text
);


ALTER TABLE public."AccessRight" OWNER TO postgres;

--
-- Name: AffiliationRule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AffiliationRule" (
    id text NOT NULL,
    "partnerId" text NOT NULL,
    "countryId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AffiliationRule" OWNER TO postgres;

--
-- Name: AffiliationRulePrefix; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AffiliationRulePrefix" (
    id text NOT NULL,
    "affiliationRuleId" text NOT NULL,
    prefixe text NOT NULL
);


ALTER TABLE public."AffiliationRulePrefix" OWNER TO postgres;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "userId" text,
    action text NOT NULL,
    cible text,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ip text
);


ALTER TABLE public."AuditLog" OWNER TO postgres;

--
-- Name: CompromiseIncident; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CompromiseIncident" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "userPhoneId" text NOT NULL,
    "dateDeclaration" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    statut text DEFAULT 'open'::text NOT NULL
);


ALTER TABLE public."CompromiseIncident" OWNER TO postgres;

--
-- Name: Contact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Contact" (
    id text NOT NULL,
    "userId" text NOT NULL,
    nom text NOT NULL,
    numero text NOT NULL,
    statut text,
    "numeroId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Contact" OWNER TO postgres;

--
-- Name: Country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Country" (
    id text NOT NULL,
    nom text NOT NULL,
    "codePays" text NOT NULL,
    "estParDefaut" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Country" OWNER TO postgres;

--
-- Name: Device; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Device" (
    id text NOT NULL,
    "userId" text NOT NULL,
    identifiant text NOT NULL,
    nom text NOT NULL,
    "datePremiereConnexion" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "dateDerniereConnexion" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Device" OWNER TO postgres;

--
-- Name: Feedback; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Feedback" (
    id text NOT NULL,
    "reportId" text,
    "userId" text NOT NULL,
    "typeRetour" text NOT NULL,
    contenu text NOT NULL,
    "dateCreation" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Feedback" OWNER TO postgres;

--
-- Name: Kpi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Kpi" (
    id text NOT NULL,
    "nomIndicateur" text NOT NULL,
    valeur double precision NOT NULL,
    periode text NOT NULL,
    portee text DEFAULT 'global'::text NOT NULL,
    "partnerId" text
);


ALTER TABLE public."Kpi" OWNER TO postgres;

--
-- Name: Notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    "userId" text NOT NULL,
    texte text NOT NULL,
    lu boolean DEFAULT false NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Notification" OWNER TO postgres;

--
-- Name: Numero; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Numero" (
    id text NOT NULL,
    valeur text NOT NULL,
    "scoreRisque" double precision DEFAULT 0 NOT NULL,
    statut text DEFAULT 'unknown'::text NOT NULL,
    "dateDerniereVerification" timestamp(3) without time zone,
    "countryId" text,
    "operatorId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Numero" OWNER TO postgres;

--
-- Name: Operator; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Operator" (
    id text NOT NULL,
    nom text NOT NULL,
    "countryId" text NOT NULL
);


ALTER TABLE public."Operator" OWNER TO postgres;

--
-- Name: OperatorPrefix; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OperatorPrefix" (
    id text NOT NULL,
    "operatorId" text NOT NULL,
    prefixe text NOT NULL
);


ALTER TABLE public."OperatorPrefix" OWNER TO postgres;

--
-- Name: OtpCode; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OtpCode" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "userPhoneId" text,
    code text NOT NULL,
    canal text NOT NULL,
    cible text NOT NULL,
    "dateExpiration" timestamp(3) without time zone NOT NULL,
    "estUtilise" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."OtpCode" OWNER TO postgres;

--
-- Name: Partner; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Partner" (
    id text NOT NULL,
    "nomEntreprise" text NOT NULL,
    "typePartenariat" text NOT NULL,
    "dateAdhesion" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Partner" OWNER TO postgres;

--
-- Name: PartnerRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PartnerRequest" (
    id text NOT NULL,
    "nomContact" text NOT NULL,
    email text NOT NULL,
    "nomEntreprise" text NOT NULL,
    "typePartenariat" text NOT NULL,
    telephone text NOT NULL,
    message text,
    statut text DEFAULT 'pending'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PartnerRequest" OWNER TO postgres;

--
-- Name: Report; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Report" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "numeroId" text NOT NULL,
    motif text NOT NULL,
    "dateSignalement" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    statut text DEFAULT 'pending'::text NOT NULL
);


ALTER TABLE public."Report" OWNER TO postgres;

--
-- Name: ReportCategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ReportCategory" (
    id text NOT NULL,
    "reportId" text NOT NULL,
    "scamCategoryId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ReportCategory" OWNER TO postgres;

--
-- Name: Role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Role" (
    id text NOT NULL,
    "nomRole" text NOT NULL,
    "partnerId" text
);


ALTER TABLE public."Role" OWNER TO postgres;

--
-- Name: ScamCategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ScamCategory" (
    id text NOT NULL,
    "nomCode" text NOT NULL,
    libelle text,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ScamCategory" OWNER TO postgres;

--
-- Name: Survey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Survey" (
    id text NOT NULL,
    question text NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    "dateCreation" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Survey" OWNER TO postgres;

--
-- Name: SurveyResponse; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SurveyResponse" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "surveyId" text NOT NULL,
    reponse text NOT NULL,
    "dateReponse" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."SurveyResponse" OWNER TO postgres;

--
-- Name: Transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Transaction" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "numeroId" text NOT NULL,
    "countryId" text,
    "operatorId" text,
    "ussdActionId" text,
    montant double precision NOT NULL,
    "dateTransaction" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    statut text DEFAULT 'prepared'::text NOT NULL,
    "niveauRisque" text,
    "codeUSSDGenere" text
);


ALTER TABLE public."Transaction" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    nom text NOT NULL,
    prenom text NOT NULL,
    email text NOT NULL,
    "motDePasse" text NOT NULL,
    "emailVerifie" boolean DEFAULT false NOT NULL,
    statut text DEFAULT 'active'::text NOT NULL,
    langue text DEFAULT 'fr'::text NOT NULL,
    photo_url text,
    "dateInscription" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "roleId" text NOT NULL,
    "partnerId" text
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: UserPhone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UserPhone" (
    id text NOT NULL,
    "userId" text NOT NULL,
    valeur text NOT NULL,
    "countryId" text NOT NULL,
    "operatorId" text,
    "numeroId" text,
    "estVerifie" boolean DEFAULT false NOT NULL,
    "dateVerification" timestamp(3) without time zone,
    "estCompromis" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."UserPhone" OWNER TO postgres;

--
-- Name: UssdAction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UssdAction" (
    id text NOT NULL,
    "operatorId" text NOT NULL,
    "nomAction" text NOT NULL,
    "codeUSSD" text NOT NULL,
    format text NOT NULL
);


ALTER TABLE public."UssdAction" OWNER TO postgres;

--
-- Name: WhatsAppAlert; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WhatsAppAlert" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "compromiseIncidentId" text,
    contenu text NOT NULL,
    "dateEnvoi" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    statut text DEFAULT 'sent'::text NOT NULL
);


ALTER TABLE public."WhatsAppAlert" OWNER TO postgres;

--
-- Name: WhatsAppAlertRecipient; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WhatsAppAlertRecipient" (
    id text NOT NULL,
    "whatsAppAlertId" text NOT NULL,
    "contactId" text NOT NULL,
    "statutAccuse" text
);


ALTER TABLE public."WhatsAppAlertRecipient" OWNER TO postgres;

--
-- Data for Name: AccessRight; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AccessRight" (id, "roleId", permission, description) FROM stdin;
cmsysu4ao00045wd7e9d7w3v0	cmsyju7ww0002icdy66jnbyqa	users:read	Consulter tous les utilisateurs
cmsysu4bb00065wd7kudem2pi	cmsyju7ww0002icdy66jnbyqa	users:write	Gerer les utilisateurs
cmsysu4br00085wd7gc1r7msf	cmsyju7ww0002icdy66jnbyqa	reports:read	Consulter les signalements
cmsysu4c6000a5wd736ati3jn	cmsyju7ww0002icdy66jnbyqa	reports:verify	Valider/Rejeter les signalements
cmsysu4cj000c5wd79dsantmc	cmsyju7ww0002icdy66jnbyqa	analytics:read	Acceder aux tableau de bord
cmsysu4cx000e5wd75sihfkj7	cmsyju7ww0002icdy66jnbyqa	system:configure	Configurer le systeme
cmsysu4dp000i5wd72z3s0ed4	cmsyju7wn0001icdyf9ktv70l	reports:read	Consulter les signalements Lies
cmsysu4e2000k5wd7jox1ioy4	cmsyju7wn0001icdyf9ktv70l	affiliation:manage	Gerer les regles d'affiliation
cmsysu4ef000m5wd7euz46sph	cmsyju7wa0000icdyjw9azk4t	reports:create	Creer des signalements
cmsysu4es000o5wd7ar6jw4n5	cmsyju7wa0000icdyjw9azk4t	phones:manage	Gerer ses numeros de telephone
cmsysu4f4000q5wd7e8lhk22x	cmsyju7wa0000icdyjw9azk4t	devices:manage	Gerer ses appareils
\.


--
-- Data for Name: AffiliationRule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AffiliationRule" (id, "partnerId", "countryId", "createdAt") FROM stdin;
\.


--
-- Data for Name: AffiliationRulePrefix; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AffiliationRulePrefix" (id, "affiliationRuleId", prefixe) FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AuditLog" (id, "userId", action, cible, date, ip) FROM stdin;
cmsyswx8u003so9qrv37ze2xo	cmsysr3lw0004shwvpep5rkzu	LOGIN_SUCCESS	auth/login	2026-08-18 15:12:10.83	127.0.0.1
cmsyswx9h003to9qr7wayd4yp	cmsysr3lw0004shwvpep5rkzu	REPORT_VERIFIED	reports/report-1	2026-08-18 15:12:10.853	127.0.0.1
cmszmcfze003fa683asezvxj1	\N	POST /auth/login	\N	2026-08-19 04:56:03.816	127.0.0.1
cmszmdjc1003ha683co4uw866	\N	POST /auth/login	\N	2026-08-19 04:56:54.815	127.0.0.1
cmszmdjev003ja683gaday33b	\N	POST /auth/login	\N	2026-08-19 04:56:54.917	127.0.0.1
cmszmht4z003la683rielp5p9	\N	POST /auth/login	\N	2026-08-19 05:00:14.145	127.0.0.1
cmszmht7n003na683vwscvayi	\N	POST /auth/login	\N	2026-08-19 05:00:14.241	127.0.0.1
cmszmhta5003pa683w7z2hq1e	\N	POST /auth/login	\N	2026-08-19 05:00:14.332	127.0.0.1
cmszmkw1i003ra6830ib5a92h	\N	POST /auth/login	\N	2026-08-19 05:02:37.877	127.0.0.1
cmszmkw4f003ta683bnyu76xy	\N	POST /auth/login	\N	2026-08-19 05:02:37.982	127.0.0.1
cmszmkw6x003va683x7zwa6ab	\N	POST /auth/login	\N	2026-08-19 05:02:38.072	127.0.0.1
cmszmlybg003xa6832urstcps	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 05:03:27.482	127.0.0.1
cmszmlye00041a6834gf9zky0	cmsyslwua0003vlwm8lrfk563	compromise_phone	cmsysvmv1003hytq2tnxjycxx	2026-08-19 05:03:27.575	\N
cmszmlye80043a6831pne5oqh	cmsyslwua0003vlwm8lrfk563	POST /users/me/phones/cmsysvmv1003hytq2tnxjycxx/compromise	\N	2026-08-19 05:03:27.582	127.0.0.1
cmszmtxmy0047a683vqb9ong3	\N	POST /auth/login	\N	2026-08-19 05:09:39.848	127.0.0.1
cmszmtxpq0049a6838jynjpiw	\N	POST /auth/login	\N	2026-08-19 05:09:39.948	127.0.0.1
cmszmtxsp004ba6831nary1m2	\N	POST /auth/login	\N	2026-08-19 05:09:40.055	127.0.0.1
cmszmu1q2004da683iodf2ljg	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 05:09:45.144	127.0.0.1
cmszmum7t004ha683bwtjpj88	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 05:10:11.703	127.0.0.1
cmszn0tht004ja683air60sbs	\N	POST /auth/login	\N	2026-08-19 05:15:01.072	127.0.0.1
cmszn0tkp004la683aecnba98	\N	POST /auth/login	\N	2026-08-19 05:15:01.176	127.0.0.1
cmszn0tni004na683l1dw1rh5	\N	POST /auth/login	\N	2026-08-19 05:15:01.277	127.0.0.1
cmszn1r9p004pa683p356jvb3	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 05:15:44.844	127.0.0.1
cmszn26vd004va683hnmmef4t	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 05:16:05.064	127.0.0.1
cmsznp0j9004xa683i3oajk25	\N	POST /auth/login	\N	2026-08-19 05:33:49.939	127.0.0.1
cmsznp0l7004za683ex5hshk8	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 05:33:50.009	127.0.0.1
cmsznpt1b0055a683f3x62loh	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 05:34:26.876	127.0.0.1
cmsznq6wn0059a6834t2u4av5	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 05:34:44.853	127.0.0.1
cmsznq6zj005ba683j06fh7gp	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 05:34:44.958	127.0.0.1
cmsznq72g005da683brquzfya	\N	POST /auth/login	\N	2026-08-19 05:34:45.062	127.0.0.1
cmsznq748005fa683r3o4ctx4	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 05:34:45.125	127.0.0.1
cmsznq770005ha68336sbg30v	\N	POST /auth/login	\N	2026-08-19 05:34:45.226	127.0.0.1
cmsznq7az005ja68301nbnm5d	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmsznpg720053a683y2yb6iaq	2026-08-19 05:34:45.37	\N
cmsznq7bu005pa6832ijbtf9t	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmsznpg720053a683y2yb6iaq/validate	\N	2026-08-19 05:34:45.4	127.0.0.1
cmsznr4x8005ra683xe5uiznn	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 05:35:28.938	127.0.0.1
cmsznu8zt003dyqsv6x8oy4i5	\N	POST /auth/login	\N	2026-08-19 05:37:54.184	127.0.0.1
cmsznu91g003fyqsvf0e14zjk	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 05:37:54.243	127.0.0.1
cmsznv1gy003nyqsv5dp47yhz	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 05:38:31.087	127.0.0.1
cmsznvfax003ryqsvdr25p6ym	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 05:38:49.015	127.0.0.1
cmsznvfdm003tyqsva60eg03e	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 05:38:49.112	127.0.0.1
cmsznvfgj003vyqsv56yy52wv	\N	POST /auth/login	\N	2026-08-19 05:38:49.217	127.0.0.1
cmsznvfi4003xyqsvx5l7jgdh	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 05:38:49.275	127.0.0.1
cmsznvfl3003zyqsvk8m5dgie	\N	POST /auth/login	\N	2026-08-19 05:38:49.381	127.0.0.1
cmsznvfp00041yqsvilo721xb	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmsznuomp003lyqsv2e3dywrz	2026-08-19 05:38:49.523	\N
cmsznvfpj0047yqsvv9z21pou	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmsznuomp003lyqsv2e3dywrz/validate	\N	2026-08-19 05:38:49.541	127.0.0.1
cmsznwd7t0049yqsvnihvrstr	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 05:39:32.967	127.0.0.1
cmszo5cak003d13adwnh8v0np	\N	POST /auth/login	\N	2026-08-19 05:46:31.674	127.0.0.1
cmszo5ccb003f13adr5mn85ss	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 05:46:31.737	127.0.0.1
cmszo6f8u003n13ad9sxuztw1	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 05:47:22.155	127.0.0.1
cmszo6y7x003r13adc3chdkii	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 05:47:46.747	127.0.0.1
cmszo6yak003t13adrchlivkr	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 05:47:46.843	127.0.0.1
cmszo6ydh003v13ad5f3ek131	\N	POST /auth/login	\N	2026-08-19 05:47:46.947	127.0.0.1
cmszo6yf2003x13advvg72knr	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 05:47:47.004	127.0.0.1
cmszo6yhz003z13ad7gg9dxc0	\N	POST /auth/login	\N	2026-08-19 05:47:47.11	127.0.0.1
cmszo6ylm004113adk85l8yas	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmszo62e5003l13adufbly1oz	2026-08-19 05:47:47.241	\N
cmszo6yma004713ad9hwh0n3p	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmszo62e5003l13adufbly1oz/validate	\N	2026-08-19 05:47:47.263	127.0.0.1
cmszo811j004913adbc8da10m	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 05:48:37.061	127.0.0.1
cmszob3z3003dw9rblmuetq33	\N	POST /auth/login	\N	2026-08-19 05:51:00.829	127.0.0.1
cmszob418003fw9rbvew8c3o7	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 05:51:00.906	127.0.0.1
cmszoc6ps003nw9rbp1xw7bwr	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 05:51:51.038	127.0.0.1
cmszocpob003rw9rb8qq7xh9z	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 05:52:15.608	127.0.0.1
cmszocpr2003tw9rbd8i3vbv1	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 05:52:15.707	127.0.0.1
cmszocptv003vw9rb2oefw67h	\N	POST /auth/login	\N	2026-08-19 05:52:15.809	127.0.0.1
cmszocpvv003xw9rb05fuz36b	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 05:52:15.88	127.0.0.1
cmszocq1p003zw9rbln7utcuz	\N	POST /auth/login	\N	2026-08-19 05:52:16.09	127.0.0.1
cmszocq5j0041w9rbntm57vmy	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmszobtvu003lw9rbxji3eltk	2026-08-19 05:52:16.229	\N
cmszocq640047w9rbwikch3re	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmszobtvu003lw9rbxji3eltk/validate	\N	2026-08-19 05:52:16.25	127.0.0.1
cmszodsni0049w9rbjlbas3uo	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 05:53:06.124	127.0.0.1
cmszopicj003dpn8cfsrqp8ca	\N	POST /auth/login	\N	2026-08-19 06:02:12.641	127.0.0.1
cmszopien003fpn8cv0ka062q	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 06:02:12.717	127.0.0.1
cmszopigp003jpn8cqo4np841	cmsyslwua0003vlwm8lrfk563	POST /users/me/phones	\N	2026-08-19 06:02:12.79	127.0.0.1
cmszoqlb1003ppn8cggb01te5	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 06:03:03.131	127.0.0.1
cmszor4c8003tpn8ceor9sfwf	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 06:03:27.798	127.0.0.1
cmszor4ek003vpn8cvm06m0yg	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 06:03:27.882	127.0.0.1
cmszor4h7003xpn8c6vfkispl	\N	POST /auth/login	\N	2026-08-19 06:03:27.978	127.0.0.1
cmszor4ir003zpn8ck2pljgcq	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 06:03:28.033	127.0.0.1
cmszor4lf0041pn8cawht2xcq	\N	POST /auth/login	\N	2026-08-19 06:03:28.128	127.0.0.1
cmszor4p70043pn8c5pnqayzi	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmszoq8f5003npn8c5um3epcg	2026-08-19 06:03:28.266	\N
cmszor4pr0049pn8c5sm5ermf	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmszoq8f5003npn8c5um3epcg/validate	\N	2026-08-19 06:03:28.285	127.0.0.1
cmszos76r004bpn8c0nmb8c0k	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 06:04:18.146	127.0.0.1
cmszox6as003d39b4yk46om94	\N	POST /auth/login	\N	2026-08-19 06:08:10.274	127.0.0.1
cmszox6cu003f39b4il3ewrea	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 06:08:10.348	127.0.0.1
cmszox6ec003j39b4t6wwdp8q	cmsyslwua0003vlwm8lrfk563	POST /users/me/phones	\N	2026-08-19 06:08:10.403	127.0.0.1
cmszoy9aj003p39b4efvq68nr	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 06:09:00.809	127.0.0.1
cmszoys9r003t39b4ja5q4rpi	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 06:09:25.405	127.0.0.1
cmszoysbt003v39b4csubqqhe	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 06:09:25.48	127.0.0.1
cmszoysej003x39b4zk5h7j4x	\N	POST /auth/login	\N	2026-08-19 06:09:25.577	127.0.0.1
cmszoysfu003z39b4nk66ksi1	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 06:09:25.624	127.0.0.1
cmszoysil004139b4i3ktky70	\N	POST /auth/login	\N	2026-08-19 06:09:25.723	127.0.0.1
cmszoysmi004339b4vi7as0rr	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmszoxwfc003n39b4l9ptgcbx	2026-08-19 06:09:25.865	\N
cmszoysmz004939b4se3wcjpo	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmszoxwfc003n39b4l9ptgcbx/validate	\N	2026-08-19 06:09:25.882	127.0.0.1
cmszozv46004b39b4bodw1k7z	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 06:10:15.747	127.0.0.1
cmszp3qyr003dwory930s6nbh	\N	POST /auth/login	\N	2026-08-19 06:13:16.993	127.0.0.1
cmszp3r0j003fwory3j6i79km	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 06:13:17.058	127.0.0.1
cmszp3r22003jworykppdqj2q	cmsyslwua0003vlwm8lrfk563	POST /users/me/phones	\N	2026-08-19 06:13:17.112	127.0.0.1
cmszp4txw003pworyryoi0e48	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 06:14:07.506	127.0.0.1
cmszp5cwa003tworyqg8iy1xw	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 06:14:32.072	127.0.0.1
cmszp5cz5003vworylu9i1bfu	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 06:14:32.176	127.0.0.1
cmszp5d27003xworyt1gb9ajn	\N	POST /auth/login	\N	2026-08-19 06:14:32.285	127.0.0.1
cmszp5d3u003zwory4gut0ewf	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 06:14:32.345	127.0.0.1
cmszp5d6g0041woryik0f4muo	\N	POST /auth/login	\N	2026-08-19 06:14:32.438	127.0.0.1
cmszp5db60043worypuyryd01	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmszp4h2a003nworyme0mst3x	2026-08-19 06:14:32.607	\N
cmszp5dbv0049woryoym5g5jw	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmszp4h2a003nworyme0mst3x/validate	\N	2026-08-19 06:14:32.633	127.0.0.1
cmszp6fsh004bworyqzn2tcz5	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 06:15:22.479	127.0.0.1
cmszpbctp003dl94ltbutibpt	\N	POST /auth/login	\N	2026-08-19 06:19:11.915	127.0.0.1
cmszpbcvk003fl94lllztd2kj	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 06:19:11.982	127.0.0.1
cmszpbcxm003jl94lcnqh9vb2	cmsyslwua0003vlwm8lrfk563	POST /users/me/phones	\N	2026-08-19 06:19:12.056	127.0.0.1
cmszpcfog003pl94l1xrv72ih	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 06:20:02.271	127.0.0.1
cmszpcyqd003tl94l6yjd66d5	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 06:20:26.963	127.0.0.1
cmszpcysw003vl94lag3rebtx	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 06:20:27.054	127.0.0.1
cmszpcyvt003xl94ldqif895a	\N	POST /auth/login	\N	2026-08-19 06:20:27.16	127.0.0.1
cmszpcyxi003zl94lsffscdeh	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 06:20:27.221	127.0.0.1
cmszpcz180041l94lvcemltpp	\N	POST /auth/login	\N	2026-08-19 06:20:27.353	127.0.0.1
cmszpcz790043l94l5vwjck1r	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmszpc2sw003nl94l4gjn4rnp	2026-08-19 06:20:27.57	\N
cmszpcz7y0049l94l0v9wy7xw	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmszpc2sw003nl94l4gjn4rnp/validate	\N	2026-08-19 06:20:27.596	127.0.0.1
cmszs7do2004bl94ltbkqj4f4	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 07:40:05.228	127.0.0.1
cmsztfytp004dl94lf7felyqp	\N	POST /auth/login	\N	2026-08-19 08:14:45.516	127.0.0.1
cmsztfyvd004fl94lf3v2b5jm	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 08:14:45.575	127.0.0.1
cmsztfyx1004jl94ljmxf55oo	cmsyslwua0003vlwm8lrfk563	POST /users/me/phones	\N	2026-08-19 08:14:45.635	127.0.0.1
cmszth2sx004pl94l3ta66s5j	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 08:15:37.327	127.0.0.1
cmszthlrl004tl94l2gypgwei	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 08:16:01.903	127.0.0.1
cmszthlu7004vl94l1a9y8zhm	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 08:16:01.996	127.0.0.1
cmszthlx7004xl94lrvf68nk2	\N	POST /auth/login	\N	2026-08-19 08:16:02.105	127.0.0.1
cmszthlym004zl94l6koo24u1	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 08:16:02.156	127.0.0.1
cmszthm1g0051l94lgzlk4rao	\N	POST /auth/login	\N	2026-08-19 08:16:02.258	127.0.0.1
cmszthm7f0053l94l9squx4le	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmsztgpxj004nl94l1wi4zms5	2026-08-19 08:16:02.471	\N
cmszthm880059l94l7ffv2usz	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmsztgpxj004nl94l1wi4zms5/validate	\N	2026-08-19 08:16:02.5	127.0.0.1
cmsztion2005bl94lla0h10ij	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 08:16:52.284	127.0.0.1
cmsztnh9o005dl94lip7al0iy	\N	POST /auth/login	\N	2026-08-19 08:20:36.01	127.0.0.1
cmsztnhbd005fl94l0vumjyfq	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 08:20:36.071	127.0.0.1
cmsztnhdc005jl94lnnndxcm6	cmsyslwua0003vlwm8lrfk563	POST /users/me/phones	\N	2026-08-19 08:20:36.141	127.0.0.1
cmsztok64005pl94l8t4ox38t	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 08:21:26.426	127.0.0.1
cmsztp36f005tl94llcygrxty	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 08:21:51.061	127.0.0.1
cmsztp3bm005zl94l3r7ukhgj	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 08:21:51.247	127.0.0.1
cmsztp3em0061l94lp9krarwr	\N	POST /auth/login	\N	2026-08-19 08:21:51.356	127.0.0.1
cmsztp3gb0063l94ll8agvr2k	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 08:21:51.417	127.0.0.1
cmsztp3jc0065l94lahbtf8jy	\N	POST /auth/login	\N	2026-08-19 08:21:51.526	127.0.0.1
cmsztp3ny0067l94ll5ol8v1l	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmszto7bz005nl94lr6k6ibl3	2026-08-19 08:21:51.692	\N
cmsztp3ok006dl94lubhdfyn6	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmszto7bz005nl94lr6k6ibl3/validate	\N	2026-08-19 08:21:51.714	127.0.0.1
cmsztq65b006fl94lfxrffg55	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 08:22:41.565	127.0.0.1
cmsztq67l006hl94l9tbsg6ni	cmsyslwua0003vlwm8lrfk563	DELETE /users/me/phones/cmsztnhcy005hl94l98u3eayx	\N	2026-08-19 08:22:41.647	127.0.0.1
cmsztr49j003doqoec4x8ddg1	\N	POST /auth/login	\N	2026-08-19 08:23:25.782	127.0.0.1
cmsztr4b9003foqoe7z3zvzgi	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 08:23:25.843	127.0.0.1
cmsztr4cw003joqoexsanqkry	cmsyslwua0003vlwm8lrfk563	POST /users/me/phones	\N	2026-08-19 08:23:25.902	127.0.0.1
cmszts778003poqoe2j3a9tlc	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 08:24:16.243	127.0.0.1
cmsztsq4v003toqoe251uvvhh	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 08:24:40.781	127.0.0.1
cmsztsq8s003zoqoe74n2dgli	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 08:24:40.922	127.0.0.1
cmsztsqbg0041oqoeqtp36u6f	\N	POST /auth/login	\N	2026-08-19 08:24:41.018	127.0.0.1
cmsztsqcx0043oqoeazdxhjc6	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 08:24:41.072	127.0.0.1
cmsztsqfh0045oqoe2k2alxtr	\N	POST /auth/login	\N	2026-08-19 08:24:41.163	127.0.0.1
cmsztsqjn0047oqoe9oohp0im	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmsztrubk003noqoetgu26t49	2026-08-19 08:24:41.314	\N
cmsztsqk8004doqoe15wzqnwp	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmsztrubk003noqoetgu26t49/validate	\N	2026-08-19 08:24:41.334	127.0.0.1
cmszttsz3004foqoex8zgm0ea	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 08:25:31.117	127.0.0.1
cmszttt0r004hoqoebdi9d61l	cmsyslwua0003vlwm8lrfk563	DELETE /users/me/phones/cmsztr4ck003hoqoettei3tfe	\N	2026-08-19 08:25:31.176	127.0.0.1
cmszxil1v004joqoejof1q7wj	\N	POST /auth/login	\N	2026-08-19 10:08:46.097	127.0.0.1
cmszxil3t004loqoepj0k2ed3	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 10:08:46.167	127.0.0.1
cmszxil5p004poqoerkczhocd	cmsyslwua0003vlwm8lrfk563	POST /users/me/phones	\N	2026-08-19 10:08:46.235	127.0.0.1
cmszxjntq004voqoe5kssidt2	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 10:09:36.348	127.0.0.1
cmszxk6sz004zoqoeal70bl3j	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 10:10:00.945	127.0.0.1
cmszxk6ya0057oqoe3g58awxd	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 10:10:01.135	127.0.0.1
cmszxk70u0059oqoed7frua01	\N	POST /auth/login	\N	2026-08-19 10:10:01.229	127.0.0.1
cmszxk72d005boqoe7ullow9u	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 10:10:01.283	127.0.0.1
cmszxk754005doqoeoaaxkcax	\N	POST /auth/login	\N	2026-08-19 10:10:01.382	127.0.0.1
cmszxk79l005foqoebfny70m3	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmszxjayd004toqoei8ohkd7w	2026-08-19 10:10:01.543	\N
cmszxk7a4005loqoex4yxk26m	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmszxjayd004toqoei8ohkd7w/validate	\N	2026-08-19 10:10:01.562	127.0.0.1
cmszxl9pe005noqoeab6l0n97	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 10:10:51.36	127.0.0.1
cmszxl9r9005poqoed0hhgqwa	cmsyslwua0003vlwm8lrfk563	DELETE /users/me/phones/cmszxil59004noqoensmsxpqs	\N	2026-08-19 10:10:51.427	127.0.0.1
cmszxm5z2003d5rn2nf0ylzmv	\N	POST /auth/login	\N	2026-08-19 10:11:33.18	127.0.0.1
cmszxm60s003f5rn2s4w8pr9u	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 10:11:33.242	127.0.0.1
cmszxm62j003j5rn2ozorzat1	cmsyslwua0003vlwm8lrfk563	POST /users/me/phones	\N	2026-08-19 10:11:33.305	127.0.0.1
cmszxn8xi003p5rn2v3wq354f	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 10:12:23.669	127.0.0.1
cmszxnrwz003t5rn2a0vp10b6	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 10:12:48.273	127.0.0.1
cmszxns24003z5rn2jn5q0qeh	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 10:12:48.458	127.0.0.1
cmszxns8800415rn2jutwv6xu	\N	POST /auth/login	\N	2026-08-19 10:12:48.678	127.0.0.1
cmszxns9n00435rn2p8i80afa	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 10:12:48.729	127.0.0.1
cmszxnsc400455rn2w3om76bc	\N	POST /auth/login	\N	2026-08-19 10:12:48.818	127.0.0.1
cmszxnsgb00475rn2kui6bqk2	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmszxmw2p003n5rn2dzby140i	2026-08-19 10:12:48.97	\N
cmszxnsgw004d5rn2prvo9pt2	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmszxmw2p003n5rn2dzby140i/validate	\N	2026-08-19 10:12:48.99	127.0.0.1
cmszxouue004f5rn2u1m8q46b	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 10:13:38.724	127.0.0.1
cmszxouvu004h5rn2n36n8ai6	cmsyslwua0003vlwm8lrfk563	DELETE /users/me/phones/cmszxm626003h5rn2uwlajxdu	\N	2026-08-19 10:13:38.776	127.0.0.1
cmszyb24w004j5rn2footx3bf	\N	POST /auth/login	\N	2026-08-19 10:30:54.605	127.0.0.1
cmszyb26h004l5rn2wyi9icba	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 10:30:54.663	127.0.0.1
cmszyb284004p5rn2ptk4enzr	cmsyslwua0003vlwm8lrfk563	POST /users/me/phones	\N	2026-08-19 10:30:54.721	127.0.0.1
cmszyc4pg004v5rn2a2cv25w0	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 10:31:44.594	127.0.0.1
cmszycno5004z5rn24vn6idwz	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 10:32:09.171	127.0.0.1
cmszycns700555rn2vjvzpc0o	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 10:32:09.317	127.0.0.1
cmszycnv400575rn2nx4rvn43	\N	POST /auth/login	\N	2026-08-19 10:32:09.422	127.0.0.1
cmszycnx100595rn2oerqutoc	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 10:32:09.491	127.0.0.1
cmszycnzv005b5rn2eg0hl958	\N	POST /auth/login	\N	2026-08-19 10:32:09.593	127.0.0.1
cmszyco45005d5rn24nzn91au	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmszybrvc004t5rn2rd2z4utj	2026-08-19 10:32:09.748	\N
cmszyco4o005j5rn2n2fvc4m0	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmszybrvc004t5rn2rd2z4utj/validate	\N	2026-08-19 10:32:09.767	127.0.0.1
cmszydqcf005l5rn20bqa26as	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 10:32:59.294	127.0.0.1
cmszydqdx005n5rn2egxs56h4	cmsyslwua0003vlwm8lrfk563	DELETE /users/me/phones/cmszyb27q004n5rn2e35q2fp8	\N	2026-08-19 10:32:59.347	127.0.0.1
cmszyl8i0003dwb2v4gh4dojt	\N	POST /auth/login	\N	2026-08-19 10:38:49.415	127.0.0.1
cmszyl8jr003fwb2v0jmnwz96	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 10:38:49.478	127.0.0.1
cmszyl8l9003jwb2vj6zamk2d	cmsyslwua0003vlwm8lrfk563	POST /users/me/phones	\N	2026-08-19 10:38:49.531	127.0.0.1
cmszymbe6003pwb2vyzzkcghs	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 10:39:39.819	127.0.0.1
cmszymub6003twb2vkumxozj0	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 10:40:04.336	127.0.0.1
cmszymudm003zwb2vxf9214sv	cmsyslwua0003vlwm8lrfk563	POST /whatsapp-alerts/broadcast	\N	2026-08-19 10:40:04.424	127.0.0.1
cmszymuer0041wb2v8d2gcf5q	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 10:40:04.465	127.0.0.1
cmszymuhj0043wb2vrb41zcgf	\N	POST /auth/login	\N	2026-08-19 10:40:04.566	127.0.0.1
cmszymujf0045wb2veffn79xt	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 10:40:04.632	127.0.0.1
cmszymum90047wb2vli2n2qzs	\N	POST /auth/login	\N	2026-08-19 10:40:04.735	127.0.0.1
cmszymuqg0049wb2vltdrbey7	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmszylyjo003nwb2vjfa8nmyt	2026-08-19 10:40:04.887	\N
cmszymuqz004fwb2vq3v7rb4u	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmszylyjo003nwb2vjfa8nmyt/validate	\N	2026-08-19 10:40:04.905	127.0.0.1
cmszynx56004hwb2vt149xbn0	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 10:40:54.664	127.0.0.1
cmszynx7e004jwb2vxxvrr012	cmsyslwua0003vlwm8lrfk563	DELETE /users/me/phones/cmszyl8kw003hwb2v6uywg0c1	\N	2026-08-19 10:40:54.743	127.0.0.1
cmszyu3hb004lwb2va4ubf09y	\N	POST /auth/login	\N	2026-08-19 10:45:42.813	127.0.0.1
cmszyu3iz004nwb2vqh9i0kmh	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-19 10:45:42.873	127.0.0.1
cmszyu3km004rwb2vaxlzg7ou	cmsyslwua0003vlwm8lrfk563	POST /users/me/phones	\N	2026-08-19 10:45:42.932	127.0.0.1
cmszyv67w004xwb2v48jprj5g	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-19 10:46:33.018	127.0.0.1
cmszyvp4s0051wb2vwohcviv8	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-19 10:46:57.53	127.0.0.1
cmszyvp7c0057wb2v03iy1kdk	cmsyslwua0003vlwm8lrfk563	POST /whatsapp-alerts/broadcast	\N	2026-08-19 10:46:57.622	127.0.0.1
cmszyvp8p0059wb2vmqe77jjx	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-19 10:46:57.672	127.0.0.1
cmszyvpbj005bwb2v0xdvor8j	\N	POST /auth/login	\N	2026-08-19 10:46:57.774	127.0.0.1
cmszyvpd6005dwb2vk8hvv9gk	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-19 10:46:57.832	127.0.0.1
cmszyvpg1005fwb2vmv2ev3uk	\N	POST /auth/login	\N	2026-08-19 10:46:57.935	127.0.0.1
cmszyvpkl005hwb2vcdy0xjw7	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmszyutei004vwb2vwgi5naq0	2026-08-19 10:46:58.099	\N
cmszyvpl7005nwb2vebe1gwyh	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmszyutei004vwb2vwgi5naq0/validate	\N	2026-08-19 10:46:58.121	127.0.0.1
cmszywrsy005pwb2vfuxc0ea5	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-19 10:47:47.649	127.0.0.1
cmszywruk005rwb2vw9vxk9to	cmsyslwua0003vlwm8lrfk563	DELETE /users/me/phones/cmszyu3k7004pwb2vs0df5b17	\N	2026-08-19 10:47:47.706	127.0.0.1
cmtcah98d005twb2vs062nqdl	\N	POST /auth/login	\N	2026-08-28 01:44:53.243	127.0.0.1
cmtcah99y005vwb2v6fw8xxte	cmsyslwua0003vlwm8lrfk563	PATCH /users/me	\N	2026-08-28 01:44:53.301	127.0.0.1
cmtcah9bm005zwb2v48ed2sl1	cmsyslwua0003vlwm8lrfk563	POST /users/me/phones	\N	2026-08-28 01:44:53.36	127.0.0.1
cmtcaibsq0065wb2ve532ee7z	cmsyslwua0003vlwm8lrfk563	POST /reports	\N	2026-08-28 01:45:43.223	127.0.0.1
cmtcaiuog0069wb2v3khfetoy	cmsyslwua0003vlwm8lrfk563	POST /transactions/prepare	\N	2026-08-28 01:46:07.694	127.0.0.1
cmtcaiur2006fwb2vmivh2avv	cmsyslwua0003vlwm8lrfk563	POST /whatsapp-alerts/broadcast	\N	2026-08-28 01:46:07.788	127.0.0.1
cmtcaiusc006hwb2vy8jtb26g	cmsyslwua0003vlwm8lrfk563	POST /auth/logout	\N	2026-08-28 01:46:07.835	127.0.0.1
cmtcaiuv4006jwb2vpdrblj6l	\N	POST /auth/login	\N	2026-08-28 01:46:07.935	127.0.0.1
cmtcaiuwr006lwb2vo3pul0ua	cmsysr3ck0003shwv6ahorru0	POST /auth/logout	\N	2026-08-28 01:46:07.994	127.0.0.1
cmtcaiuzm006nwb2v3ilwe2oy	\N	POST /auth/login	\N	2026-08-28 01:46:08.096	127.0.0.1
cmtcaiv3u006pwb2vukn886ai	cmsysr3lw0004shwvpep5rkzu	validate_report:validated	cmtcahyyv0063wb2v4klvvq8c	2026-08-28 01:46:08.249	\N
cmtcaiv4g006vwb2vgresl97f	cmsysr3lw0004shwvpep5rkzu	PATCH /reports/cmtcahyyv0063wb2v4klvvq8c/validate	\N	2026-08-28 01:46:08.27	127.0.0.1
cmtcajxhi006xwb2vmw4m2dka	cmsysr3lw0004shwvpep5rkzu	POST /auth/logout	\N	2026-08-28 01:46:57.987	127.0.0.1
cmtcajxj2006zwb2vz2suz69g	cmsyslwua0003vlwm8lrfk563	DELETE /users/me/phones/cmtcah9b9005xwb2v179alcck	\N	2026-08-28 01:46:58.044	127.0.0.1
\.


--
-- Data for Name: CompromiseIncident; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CompromiseIncident" (id, "userId", "userPhoneId", "dateDeclaration", statut) FROM stdin;
cmszmlyds003za68336wc76ya	cmsyslwua0003vlwm8lrfk563	cmsysvmv1003hytq2tnxjycxx	2026-08-19 05:03:27.569	open
\.


--
-- Data for Name: Contact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Contact" (id, "userId", nom, numero, statut, "numeroId", "createdAt", "updatedAt") FROM stdin;
cmsysw7fo003e7jjy4zwyuxi0	cmsyslwua0003vlwm8lrfk563	Maman	+237677889900	securise	cmsysvmsh003dytq2lj4qyoi0	2026-08-18 15:11:37.381	2026-08-19 05:15:44.966
cmsysw7g8003f7jjy88pmhzl4	cmsyslwua0003vlwm8lrfk563	Jean Paul	+237699001122	securise	cmsysvmta003eytq2vwri2ll5	2026-08-18 15:11:37.4	2026-08-18 15:11:37.4
cmszmlyfc0045a683igwjnz00	cmsyslwua0003vlwm8lrfk563	Contact Audit	+237677998811	\N	\N	2026-08-19 05:03:27.624	2026-08-19 05:03:27.624
cmszn1rc3004ra6831q3vykur	cmsyslwua0003vlwm8lrfk563	Contact Audit cmsy	+237677991122	\N	\N	2026-08-19 05:15:44.932	2026-08-19 05:15:44.932
cmsznp0ou0051a683r285cnc6	cmsyslwua0003vlwm8lrfk563	Contact Test	+237677983931	\N	\N	2026-08-19 05:33:50.143	2026-08-19 05:33:50.143
cmsznu94y003jyqsvta9t21eh	cmsyslwua0003vlwm8lrfk563	Contact Test	+237676381320	\N	\N	2026-08-19 05:37:54.371	2026-08-19 05:37:54.371
cmszo5cgo003j13adfektu91z	cmsyslwua0003vlwm8lrfk563	Contact Test	+237673317754	\N	\N	2026-08-19 05:46:31.897	2026-08-19 05:46:31.897
cmszob44m003jw9rbivsnxfp0	cmsyslwua0003vlwm8lrfk563	Contact Test	+237674615484	\N	\N	2026-08-19 05:51:01.03	2026-08-19 05:51:01.03
cmszopiij003lpn8c3cnws7xu	cmsyslwua0003vlwm8lrfk563	Contact Test	+237671538683	\N	\N	2026-08-19 06:02:12.859	2026-08-19 06:02:12.859
cmszox6fh003l39b4ju8qgqfs	cmsyslwua0003vlwm8lrfk563	Contact Test	+237674739826	\N	\N	2026-08-19 06:08:10.445	2026-08-19 06:08:10.445
cmszp3r3l003lwory7y7c1vq8	cmsyslwua0003vlwm8lrfk563	Contact Test	+237678872129	\N	\N	2026-08-19 06:13:17.169	2026-08-19 06:13:17.169
cmszpbcz6003ll94lkf5l0bo0	cmsyslwua0003vlwm8lrfk563	Contact Test	+237677534984	\N	\N	2026-08-19 06:19:12.114	2026-08-19 06:19:12.114
cmsztfyyh004ll94ltcibc1i9	cmsyslwua0003vlwm8lrfk563	Contact Test	+237671885597	\N	\N	2026-08-19 08:14:45.69	2026-08-19 08:14:45.69
cmsztnhex005ll94l8j3etjbb	cmsyslwua0003vlwm8lrfk563	Contact Test Auto	+237677606924	\N	\N	2026-08-19 08:20:36.202	2026-08-19 08:20:36.202
cmuapmflf0001iawthamneegp	cmu2ivveg0001z8ddgxkvkvbc	Brayan Weko	+237620132092	securise	\N	2026-09-21 03:52:58.989	2026-09-28 23:59:36.956
cmuapmfmm0003iawtcslric8m	cmu2ivveg0001z8ddgxkvkvbc	Menkeh Tingai	+15715309085	frauduleux	\N	2026-09-21 03:52:59.038	2026-09-28 23:59:36.872
cmuapmfnv0005iawthqa3panr	cmu2ivveg0001z8ddgxkvkvbc	Baby Boo 🧸❤️	+237679660706	\N	\N	2026-09-21 03:52:59.083	2026-09-28 23:27:55.282
cmuapmfou0007iawt7urcjj65	cmu2ivveg0001z8ddgxkvkvbc	Mr E. (SoftBytes)	+918872549959	\N	\N	2026-09-21 03:52:59.118	2026-09-21 03:52:59.118
cmuapmfpn0009iawtw6qbnp2c	cmu2ivveg0001z8ddgxkvkvbc	Rayane Moundi	+237694330243	\N	\N	2026-09-21 03:52:59.148	2026-09-21 03:52:59.148
cmuaykdqg000171kebm1arkxh	cmu2kzqeu00055t7mrgmescc1	+237 6 80 72 87 87	+237680728787	\N	\N	2026-09-21 08:03:19.811	2026-09-21 08:03:19.811
cmuaykdsw000371keiyqdm63l	cmu2kzqeu00055t7mrgmescc1	+23756943131	+23756943131	\N	\N	2026-09-21 08:03:19.904	2026-09-21 08:03:19.904
cmuaykduu000571ke0vlxhygy	cmu2kzqeu00055t7mrgmescc1	+237620756699	+237620756699	\N	\N	2026-09-21 08:03:19.975	2026-09-21 08:03:19.975
cmuaykdx2000771keszco4u9a	cmu2kzqeu00055t7mrgmescc1	+23756259645	+23756259645	\N	\N	2026-09-21 08:03:20.054	2026-09-21 08:03:20.054
cmuaykdz6000971kelfp4hf67	cmu2kzqeu00055t7mrgmescc1	+237620736094	+237620736094	\N	\N	2026-09-21 08:03:20.13	2026-09-21 08:03:20.13
cmuayke11000b71keb6s4ajrt	cmu2kzqeu00055t7mrgmescc1	+23756468786	+23756468786	\N	\N	2026-09-21 08:03:20.197	2026-09-21 08:03:20.197
cmuayke3p000d71keh5yupmzs	cmu2kzqeu00055t7mrgmescc1	+237620569855	+237620569855	\N	\N	2026-09-21 08:03:20.293	2026-09-21 08:03:20.293
cmuayke67000f71keel9sn221	cmu2kzqeu00055t7mrgmescc1	+23756203075	+23756203075	\N	\N	2026-09-21 08:03:20.383	2026-09-21 08:03:20.383
cmuayke88000h71keuiq8h9xw	cmu2kzqeu00055t7mrgmescc1	+23756111060	+23756111060	\N	\N	2026-09-21 08:03:20.457	2026-09-21 08:03:20.457
cmuaykea7000j71ke4puujijf	cmu2kzqeu00055t7mrgmescc1	+23755751719	+23755751719	\N	\N	2026-09-21 08:03:20.528	2026-09-21 08:03:20.528
cmuaykech000l71kehhxklbqz	cmu2kzqeu00055t7mrgmescc1	+237620976268	+237620976268	\N	\N	2026-09-21 08:03:20.609	2026-09-21 08:03:20.609
cmuaykeef000n71keqljmnkgi	cmu2kzqeu00055t7mrgmescc1	Youssef⚛️	+237620585494	\N	\N	2026-09-21 08:03:20.679	2026-09-21 16:28:15.425
cmuaykehc000p71keagh5r9v3	cmu2kzqeu00055t7mrgmescc1	+237621366512	+237621366512	\N	\N	2026-09-21 08:03:20.784	2026-09-21 08:03:20.784
cmuaykekm000r71kerflujb0t	cmu2kzqeu00055t7mrgmescc1	+237621780462	+237621780462	\N	\N	2026-09-21 08:03:20.902	2026-09-21 08:03:20.902
cmuaykerc000t71kee439nbm8	cmu2kzqeu00055t7mrgmescc1	+237620944366	+237620944366	\N	\N	2026-09-21 08:03:21.144	2026-09-21 08:03:21.144
cmuaykez2000v71ke3d9kcf7c	cmu2kzqeu00055t7mrgmescc1	+237640077627	+237640077627	\N	\N	2026-09-21 08:03:21.422	2026-09-21 08:03:21.422
cmuaykf6d000x71kecbgmzeaw	cmu2kzqeu00055t7mrgmescc1	+237621842892	+237621842892	\N	\N	2026-09-21 08:03:21.685	2026-09-21 08:03:21.685
cmuaykf9c000z71ked4lz1kkl	cmu2kzqeu00055t7mrgmescc1	+237640817162	+237640817162	\N	\N	2026-09-21 08:03:21.792	2026-09-21 08:03:21.792
cmuaykfc5001171kepiqgebuk	cmu2kzqeu00055t7mrgmescc1	+237650064362	+237650064362	\N	\N	2026-09-21 08:03:21.893	2026-09-21 08:03:21.893
cmuaykfh5001371keqj392ufp	cmu2kzqeu00055t7mrgmescc1	+237650083732	+237650083732	\N	\N	2026-09-21 08:03:22.073	2026-09-21 08:03:22.073
cmuaykfjp001571kesqgrjqve	cmu2kzqeu00055t7mrgmescc1	+237650066321	+237650066321	\N	\N	2026-09-21 08:03:22.165	2026-09-21 08:03:22.165
cmuaykfmn001771kepamgakon	cmu2kzqeu00055t7mrgmescc1	+237650222400	+237650222400	\N	\N	2026-09-21 08:03:22.271	2026-09-21 08:03:22.271
cmuaykg3s001971kefe0ouy95	cmu2kzqeu00055t7mrgmescc1	+237650395635	+237650395635	\N	\N	2026-09-21 08:03:22.888	2026-09-21 08:03:22.888
cmuaykg69001b71kedk0m7ro6	cmu2kzqeu00055t7mrgmescc1	+237650796468	+237650796468	\N	\N	2026-09-21 08:03:22.977	2026-09-21 08:03:22.977
cmuaykg8u001d71ke3zn7szuo	cmu2kzqeu00055t7mrgmescc1	+237654949097	+237654949097	\N	\N	2026-09-21 08:03:23.071	2026-09-21 08:03:23.071
cmuaykgb4001f71ke6f20pe3a	cmu2kzqeu00055t7mrgmescc1	+237653510706	+237653510706	\N	\N	2026-09-21 08:03:23.153	2026-09-21 08:03:23.153
cmuaykgd2001h71keil2smdsk	cmu2kzqeu00055t7mrgmescc1	+237654417413	+237654417413	\N	\N	2026-09-21 08:03:23.222	2026-09-21 08:03:23.222
cmuaykgmx001j71keivel0j6r	cmu2kzqeu00055t7mrgmescc1	+237655062075	+237655062075	\N	\N	2026-09-21 08:03:23.577	2026-09-21 08:03:23.577
cmuaykgq1001l71keugc526rj	cmu2kzqeu00055t7mrgmescc1	+237653712225	+237653712225	\N	\N	2026-09-21 08:03:23.689	2026-09-21 08:03:23.689
cmuaykgsa001n71kepmnx3959	cmu2kzqeu00055t7mrgmescc1	+237653234116	+237653234116	\N	\N	2026-09-21 08:03:23.77	2026-09-21 08:03:23.77
cmuaykgub001p71ke8i67jzy1	cmu2kzqeu00055t7mrgmescc1	+237653270018	+237653270018	\N	\N	2026-09-21 08:03:23.843	2026-09-21 08:03:23.843
cmuaykgw9001r71keu0fm6j0y	cmu2kzqeu00055t7mrgmescc1	+237653678149	+237653678149	\N	\N	2026-09-21 08:03:23.913	2026-09-21 08:03:23.913
cmuaykgxz001t71keasa59yr6	cmu2kzqeu00055t7mrgmescc1	+237654223622	+237654223622	\N	\N	2026-09-21 08:03:23.975	2026-09-21 08:03:23.975
cmuaykh0b001v71keez6bvgqb	cmu2kzqeu00055t7mrgmescc1	+237655098968	+237655098968	\N	\N	2026-09-21 08:03:24.059	2026-09-21 08:03:24.059
cmuaykh2h001x71kelkif1471	cmu2kzqeu00055t7mrgmescc1	Mounir Jw	+237654785608	\N	\N	2026-09-21 08:03:24.137	2026-09-21 16:27:56.481
cmuaykh4e001z71kewol0hyxf	cmu2kzqeu00055t7mrgmescc1	+237655171984	+237655171984	\N	\N	2026-09-21 08:03:24.207	2026-09-21 08:03:24.207
cmuaykh62002171kek0cjypu2	cmu2kzqeu00055t7mrgmescc1	+237652768071	+237652768071	\N	\N	2026-09-21 08:03:24.266	2026-09-21 08:03:24.266
cmuaykh7p002371kev4skezj9	cmu2kzqeu00055t7mrgmescc1	+237655024233	+237655024233	\N	\N	2026-09-21 08:03:24.325	2026-09-21 08:03:24.325
cmuaykh9s002571kew7d84rl1	cmu2kzqeu00055t7mrgmescc1	+237653911862	+237653911862	\N	\N	2026-09-21 08:03:24.4	2026-09-21 08:03:24.4
cmuaykhbr002771keg5hnscd6	cmu2kzqeu00055t7mrgmescc1	+237652685608	+237652685608	\N	\N	2026-09-21 08:03:24.471	2026-09-21 08:03:24.471
cmuaykhdk002971keq29kyhal	cmu2kzqeu00055t7mrgmescc1	+237654114628	+237654114628	\N	\N	2026-09-21 08:03:24.536	2026-09-21 08:03:24.536
cmuaykhfr002b71ke1zct0gia	cmu2kzqeu00055t7mrgmescc1	+237654987277	+237654987277	\N	\N	2026-09-21 08:03:24.615	2026-09-21 08:03:24.615
cmuaykhhs002d71ke7pojx144	cmu2kzqeu00055t7mrgmescc1	+237654379437	+237654379437	\N	\N	2026-09-21 08:03:24.688	2026-09-21 08:03:24.688
cmuaykhjj002f71ke7762jpkp	cmu2kzqeu00055t7mrgmescc1	+237655197866	+237655197866	\N	\N	2026-09-21 08:03:24.752	2026-09-21 08:03:24.752
cmuaykhlf002h71kesg9au82c	cmu2kzqeu00055t7mrgmescc1	+237655134249	+237655134249	\N	\N	2026-09-21 08:03:24.819	2026-09-21 08:03:24.819
cmuaykhna002j71kedg2wneh7	cmu2kzqeu00055t7mrgmescc1	+237654279234	+237654279234	\N	\N	2026-09-21 08:03:24.886	2026-09-21 08:03:24.886
cmuaykhp0002l71kecvoj5xkt	cmu2kzqeu00055t7mrgmescc1	+237653218064	+237653218064	\N	\N	2026-09-21 08:03:24.948	2026-09-21 08:03:24.948
cmuaykhqo002n71kesdj4v3gr	cmu2kzqeu00055t7mrgmescc1	+237655105119	+237655105119	\N	\N	2026-09-21 08:03:25.008	2026-09-21 08:03:25.008
cmuaykhsk002p71ke62bqeajs	cmu2kzqeu00055t7mrgmescc1	+237655140271	+237655140271	\N	\N	2026-09-21 08:03:25.076	2026-09-21 08:03:25.076
cmuaykhuc002r71kecglceslc	cmu2kzqeu00055t7mrgmescc1	+237655098331	+237655098331	\N	\N	2026-09-21 08:03:25.14	2026-09-21 08:03:25.14
cmuaykhw5002t71kemny5z39y	cmu2kzqeu00055t7mrgmescc1	+237655047266	+237655047266	\N	\N	2026-09-21 08:03:25.205	2026-09-21 08:03:25.205
cmuaykhy1002v71kex7p2s7w4	cmu2kzqeu00055t7mrgmescc1	+237652606188	+237652606188	\N	\N	2026-09-21 08:03:25.274	2026-09-21 08:03:25.274
cmuaykhzw002x71keajveqn2j	cmu2kzqeu00055t7mrgmescc1	+237655038373	+237655038373	\N	\N	2026-09-21 08:03:25.34	2026-09-21 08:03:25.34
cmuayki1r002z71keaymiexbl	cmu2kzqeu00055t7mrgmescc1	+237654436920	+237654436920	\N	\N	2026-09-21 08:03:25.407	2026-09-21 08:03:25.407
cmuayki3v003171kezgna14vv	cmu2kzqeu00055t7mrgmescc1	+237654232450	+237654232450	\N	\N	2026-09-21 08:03:25.483	2026-09-21 08:03:25.483
cmuayki5i003371kekzzjo5lc	cmu2kzqeu00055t7mrgmescc1	+237654238044	+237654238044	\N	\N	2026-09-21 08:03:25.542	2026-09-21 08:03:25.542
cmuayki7b003571keh2orafyc	cmu2kzqeu00055t7mrgmescc1	+237655251992	+237655251992	\N	\N	2026-09-21 08:03:25.607	2026-09-21 08:03:25.607
cmuayki92003771keau0531h6	cmu2kzqeu00055t7mrgmescc1	+237655314180	+237655314180	\N	\N	2026-09-21 08:03:25.67	2026-09-21 08:03:25.67
cmuaykiay003971ke4r924l93	cmu2kzqeu00055t7mrgmescc1	+237655247736	+237655247736	\N	\N	2026-09-21 08:03:25.738	2026-09-21 08:03:25.738
cmuaykico003b71kez00rvtvr	cmu2kzqeu00055t7mrgmescc1	+237655318631	+237655318631	\N	\N	2026-09-21 08:03:25.801	2026-09-21 08:03:25.801
cmuaykiej003d71ke826vmfsj	cmu2kzqeu00055t7mrgmescc1	+237655329686	+237655329686	\N	\N	2026-09-21 08:03:25.867	2026-09-21 08:03:25.867
cmuaykig6003f71kel81n832r	cmu2kzqeu00055t7mrgmescc1	+237655327441	+237655327441	\N	\N	2026-09-21 08:03:25.926	2026-09-21 08:03:25.926
cmuaykihx003h71kebv16x8io	cmu2kzqeu00055t7mrgmescc1	+237655371767	+237655371767	\N	\N	2026-09-21 08:03:25.99	2026-09-21 08:03:25.99
cmuaykijl003j71kezp1puyq1	cmu2kzqeu00055t7mrgmescc1	+237655436620	+237655436620	\N	\N	2026-09-21 08:03:26.049	2026-09-21 08:03:26.049
cmuaykitl003l71kexaysouly	cmu2kzqeu00055t7mrgmescc1	+237655464818	+237655464818	\N	\N	2026-09-21 08:03:26.409	2026-09-21 08:03:26.409
cmuaykj3p003n71ke8cvwdz53	cmu2kzqeu00055t7mrgmescc1	+237655478028	+237655478028	\N	\N	2026-09-21 08:03:26.773	2026-09-21 08:03:26.773
cmuaykj8k003p71kectewjfhw	cmu2kzqeu00055t7mrgmescc1	+237655463735	+237655463735	\N	\N	2026-09-21 08:03:26.948	2026-09-21 08:03:26.948
cmuaykjax003r71kezx71jyht	cmu2kzqeu00055t7mrgmescc1	C🧚‍♀️Y🧚‍♀️B🧚‍♀️E🧚‍♀️L🧚‍♀️L🧚‍♀️E	+237655507240	\N	\N	2026-09-21 08:03:27.033	2026-09-21 16:27:30.469
cmuaykjd2003t71keym4wt5ru	cmu2kzqeu00055t7mrgmescc1	+237655480119	+237655480119	\N	\N	2026-09-21 08:03:27.111	2026-09-21 08:03:27.111
cmuaykjeu003v71kedhjgvvkj	cmu2kzqeu00055t7mrgmescc1	+237655647682	+237655647682	\N	\N	2026-09-21 08:03:27.175	2026-09-21 08:03:27.175
cmuaykjgl003x71keemh5e9gf	cmu2kzqeu00055t7mrgmescc1	+237655655315	+237655655315	\N	\N	2026-09-21 08:03:27.238	2026-09-21 08:03:27.238
cmuaykjic003z71kemrd4ba2l	cmu2kzqeu00055t7mrgmescc1	+237655611422	+237655611422	\N	\N	2026-09-21 08:03:27.3	2026-09-21 08:03:27.3
cmuaykjkd004171keobzbtxmy	cmu2kzqeu00055t7mrgmescc1	+237655666261	+237655666261	\N	\N	2026-09-21 08:03:27.373	2026-09-21 08:03:27.373
cmuaykjm9004371ke4jrgm6yc	cmu2kzqeu00055t7mrgmescc1	+237654445467	+237654445467	\N	\N	2026-09-21 08:03:27.441	2026-09-21 08:03:27.441
cmuaykjo0004571keta2chd1k	cmu2kzqeu00055t7mrgmescc1	+237655703578	+237655703578	\N	\N	2026-09-21 08:03:27.504	2026-09-21 08:03:27.504
cmuaykjq2004771ke0eqexpy8	cmu2kzqeu00055t7mrgmescc1	+237655772944	+237655772944	\N	\N	2026-09-21 08:03:27.578	2026-09-21 08:03:27.578
cmuaykjru004971kegx84u6e3	cmu2kzqeu00055t7mrgmescc1	+237655934191	+237655934191	\N	\N	2026-09-21 08:03:27.642	2026-09-21 08:03:27.642
cmuaykjtp004b71kepffpgdko	cmu2kzqeu00055t7mrgmescc1	+237655854206	+237655854206	\N	\N	2026-09-21 08:03:27.71	2026-09-21 08:03:27.71
cmuaykjvh004d71ke65gx9sld	cmu2kzqeu00055t7mrgmescc1	+237655771817	+237655771817	\N	\N	2026-09-21 08:03:27.774	2026-09-21 08:03:27.774
cmuaykjx8004f71ke63ky7mkc	cmu2kzqeu00055t7mrgmescc1	+237655790820	+237655790820	\N	\N	2026-09-21 08:03:27.836	2026-09-21 08:03:27.836
cmuaykjz2004h71keasx58e1y	cmu2kzqeu00055t7mrgmescc1	+237655875239	+237655875239	\N	\N	2026-09-21 08:03:27.903	2026-09-21 08:03:27.903
cmuaykk0w004j71keaxktcfd3	cmu2kzqeu00055t7mrgmescc1	+237655724776	+237655724776	\N	\N	2026-09-21 08:03:27.968	2026-09-21 08:03:27.968
cmuaykk2w004l71ke8hjr1dul	cmu2kzqeu00055t7mrgmescc1	+237655952537	+237655952537	\N	\N	2026-09-21 08:03:28.04	2026-09-21 08:03:28.04
cmuaykk4t004n71kef5tjjjub	cmu2kzqeu00055t7mrgmescc1	KAAris Duck	+237655963513	\N	\N	2026-09-21 08:03:28.109	2026-09-21 16:27:45.949
cmuaykk6j004p71keku2muokj	cmu2kzqeu00055t7mrgmescc1	+237655939162	+237655939162	\N	\N	2026-09-21 08:03:28.171	2026-09-21 08:03:28.171
cmuaykk8b004r71kefep393zn	cmu2kzqeu00055t7mrgmescc1	+8613876813763	+8613876813763	\N	\N	2026-09-21 08:03:28.235	2026-09-21 08:03:28.235
cmuaykka2004t71keb21ee12t	cmu2kzqeu00055t7mrgmescc1	+27679275666	+27679275666	\N	\N	2026-09-21 08:03:28.298	2026-09-21 08:03:28.298
cmuaykkbz004v71ke9syqqovs	cmu2kzqeu00055t7mrgmescc1	+992020090010	+992020090010	\N	\N	2026-09-21 08:03:28.367	2026-09-21 08:03:28.367
cmuaykkdx004x71ke3ow0uggr	cmu2kzqeu00055t7mrgmescc1	+243836733020	+243836733020	\N	\N	2026-09-21 08:03:28.437	2026-09-21 08:03:28.437
cmuaykkft004z71kes7k1sfpm	cmu2kzqeu00055t7mrgmescc1	+242064531514	+242064531514	\N	\N	2026-09-21 08:03:28.505	2026-09-21 08:03:28.505
cmuaykki4005171kex60fo3db	cmu2kzqeu00055t7mrgmescc1	+23799714852	+23799714852	\N	\N	2026-09-21 08:03:28.588	2026-09-21 08:03:28.588
cmuaykkkj005371key7sq51h9	cmu2kzqeu00055t7mrgmescc1	+23797794603	+23797794603	\N	\N	2026-09-21 08:03:28.676	2026-09-21 08:03:28.676
cmuaykkmd005571ke3o2sbchu	cmu2kzqeu00055t7mrgmescc1	+23795971854	+23795971854	\N	\N	2026-09-21 08:03:28.741	2026-09-21 08:03:28.741
cmuaykko2005771kel2ofrk2v	cmu2kzqeu00055t7mrgmescc1	+23795755874	+23795755874	\N	\N	2026-09-21 08:03:28.803	2026-09-21 08:03:28.803
cmuaykkq3005971kecg00gqlq	cmu2kzqeu00055t7mrgmescc1	+23793739718	+23793739718	\N	\N	2026-09-21 08:03:28.875	2026-09-21 08:03:28.875
cmuaykksl005b71ke0b8b0z37	cmu2kzqeu00055t7mrgmescc1	Gerry	+23797101018	\N	\N	2026-09-21 08:03:28.965	2026-09-21 16:27:39.269
cmuaykkvd005d71kee2v79619	cmu2kzqeu00055t7mrgmescc1	+23795464731	+23795464731	\N	\N	2026-09-21 08:03:29.065	2026-09-21 08:03:29.065
cmuaykkxn005f71kezo8tivhr	cmu2kzqeu00055t7mrgmescc1	+23795596319	+23795596319	\N	\N	2026-09-21 08:03:29.147	2026-09-21 08:03:29.147
cmuaykkzt005h71kepy1n5ssc	cmu2kzqeu00055t7mrgmescc1	+23795929837	+23795929837	\N	\N	2026-09-21 08:03:29.225	2026-09-21 08:03:29.225
cmuaykl1v005j71ke1jzsgwsc	cmu2kzqeu00055t7mrgmescc1	+23795566803	+23795566803	\N	\N	2026-09-21 08:03:29.3	2026-09-21 08:03:29.3
cmuaykl3x005l71ketp2wxsah	cmu2kzqeu00055t7mrgmescc1	+23795411824	+23795411824	\N	\N	2026-09-21 08:03:29.374	2026-09-21 08:03:29.374
cmuaykl60005n71ke5gdrrwt0	cmu2kzqeu00055t7mrgmescc1	+23794725430	+23794725430	\N	\N	2026-09-21 08:03:29.448	2026-09-21 08:03:29.448
cmuayklbr005p71ke6uefckde	cmu2kzqeu00055t7mrgmescc1	+23793028346	+23793028346	\N	\N	2026-09-21 08:03:29.655	2026-09-21 08:03:29.655
cmuaykleg005r71keo57a6p7n	cmu2kzqeu00055t7mrgmescc1	+237699419444	+237699419444	\N	\N	2026-09-21 08:03:29.753	2026-09-21 08:03:29.753
cmuayklg3005t71keuebdd4yh	cmu2kzqeu00055t7mrgmescc1	+237699547449	+237699547449	\N	\N	2026-09-21 08:03:29.812	2026-09-21 08:03:29.812
cmuayklht005v71ke1rb9wwzg	cmu2kzqeu00055t7mrgmescc1	+237699677717	+237699677717	\N	\N	2026-09-21 08:03:29.873	2026-09-21 08:03:29.873
cmuaykljn005x71ke19h0bzhp	cmu2kzqeu00055t7mrgmescc1	+237699271584	+237699271584	\N	\N	2026-09-21 08:03:29.939	2026-09-21 08:03:29.939
cmuaykllj005z71ke3v3h0usj	cmu2kzqeu00055t7mrgmescc1	+237699237711	+237699237711	\N	\N	2026-09-21 08:03:30.007	2026-09-21 08:03:30.007
cmuayklnv006171keikhc19e4	cmu2kzqeu00055t7mrgmescc1	+237699218565	+237699218565	\N	\N	2026-09-21 08:03:30.091	2026-09-21 08:03:30.091
cmuayklq0006371kellzfy5r1	cmu2kzqeu00055t7mrgmescc1	+237699171197	+237699171197	\N	\N	2026-09-21 08:03:30.169	2026-09-21 08:03:30.169
cmuaykls0006571kemuzp1w07	cmu2kzqeu00055t7mrgmescc1	+237699143246	+237699143246	\N	\N	2026-09-21 08:03:30.24	2026-09-21 08:03:30.24
cmuaykm0b006771ke1q0ea1j3	cmu2kzqeu00055t7mrgmescc1	+237699111906	+237699111906	\N	\N	2026-09-21 08:03:30.539	2026-09-21 08:03:30.539
cmuaykm24006971ke28t6uqax	cmu2kzqeu00055t7mrgmescc1	+237699140532	+237699140532	\N	\N	2026-09-21 08:03:30.604	2026-09-21 08:03:30.604
cmuaykm3r006b71kebnjfn8km	cmu2kzqeu00055t7mrgmescc1	Andrea🇨🇲🇨🇲	+237698961393	\N	\N	2026-09-21 08:03:30.663	2026-09-21 16:27:20.947
cmuaykm5k006d71kefn1tq4ya	cmu2kzqeu00055t7mrgmescc1	+237698798302	+237698798302	\N	\N	2026-09-21 08:03:30.728	2026-09-21 08:03:30.728
cmuaykm78006f71keelhh5fp0	cmu2kzqeu00055t7mrgmescc1	+237698285355	+237698285355	\N	\N	2026-09-21 08:03:30.788	2026-09-21 08:03:30.788
cmuaykm94006h71keyswfrri9	cmu2kzqeu00055t7mrgmescc1	+237698143045	+237698143045	\N	\N	2026-09-21 08:03:30.857	2026-09-21 08:03:30.857
cmuaykmau006j71kebc811529	cmu2kzqeu00055t7mrgmescc1	+237698847271	+237698847271	\N	\N	2026-09-21 08:03:30.918	2026-09-21 08:03:30.918
cmuaykmcu006l71kem6mkhxp2	cmu2kzqeu00055t7mrgmescc1	Stéphanie Nguemkem	+237698643932	\N	\N	2026-09-21 08:03:30.99	2026-09-21 16:28:10.448
cmuaykmez006n71kedahgq683	cmu2kzqeu00055t7mrgmescc1	+237698917704	+237698917704	\N	\N	2026-09-21 08:03:31.067	2026-09-21 08:03:31.067
cmuaykmhh006p71keczb2rysr	cmu2kzqeu00055t7mrgmescc1	+237698470149	+237698470149	\N	\N	2026-09-21 08:03:31.157	2026-09-21 08:03:31.157
cmuaykmje006r71ke915aj3r7	cmu2kzqeu00055t7mrgmescc1	Dilano Dilane✳️	+237698303140	\N	\N	2026-09-21 08:03:31.225	2026-09-21 16:27:33.263
cmuaykmr9006t71kety1f5r40	cmu2kzqeu00055t7mrgmescc1	+237698623814	+237698623814	\N	\N	2026-09-21 08:03:31.509	2026-09-21 08:03:31.509
cmuaykmui006v71keovji99w1	cmu2kzqeu00055t7mrgmescc1	+237698930472	+237698930472	\N	\N	2026-09-21 08:03:31.626	2026-09-21 08:03:31.626
cmuaykmwm006x71ke9hv18d5k	cmu2kzqeu00055t7mrgmescc1	+237698716009	+237698716009	\N	\N	2026-09-21 08:03:31.702	2026-09-21 08:03:31.702
cmuaykmz7006z71ked18yhxgt	cmu2kzqeu00055t7mrgmescc1	Alexis Kaldjop	+237698522060	\N	\N	2026-09-21 08:03:31.795	2026-09-21 16:27:20.106
cmuaykn1r007171kecnq4u16y	cmu2kzqeu00055t7mrgmescc1	+237698301475	+237698301475	\N	\N	2026-09-21 08:03:31.887	2026-09-21 08:03:31.887
cmuaykn40007371kelfc4vd1x	cmu2kzqeu00055t7mrgmescc1	+237698836011	+237698836011	\N	\N	2026-09-21 08:03:31.968	2026-09-21 08:03:31.968
cmuaykn6g007571ke9jfmd3po	cmu2kzqeu00055t7mrgmescc1	+237698514631	+237698514631	\N	\N	2026-09-21 08:03:32.056	2026-09-21 08:03:32.056
cmuaykn9h007771keri19bkxe	cmu2kzqeu00055t7mrgmescc1	+237698681321	+237698681321	\N	\N	2026-09-21 08:03:32.166	2026-09-21 08:03:32.166
cmuaykncw007971kepzsq9ouz	cmu2kzqeu00055t7mrgmescc1	+237698603275	+237698603275	\N	\N	2026-09-21 08:03:32.288	2026-09-21 08:03:32.288
cmuayknh1007b71kewoq46tb2	cmu2kzqeu00055t7mrgmescc1	+237698411909	+237698411909	\N	\N	2026-09-21 08:03:32.437	2026-09-21 08:03:32.437
cmuayknjf007d71kexxuaoybl	cmu2kzqeu00055t7mrgmescc1	+237698413611	+237698413611	\N	\N	2026-09-21 08:03:32.524	2026-09-21 08:03:32.524
cmuayknmk007f71kez3asqxc3	cmu2kzqeu00055t7mrgmescc1	+237698355592	+237698355592	\N	\N	2026-09-21 08:03:32.636	2026-09-21 08:03:32.636
cmuayknow007h71ked4hkzntx	cmu2kzqeu00055t7mrgmescc1	+237698117357	+237698117357	\N	\N	2026-09-21 08:03:32.72	2026-09-21 08:03:32.72
cmuayknr0007j71ke6dqnc06g	cmu2kzqeu00055t7mrgmescc1	+237698286988	+237698286988	\N	\N	2026-09-21 08:03:32.796	2026-09-21 08:03:32.796
cmuayknti007l71kewg35c1x2	cmu2kzqeu00055t7mrgmescc1	+237698202252	+237698202252	\N	\N	2026-09-21 08:03:32.886	2026-09-21 08:03:32.886
cmuayknvr007n71kekohhs3ek	cmu2kzqeu00055t7mrgmescc1	+237698655386	+237698655386	\N	\N	2026-09-21 08:03:32.967	2026-09-21 08:03:32.967
cmuayknzh007p71kew2gzgye1	cmu2kzqeu00055t7mrgmescc1	+237698756585	+237698756585	\N	\N	2026-09-21 08:03:33.101	2026-09-21 08:03:33.101
cmuayko2w007r71ke9eylpmmc	cmu2kzqeu00055t7mrgmescc1	+237698775300	+237698775300	\N	\N	2026-09-21 08:03:33.224	2026-09-21 08:03:33.224
cmuayko57007t71keinx769re	cmu2kzqeu00055t7mrgmescc1	+237698482738	+237698482738	\N	\N	2026-09-21 08:03:33.307	2026-09-21 08:03:33.307
cmuayko88007v71kez3j6w5bw	cmu2kzqeu00055t7mrgmescc1	+237698495305	+237698495305	\N	\N	2026-09-21 08:03:33.417	2026-09-21 08:03:33.417
cmuaykoau007x71kelpaao5rn	cmu2kzqeu00055t7mrgmescc1	+237698541245	+237698541245	\N	\N	2026-09-21 08:03:33.51	2026-09-21 08:03:33.51
cmuaykoe8007z71keufsz776w	cmu2kzqeu00055t7mrgmescc1	+237698287525	+237698287525	\N	\N	2026-09-21 08:03:33.632	2026-09-21 08:03:33.632
cmuaykoi3008171keftx68hux	cmu2kzqeu00055t7mrgmescc1	+237698603516	+237698603516	\N	\N	2026-09-21 08:03:33.771	2026-09-21 08:03:33.771
cmuaykok8008371ke2jnagzpw	cmu2kzqeu00055t7mrgmescc1	+237698268402	+237698268402	\N	\N	2026-09-21 08:03:33.848	2026-09-21 08:03:33.848
cmuaykomj008571ke5kssfjhb	cmu2kzqeu00055t7mrgmescc1	+237698501227	+237698501227	\N	\N	2026-09-21 08:03:33.931	2026-09-21 08:03:33.931
cmuaykoov008771keq03efbys	cmu2kzqeu00055t7mrgmescc1	+237698852141	+237698852141	\N	\N	2026-09-21 08:03:34.015	2026-09-21 08:03:34.015
cmuaykorn008971kee5x0pvjd	cmu2kzqeu00055t7mrgmescc1	+237698435963	+237698435963	\N	\N	2026-09-21 08:03:34.115	2026-09-21 08:03:34.115
cmuaykou3008b71ketogdtnlb	cmu2kzqeu00055t7mrgmescc1	+237698142048	+237698142048	\N	\N	2026-09-21 08:03:34.203	2026-09-21 08:03:34.203
cmuaykoxe008d71kep21xttix	cmu2kzqeu00055t7mrgmescc1	+237678950892	+237678950892	\N	\N	2026-09-21 08:03:34.322	2026-09-21 08:03:34.322
cmuaykp5m008f71ke9tn2ae63	cmu2kzqeu00055t7mrgmescc1	I'm	+237678694648	\N	\N	2026-09-21 08:03:34.619	2026-09-21 16:27:40.542
cmuaykpfb008h71ket8973vii	cmu2kzqeu00055t7mrgmescc1	+237697786335	+237697786335	\N	\N	2026-09-21 08:03:34.967	2026-09-21 08:03:34.967
cmuaykpmr008j71ket5d0axbf	cmu2kzqeu00055t7mrgmescc1	+237697766953	+237697766953	\N	\N	2026-09-21 08:03:35.235	2026-09-21 08:03:35.235
cmuaykpt9008l71keziutcpjs	cmu2kzqeu00055t7mrgmescc1	+237678653974	+237678653974	\N	\N	2026-09-21 08:03:35.469	2026-09-21 08:03:35.469
cmuaykq7z008n71ke159hm4x5	cmu2kzqeu00055t7mrgmescc1	+237697740025	+237697740025	\N	\N	2026-09-21 08:03:35.999	2026-09-21 08:03:35.999
cmuaykqfc008p71keabcskueb	cmu2kzqeu00055t7mrgmescc1	Steve Vue	+237677624764	\N	\N	2026-09-21 08:03:36.264	2026-09-21 16:28:10.159
cmuaykqjq008r71kejfw37jie	cmu2kzqeu00055t7mrgmescc1	+237680982306	+237680982306	\N	\N	2026-09-21 08:03:36.422	2026-09-21 08:03:36.422
cmuaykqn0008t71kepvidv7oi	cmu2kzqeu00055t7mrgmescc1	+237680342678	+237680342678	\N	\N	2026-09-21 08:03:36.54	2026-09-21 08:03:36.54
cmuaykqpl008v71kei0adwl1m	cmu2kzqeu00055t7mrgmescc1	+237677318859	+237677318859	\N	\N	2026-09-21 08:03:36.633	2026-09-21 08:03:36.633
cmuaykqsq008x71ke0zn7ksjs	cmu2kzqeu00055t7mrgmescc1	+237679349315	+237679349315	\N	\N	2026-09-21 08:03:36.746	2026-09-21 08:03:36.746
cmuaykqvu008z71keez4omllg	cmu2kzqeu00055t7mrgmescc1	+237674182690	+237674182690	\N	\N	2026-09-21 08:03:36.859	2026-09-21 08:03:36.859
cmuaykrki009171kekt9f4hk0	cmu2kzqeu00055t7mrgmescc1	+237679082557	+237679082557	\N	\N	2026-09-21 08:03:37.747	2026-09-21 08:03:37.747
cmuaykrzv009371ke9yqb5ki4	cmu2kzqeu00055t7mrgmescc1	+237672102286	+237672102286	\N	\N	2026-09-21 08:03:38.299	2026-09-21 08:03:38.299
cmuayks2b009571kehblb1tlw	cmu2kzqeu00055t7mrgmescc1	+237677102784	+237677102784	\N	\N	2026-09-21 08:03:38.387	2026-09-21 08:03:38.387
cmuayks5c009771ke2tq7e7rc	cmu2kzqeu00055t7mrgmescc1	+237677220377	+237677220377	\N	\N	2026-09-21 08:03:38.497	2026-09-21 08:03:38.497
cmuayks8o009971ke6pplcr3k	cmu2kzqeu00055t7mrgmescc1	+237673902396	+237673902396	\N	\N	2026-09-21 08:03:38.616	2026-09-21 08:03:38.616
cmuaykscg009b71keywc3wkum	cmu2kzqeu00055t7mrgmescc1	+237672341874	+237672341874	\N	\N	2026-09-21 08:03:38.752	2026-09-21 08:03:38.752
cmuayksfr009d71kel6voktl7	cmu2kzqeu00055t7mrgmescc1	+237674274397	+237674274397	\N	\N	2026-09-21 08:03:38.872	2026-09-21 08:03:38.872
cmuayksix009f71kehgeap5r0	cmu2kzqeu00055t7mrgmescc1	+237675240717	+237675240717	\N	\N	2026-09-21 08:03:38.985	2026-09-21 08:03:38.985
cmuaykslh009h71ke8714i9hh	cmu2kzqeu00055t7mrgmescc1	+237672688980	+237672688980	\N	\N	2026-09-21 08:03:39.077	2026-09-21 08:03:39.077
cmuayksni009j71ke629y9o47	cmu2kzqeu00055t7mrgmescc1	+237683851446	+237683851446	\N	\N	2026-09-21 08:03:39.15	2026-09-21 08:03:39.15
cmuayksq9009l71kez4v6myhh	cmu2kzqeu00055t7mrgmescc1	+237672559037	+237672559037	\N	\N	2026-09-21 08:03:39.249	2026-09-21 08:03:39.249
cmuaykssk009n71kerk9ph2e5	cmu2kzqeu00055t7mrgmescc1	Chri_sty📍	+237674436563	\N	\N	2026-09-21 08:03:39.332	2026-09-21 16:27:29.323
cmuayksuu009p71keiy8xpb7k	cmu2kzqeu00055t7mrgmescc1	+237672085038	+237672085038	\N	\N	2026-09-21 08:03:39.414	2026-09-21 08:03:39.414
cmuayksya009r71kete43s6vg	cmu2kzqeu00055t7mrgmescc1	+237673678516	+237673678516	\N	\N	2026-09-21 08:03:39.538	2026-09-21 08:03:39.538
cmuaykt13009t71kerbhf1k4l	cmu2kzqeu00055t7mrgmescc1	+237672485187	+237672485187	\N	\N	2026-09-21 08:03:39.639	2026-09-21 08:03:39.639
cmuaykt59009v71kekoegnwp6	cmu2kzqeu00055t7mrgmescc1	+237686042388	+237686042388	\N	\N	2026-09-21 08:03:39.789	2026-09-21 08:03:39.789
cmuaykt7b009x71keexmz0x2a	cmu2kzqeu00055t7mrgmescc1	+237682278882	+237682278882	\N	\N	2026-09-21 08:03:39.863	2026-09-21 08:03:39.863
cmuaykt9c009z71keyp4y6l79	cmu2kzqeu00055t7mrgmescc1	+237681547197	+237681547197	\N	\N	2026-09-21 08:03:39.936	2026-09-21 08:03:39.936
cmuayktbk00a171kei7dw0d1y	cmu2kzqeu00055t7mrgmescc1	+237674385909	+237674385909	\N	\N	2026-09-21 08:03:40.016	2026-09-21 08:03:40.016
cmuayktdk00a371ke15jt456y	cmu2kzqeu00055t7mrgmescc1	+237682353098	+237682353098	\N	\N	2026-09-21 08:03:40.088	2026-09-21 08:03:40.088
cmuayktfn00a571kefy860fvv	cmu2kzqeu00055t7mrgmescc1	+237681801710	+237681801710	\N	\N	2026-09-21 08:03:40.163	2026-09-21 08:03:40.163
cmuayktp600a771keryh4dgju	cmu2kzqeu00055t7mrgmescc1	+237677880605	+237677880605	\N	\N	2026-09-21 08:03:40.506	2026-09-21 08:03:40.506
cmuayktrc00a971keu4mc67xv	cmu2kzqeu00055t7mrgmescc1	+237677763105	+237677763105	\N	\N	2026-09-21 08:03:40.584	2026-09-21 08:03:40.584
cmuaykttd00ab71kez5r85p9j	cmu2kzqeu00055t7mrgmescc1	+237672943559	+237672943559	\N	\N	2026-09-21 08:03:40.657	2026-09-21 08:03:40.657
cmuayktvh00ad71kex9ubucic	cmu2kzqeu00055t7mrgmescc1	+237672643756	+237672643756	\N	\N	2026-09-21 08:03:40.734	2026-09-21 08:03:40.734
cmuayktyn00af71kedrpx2u0c	cmu2kzqeu00055t7mrgmescc1	+237683237788	+237683237788	\N	\N	2026-09-21 08:03:40.847	2026-09-21 08:03:40.847
cmuayku0l00ah71kevlgcprt8	cmu2kzqeu00055t7mrgmescc1	+237683436933	+237683436933	\N	\N	2026-09-21 08:03:40.917	2026-09-21 08:03:40.917
cmuayku3000aj71kex4y2qdc5	cmu2kzqeu00055t7mrgmescc1	Ariane Style🕉️	+237683569300	\N	\N	2026-09-21 08:03:41.005	2026-09-21 16:27:22.216
cmuayku5o00al71ke3opyr098	cmu2kzqeu00055t7mrgmescc1	+237675806150	+237675806150	\N	\N	2026-09-21 08:03:41.101	2026-09-21 08:03:41.101
cmuaykukh00an71ke41wa1roc	cmu2kzqeu00055t7mrgmescc1	+237682270822	+237682270822	\N	\N	2026-09-21 08:03:41.634	2026-09-21 08:03:41.634
cmuaykuq400ap71ketugweg4f	cmu2kzqeu00055t7mrgmescc1	+237675515214	+237675515214	\N	\N	2026-09-21 08:03:41.836	2026-09-21 08:03:41.836
cmuaykuse00ar71kebdfvqi4j	cmu2kzqeu00055t7mrgmescc1	+237678189826	+237678189826	\N	\N	2026-09-21 08:03:41.918	2026-09-21 08:03:41.918
cmuaykv7m00at71ke6y5dsox6	cmu2kzqeu00055t7mrgmescc1	+237675829913	+237675829913	\N	\N	2026-09-21 08:03:42.466	2026-09-21 08:03:42.466
cmuaykva300av71ke3glfuuki	cmu2kzqeu00055t7mrgmescc1	+237682198077	+237682198077	\N	\N	2026-09-21 08:03:42.555	2026-09-21 08:03:42.555
cmuaykvcb00ax71kefl5xb25j	cmu2kzqeu00055t7mrgmescc1	+237672263971	+237672263971	\N	\N	2026-09-21 08:03:42.635	2026-09-21 08:03:42.635
cmuaykve900az71keuv8hli5c	cmu2kzqeu00055t7mrgmescc1	+237698091526	+237698091526	\N	\N	2026-09-21 08:03:42.705	2026-09-21 08:03:42.705
cmuaykvgg00b171keg5srqlr2	cmu2kzqeu00055t7mrgmescc1	+237697991115	+237697991115	\N	\N	2026-09-21 08:03:42.785	2026-09-21 08:03:42.785
cmuaykvie00b371ke2wrfu2wg	cmu2kzqeu00055t7mrgmescc1	+237697956515	+237697956515	\N	\N	2026-09-21 08:03:42.854	2026-09-21 08:03:42.854
cmuaykvk800b571kegaw3ly3m	cmu2kzqeu00055t7mrgmescc1	+237697946388	+237697946388	\N	\N	2026-09-21 08:03:42.921	2026-09-21 08:03:42.921
cmuaykvm500b771ke3vsn7v2n	cmu2kzqeu00055t7mrgmescc1	+237697934524	+237697934524	\N	\N	2026-09-21 08:03:42.989	2026-09-21 08:03:42.989
cmuaykvo700b971ketsg87fx1	cmu2kzqeu00055t7mrgmescc1	+237697925850	+237697925850	\N	\N	2026-09-21 08:03:43.064	2026-09-21 08:03:43.064
cmuaykvq200bb71kez44b6esu	cmu2kzqeu00055t7mrgmescc1	+237697887948	+237697887948	\N	\N	2026-09-21 08:03:43.13	2026-09-21 08:03:43.13
cmuaykvrx00bd71ke3jpuislb	cmu2kzqeu00055t7mrgmescc1	+237697831052	+237697831052	\N	\N	2026-09-21 08:03:43.197	2026-09-21 08:03:43.197
cmuaykvwr00bf71ke1vzqv3mv	cmu2kzqeu00055t7mrgmescc1	+237687021752	+237687021752	\N	\N	2026-09-21 08:03:43.371	2026-09-21 08:03:43.371
cmuaykvyo00bh71keu6f9rbuq	cmu2kzqeu00055t7mrgmescc1	+237689503858	+237689503858	\N	\N	2026-09-21 08:03:43.44	2026-09-21 08:03:43.44
cmuaykw0n00bj71kewh4p791r	cmu2kzqeu00055t7mrgmescc1	+237687711567	+237687711567	\N	\N	2026-09-21 08:03:43.511	2026-09-21 08:03:43.511
cmuaykw2b00bl71kevtt8qae1	cmu2kzqeu00055t7mrgmescc1	+237688827440	+237688827440	\N	\N	2026-09-21 08:03:43.571	2026-09-21 08:03:43.571
cmuaykw4200bn71kesbubd60i	cmu2kzqeu00055t7mrgmescc1	+237686612219	+237686612219	\N	\N	2026-09-21 08:03:43.634	2026-09-21 08:03:43.634
cmuaykw5v00bp71ke4aint225	cmu2kzqeu00055t7mrgmescc1	+237688077073	+237688077073	\N	\N	2026-09-21 08:03:43.699	2026-09-21 08:03:43.699
cmuaykw7s00br71kepgspbbuh	cmu2kzqeu00055t7mrgmescc1	+237689470609	+237689470609	\N	\N	2026-09-21 08:03:43.768	2026-09-21 08:03:43.768
cmuaykw9q00bt71kek1s6pbsa	cmu2kzqeu00055t7mrgmescc1	+237687334688	+237687334688	\N	\N	2026-09-21 08:03:43.838	2026-09-21 08:03:43.838
cmuaykwbt00bv71kex27wjltv	cmu2kzqeu00055t7mrgmescc1	+237688317638	+237688317638	\N	\N	2026-09-21 08:03:43.913	2026-09-21 08:03:43.913
cmuaykwe700bx71keotn8utze	cmu2kzqeu00055t7mrgmescc1	+237688858124	+237688858124	\N	\N	2026-09-21 08:03:43.999	2026-09-21 08:03:43.999
cmuaykwg000bz71kemng34vjd	cmu2kzqeu00055t7mrgmescc1	+237687596222	+237687596222	\N	\N	2026-09-21 08:03:44.064	2026-09-21 08:03:44.064
cmuaykwi100c171ke1ta0npuv	cmu2kzqeu00055t7mrgmescc1	+237687649321	+237687649321	\N	\N	2026-09-21 08:03:44.138	2026-09-21 08:03:44.138
cmuaykwjs00c371kexaslyh4q	cmu2kzqeu00055t7mrgmescc1	+237688230365	+237688230365	\N	\N	2026-09-21 08:03:44.201	2026-09-21 08:03:44.201
cmuaykwlm00c571kex9lr0rza	cmu2kzqeu00055t7mrgmescc1	+237687318425	+237687318425	\N	\N	2026-09-21 08:03:44.266	2026-09-21 08:03:44.266
cmuaykwni00c771ket8apnbvg	cmu2kzqeu00055t7mrgmescc1	+237688022669	+237688022669	\N	\N	2026-09-21 08:03:44.334	2026-09-21 08:03:44.334
cmuaykwph00c971kedh694wym	cmu2kzqeu00055t7mrgmescc1	+237687064322	+237687064322	\N	\N	2026-09-21 08:03:44.405	2026-09-21 08:03:44.405
cmuaykwr500cb71keioapxg4q	cmu2kzqeu00055t7mrgmescc1	+237688661965	+237688661965	\N	\N	2026-09-21 08:03:44.465	2026-09-21 08:03:44.465
cmuaykwsv00cd71kemfvpqupy	cmu2kzqeu00055t7mrgmescc1	+237686948590	+237686948590	\N	\N	2026-09-21 08:03:44.527	2026-09-21 08:03:44.527
cmuaykwuk00cf71ke3do3knec	cmu2kzqeu00055t7mrgmescc1	+237686919081	+237686919081	\N	\N	2026-09-21 08:03:44.589	2026-09-21 08:03:44.589
cmuaykww800ch71ke76idutlu	cmu2kzqeu00055t7mrgmescc1	WAZARIEN LAUTORITE📍	+237686493634	\N	\N	2026-09-21 08:03:44.649	2026-09-21 16:28:13.67
cmuaykwy700cj71kejgjpijn8	cmu2kzqeu00055t7mrgmescc1	+237689306808	+237689306808	\N	\N	2026-09-21 08:03:44.719	2026-09-21 08:03:44.719
cmuaykwzz00cl71kexgfv5zaz	cmu2kzqeu00055t7mrgmescc1	+237688887489	+237688887489	\N	\N	2026-09-21 08:03:44.783	2026-09-21 08:03:44.783
cmuaykx3700cn71kemk9jalsa	cmu2kzqeu00055t7mrgmescc1	+237689837656	+237689837656	\N	\N	2026-09-21 08:03:44.899	2026-09-21 08:03:44.899
cmuaykx8600cp71kenkzg43ux	cmu2kzqeu00055t7mrgmescc1	+237688308337	+237688308337	\N	\N	2026-09-21 08:03:45.079	2026-09-21 08:03:45.079
cmuaykxa900cr71keb8toxgst	cmu2kzqeu00055t7mrgmescc1	Dilan Dollars📍	+237686343336	\N	\N	2026-09-21 08:03:45.153	2026-09-21 16:27:33.168
cmuaykxcg00ct71keoxthhnas	cmu2kzqeu00055t7mrgmescc1	+237686997788	+237686997788	\N	\N	2026-09-21 08:03:45.232	2026-09-21 08:03:45.232
cmuaykxeb00cv71kehmwbvc0k	cmu2kzqeu00055t7mrgmescc1	+237689096934	+237689096934	\N	\N	2026-09-21 08:03:45.299	2026-09-21 08:03:45.299
cmuaykxg500cx71ke16oo9r65	cmu2kzqeu00055t7mrgmescc1	+237687155691	+237687155691	\N	\N	2026-09-21 08:03:45.366	2026-09-21 08:03:45.366
cmuaykxhw00cz71keuscytz23	cmu2kzqeu00055t7mrgmescc1	+237688638957	+237688638957	\N	\N	2026-09-21 08:03:45.428	2026-09-21 08:03:45.428
cmuaykxjs00d171kex8khm4v5	cmu2kzqeu00055t7mrgmescc1	+237686372661	+237686372661	\N	\N	2026-09-21 08:03:45.497	2026-09-21 08:03:45.497
cmuaykxme00d371keit2fnmke	cmu2kzqeu00055t7mrgmescc1	+237688256044	+237688256044	\N	\N	2026-09-21 08:03:45.591	2026-09-21 08:03:45.591
cmuaykxp400d571keosotrmhd	cmu2kzqeu00055t7mrgmescc1	+237690568718	+237690568718	\N	\N	2026-09-21 08:03:45.689	2026-09-21 08:03:45.689
cmuaykxt900d771kebzs8tz46	cmu2kzqeu00055t7mrgmescc1	+237659755385	+237659755385	\N	\N	2026-09-21 08:03:45.837	2026-09-21 08:03:45.837
cmuaykxwy00d971ke9hebkt6o	cmu2kzqeu00055t7mrgmescc1	+237690573880	+237690573880	\N	\N	2026-09-21 08:03:45.97	2026-09-21 08:03:45.97
cmuayky0p00db71kepwq712xw	cmu2kzqeu00055t7mrgmescc1	+237690513491	+237690513491	\N	\N	2026-09-21 08:03:46.105	2026-09-21 08:03:46.105
cmuayky4d00dd71kedwie5mtl	cmu2kzqeu00055t7mrgmescc1	Falcone	+237690687337	\N	\N	2026-09-21 08:03:46.238	2026-09-21 16:27:36.957
cmuayky8t00df71kekw06qlhr	cmu2kzqeu00055t7mrgmescc1	+237655994886	+237655994886	\N	\N	2026-09-21 08:03:46.398	2026-09-21 08:03:46.398
cmuaykyd600dh71ke4ir9gmv6	cmu2kzqeu00055t7mrgmescc1	+237690154510	+237690154510	\N	\N	2026-09-21 08:03:46.555	2026-09-21 08:03:46.555
cmuaykyhp00dj71kea61cbhi7	cmu2kzqeu00055t7mrgmescc1	+237691187999	+237691187999	\N	\N	2026-09-21 08:03:46.717	2026-09-21 08:03:46.717
cmuaykylc00dl71kekb4vlle7	cmu2kzqeu00055t7mrgmescc1	+237690777990	+237690777990	\N	\N	2026-09-21 08:03:46.848	2026-09-21 08:03:46.848
cmuaykyom00dn71keclcmli6r	cmu2kzqeu00055t7mrgmescc1	+237690652725	+237690652725	\N	\N	2026-09-21 08:03:46.966	2026-09-21 08:03:46.966
cmuaykyu600dp71keh251dy85	cmu2kzqeu00055t7mrgmescc1	+237690667306	+237690667306	\N	\N	2026-09-21 08:03:47.166	2026-09-21 08:03:47.166
cmuaykz5c00dr71ke5rz1b06v	cmu2kzqeu00055t7mrgmescc1	+237691170267	+237691170267	\N	\N	2026-09-21 08:03:47.568	2026-09-21 08:03:47.568
cmuaykzau00dt71kegatrikg1	cmu2kzqeu00055t7mrgmescc1	+237690987506	+237690987506	\N	\N	2026-09-21 08:03:47.766	2026-09-21 08:03:47.766
cmuaykzgj00dv71ked5woylkd	cmu2kzqeu00055t7mrgmescc1	+237690889060	+237690889060	\N	\N	2026-09-21 08:03:47.972	2026-09-21 08:03:47.972
cmuaykzka00dx71kecvos4hz0	cmu2kzqeu00055t7mrgmescc1	+237691009904	+237691009904	\N	\N	2026-09-21 08:03:48.106	2026-09-21 08:03:48.106
cmuaykzod00dz71keabk2hcs4	cmu2kzqeu00055t7mrgmescc1	+237690262419	+237690262419	\N	\N	2026-09-21 08:03:48.254	2026-09-21 08:03:48.254
cmuaykzsg00e171kepxzhsowz	cmu2kzqeu00055t7mrgmescc1	+237690621466	+237690621466	\N	\N	2026-09-21 08:03:48.4	2026-09-21 08:03:48.4
cmuayl0cx00e371kerpvsno9g	cmu2kzqeu00055t7mrgmescc1	+237691147240	+237691147240	\N	\N	2026-09-21 08:03:49.138	2026-09-21 08:03:49.138
cmuayl0ka00e571kexfs5zz5w	cmu2kzqeu00055t7mrgmescc1	+237690402984	+237690402984	\N	\N	2026-09-21 08:03:49.402	2026-09-21 08:03:49.402
cmuayl0nx00e771ke79936smy	cmu2kzqeu00055t7mrgmescc1	+237690738238	+237690738238	\N	\N	2026-09-21 08:03:49.533	2026-09-21 08:03:49.533
cmuayl0rj00e971ker45up1yt	cmu2kzqeu00055t7mrgmescc1	+237690146016	+237690146016	\N	\N	2026-09-21 08:03:49.664	2026-09-21 08:03:49.664
cmuayl0ve00eb71kev6j6xgpm	cmu2kzqeu00055t7mrgmescc1	+237690798727	+237690798727	\N	\N	2026-09-21 08:03:49.802	2026-09-21 08:03:49.802
cmuayl10f00ed71keutu9740h	cmu2kzqeu00055t7mrgmescc1	+237690044631	+237690044631	\N	\N	2026-09-21 08:03:49.983	2026-09-21 08:03:49.983
cmuayl1c100ef71ke67sdtzy0	cmu2kzqeu00055t7mrgmescc1	+237690851250	+237690851250	\N	\N	2026-09-21 08:03:50.402	2026-09-21 08:03:50.402
cmuayl2ac00eh71ke7iv2wiax	cmu2kzqeu00055t7mrgmescc1	+237690818060	+237690818060	\N	\N	2026-09-21 08:03:51.637	2026-09-21 08:03:51.637
cmuayl2ee00ej71kejgaqrg6k	cmu2kzqeu00055t7mrgmescc1	+237690570239	+237690570239	\N	\N	2026-09-21 08:03:51.782	2026-09-21 08:03:51.782
cmuayl2il00el71ke7mdaavr3	cmu2kzqeu00055t7mrgmescc1	+237691131579	+237691131579	\N	\N	2026-09-21 08:03:51.933	2026-09-21 08:03:51.933
cmuayl2nt00en71kecinuqcsf	cmu2kzqeu00055t7mrgmescc1	Queen Balaistie📍	+237690629855	\N	\N	2026-09-21 08:03:52.121	2026-09-21 16:28:04.808
cmuayl2sc00ep71kec4u9yh5o	cmu2kzqeu00055t7mrgmescc1	+237690420102	+237690420102	\N	\N	2026-09-21 08:03:52.284	2026-09-21 08:03:52.284
cmuayl2wm00er71kepphp68em	cmu2kzqeu00055t7mrgmescc1	+237689902285	+237689902285	\N	\N	2026-09-21 08:03:52.438	2026-09-21 08:03:52.438
cmuayl39100et71ke93jwong3	cmu2kzqeu00055t7mrgmescc1	+237690578721	+237690578721	\N	\N	2026-09-21 08:03:52.886	2026-09-21 08:03:52.886
cmuayl3ei00ev71kel638aemi	cmu2kzqeu00055t7mrgmescc1	+237690566725	+237690566725	\N	\N	2026-09-21 08:03:53.082	2026-09-21 08:03:53.082
cmuayl3k300ex71kealta40x0	cmu2kzqeu00055t7mrgmescc1	+237691170825	+237691170825	\N	\N	2026-09-21 08:03:53.283	2026-09-21 08:03:53.283
cmuayl3qm00ez71kesvqe4aq8	cmu2kzqeu00055t7mrgmescc1	+237659672264	+237659672264	\N	\N	2026-09-21 08:03:53.518	2026-09-21 08:03:53.518
cmuayl3zs00f171ke4ui1vals	cmu2kzqeu00055t7mrgmescc1	+237690159459	+237690159459	\N	\N	2026-09-21 08:03:53.848	2026-09-21 08:03:53.848
cmuayl49900f371ke7iwdne4a	cmu2kzqeu00055t7mrgmescc1	+237676981026	+237676981026	\N	\N	2026-09-21 08:03:54.189	2026-09-21 08:03:54.189
cmuayl4f200f571keshd1grnj	cmu2kzqeu00055t7mrgmescc1	+237698883169	+237698883169	\N	\N	2026-09-21 08:03:54.398	2026-09-21 08:03:54.398
cmuayl4j500f771kehdcfl19p	cmu2kzqeu00055t7mrgmescc1	+237658080108	+237658080108	\N	\N	2026-09-21 08:03:54.546	2026-09-21 08:03:54.546
cmuayl4n300f971kef4gfeodm	cmu2kzqeu00055t7mrgmescc1	N	+237656784552	\N	\N	2026-09-21 08:03:54.687	2026-09-21 16:27:59.044
cmuayl4r100fb71ke5ck8ae14	cmu2kzqeu00055t7mrgmescc1	Andy📍	+237695611994	\N	\N	2026-09-21 08:03:54.829	2026-09-21 16:27:21.066
cmuayl4uv00fd71kex991fsnw	cmu2kzqeu00055t7mrgmescc1	+237692471845	+237692471845	\N	\N	2026-09-21 08:03:54.967	2026-09-21 08:03:54.967
cmuayl4z800ff71ke9p2htyqc	cmu2kzqeu00055t7mrgmescc1	+237694613535	+237694613535	\N	\N	2026-09-21 08:03:55.124	2026-09-21 08:03:55.124
cmuayl52u00fh71kefe1y63vn	cmu2kzqeu00055t7mrgmescc1	+237658951132	+237658951132	\N	\N	2026-09-21 08:03:55.255	2026-09-21 08:03:55.255
cmuayl56t00fj71keyturyuof	cmu2kzqeu00055t7mrgmescc1	Gr	+22999413985	\N	\N	2026-09-21 08:03:55.397	2026-09-21 16:27:39.756
cmuayl5aq00fl71ke8rj1grfe	cmu2kzqeu00055t7mrgmescc1	+237656789402	+237656789402	\N	\N	2026-09-21 08:03:55.538	2026-09-21 08:03:55.538
cmuayl5m100fn71ke1888c2yc	cmu2kzqeu00055t7mrgmescc1	𝑹𝒐𝒔𝒆 𝒁�	+237657099809	\N	\N	2026-09-21 08:03:55.945	2026-09-21 16:28:19.41
cmuayl5qq00fp71kedrp56v9m	cmu2kzqeu00055t7mrgmescc1	+237640123666	+237640123666	\N	\N	2026-09-21 08:03:56.114	2026-09-21 08:03:56.114
cmuayl5v400fr71keo1w2n2jb	cmu2kzqeu00055t7mrgmescc1	+22504842761	+22504842761	\N	\N	2026-09-21 08:03:56.271	2026-09-21 08:03:56.271
cmuayl5zm00ft71kehw3uxlok	cmu2kzqeu00055t7mrgmescc1	Charly	+2250153457383	\N	\N	2026-09-21 08:03:56.434	2026-09-21 16:27:29.01
cmuayl64600fv71keosw1hqjp	cmu2kzqeu00055t7mrgmescc1	Mic Key	+237686878451	\N	\N	2026-09-21 08:03:56.598	2026-09-21 16:27:55.135
cmuayl68a00fx71keh7ojid0r	cmu2kzqeu00055t7mrgmescc1	Boy Ca	+237650343401	\N	\N	2026-09-21 08:03:56.746	2026-09-21 16:27:25.932
cmuayl6cz00fz71kepincwaq2	cmu2kzqeu00055t7mrgmescc1	Mr Orange Money	+23799949764	\N	\N	2026-09-21 08:03:56.915	2026-09-21 16:27:57.462
cmuayl6hj00g171kej3dv7e6b	cmu2kzqeu00055t7mrgmescc1	#BELLINGHAM#	+237674759125	\N	\N	2026-09-21 08:03:57.079	2026-09-21 08:03:57.079
cmuayl6ld00g371keyoqlawxw	cmu2kzqeu00055t7mrgmescc1	#Franklin	+237680361775	\N	\N	2026-09-21 08:03:57.217	2026-09-21 08:03:57.217
cmuayl6qu00g571ke64iivxnm	cmu2kzqeu00055t7mrgmescc1	#Muriellesophie	+237674839284	\N	\N	2026-09-21 08:03:57.415	2026-09-21 08:03:57.415
cmuayl6ws00g771kej3xp1dzi	cmu2kzqeu00055t7mrgmescc1	(B.B) Billionaire 🤑😎	+237672480660	\N	\N	2026-09-21 08:03:57.628	2026-09-21 08:03:57.628
cmuayl71j00g971ke2h02pfwz	cmu2kzqeu00055t7mrgmescc1	*Dashi junior*	+237655362885	\N	\N	2026-09-21 08:03:57.8	2026-09-21 08:03:57.8
cmuayl76500gb71ke87rxztl9	cmu2kzqeu00055t7mrgmescc1	+212681768440	+212681768440	\N	\N	2026-09-21 08:03:57.965	2026-09-21 08:03:57.965
cmuayl7f200gd71kewvq04kti	cmu2kzqeu00055t7mrgmescc1	+221777061913	+221777061913	\N	\N	2026-09-21 08:03:58.286	2026-09-21 08:03:58.286
cmuayl7o700gf71kezhua4x7v	cmu2kzqeu00055t7mrgmescc1	+221778043386	+221778043386	\N	\N	2026-09-21 08:03:58.615	2026-09-21 08:03:58.615
cmuayl7t700gh71kee5o7j5h2	cmu2kzqeu00055t7mrgmescc1	+221781155252	+221781155252	\N	\N	2026-09-21 08:03:58.795	2026-09-21 08:03:58.795
cmuayl7xu00gj71kejvxy333k	cmu2kzqeu00055t7mrgmescc1	+22368191283	+22368191283	\N	\N	2026-09-21 08:03:58.962	2026-09-21 08:03:58.962
cmuayl88000gl71kexyosql2w	cmu2kzqeu00055t7mrgmescc1	+22378981208	+22378981208	\N	\N	2026-09-21 08:03:59.328	2026-09-21 08:03:59.328
cmuayl9aw00gn71keqdptww5g	cmu2kzqeu00055t7mrgmescc1	+224610454494	+224610454494	\N	\N	2026-09-21 08:04:00.729	2026-09-21 08:04:00.729
cmuaylaa900gp71ke344swkps	cmu2kzqeu00055t7mrgmescc1	+224620009971	+224620009971	\N	\N	2026-09-21 08:04:02.002	2026-09-21 08:04:02.002
cmuaylajk00gr71ke9oitcwv8	cmu2kzqeu00055t7mrgmescc1	+224621664230	+224621664230	\N	\N	2026-09-21 08:04:02.336	2026-09-21 08:04:02.336
cmuaylar700gt71key8ovo4q7	cmu2kzqeu00055t7mrgmescc1	+224624310543	+224624310543	\N	\N	2026-09-21 08:04:02.611	2026-09-21 08:04:02.611
cmuaylbtq00gv71ke6783rhct	cmu2kzqeu00055t7mrgmescc1	+224624539797	+224624539797	\N	\N	2026-09-21 08:04:03.998	2026-09-21 08:04:03.998
cmuaylc4t00gx71kee0mv0nzj	cmu2kzqeu00055t7mrgmescc1	+224625558229	+224625558229	\N	\N	2026-09-21 08:04:04.397	2026-09-21 08:04:04.397
cmuaylcau00gz71ke58loaj2c	cmu2kzqeu00055t7mrgmescc1	+224626053021	+224626053021	\N	\N	2026-09-21 08:04:04.614	2026-09-21 08:04:04.614
cmuaylci600h171ke9qe6sjiq	cmu2kzqeu00055t7mrgmescc1	+224626440709	+224626440709	\N	\N	2026-09-21 08:04:04.878	2026-09-21 08:04:04.878
cmuaylcr000h371kezqchqhzg	cmu2kzqeu00055t7mrgmescc1	+224627123249	+224627123249	\N	\N	2026-09-21 08:04:05.196	2026-09-21 08:04:05.196
cmuaylcvb00h571kexexncd8h	cmu2kzqeu00055t7mrgmescc1	+2250160345783	+2250160345783	\N	\N	2026-09-21 08:04:05.351	2026-09-21 08:04:05.351
cmuayldb300h771ke9kp7s17t	cmu2kzqeu00055t7mrgmescc1	+22501614690	+22501614690	\N	\N	2026-09-21 08:04:05.92	2026-09-21 08:04:05.92
cmuayldgf00h971ke0blhmgca	cmu2kzqeu00055t7mrgmescc1	+22502673847	+22502673847	\N	\N	2026-09-21 08:04:06.112	2026-09-21 08:04:06.112
cmuayldll00hb71keqwpzegqm	cmu2kzqeu00055t7mrgmescc1	+22504757340	+22504757340	\N	\N	2026-09-21 08:04:06.297	2026-09-21 08:04:06.297
cmuayldqr00hd71kejw47cv3c	cmu2kzqeu00055t7mrgmescc1	+22505151230	+22505151230	\N	\N	2026-09-21 08:04:06.483	2026-09-21 08:04:06.483
cmuayldvd00hf71ketsdcgf64	cmu2kzqeu00055t7mrgmescc1	+22505695161	+22505695161	\N	\N	2026-09-21 08:04:06.649	2026-09-21 08:04:06.649
cmuaylee700hh71kelzj0zqm2	cmu2kzqeu00055t7mrgmescc1	+2250700450411	+2250700450411	\N	\N	2026-09-21 08:04:07.327	2026-09-21 08:04:07.327
cmuayleil00hj71ke4n007w2g	cmu2kzqeu00055t7mrgmescc1	+2250702022719	+2250702022719	\N	\N	2026-09-21 08:04:07.485	2026-09-21 08:04:07.485
cmuaylenu00hl71ke39gak9mh	cmu2kzqeu00055t7mrgmescc1	+2250702817931	+2250702817931	\N	\N	2026-09-21 08:04:07.674	2026-09-21 08:04:07.674
cmuayleof00hn71ke21cxvfnc	cmu2kzqeu00055t7mrgmescc1	+2250702817931	+2250702817931	\N	\N	2026-09-21 08:04:07.695	2026-09-21 08:04:07.695
cmuaylero00hp71kep1ghcg2a	cmu2kzqeu00055t7mrgmescc1	+2250704366494	+2250704366494	\N	\N	2026-09-21 08:04:07.812	2026-09-21 08:04:07.812
cmuayles900hr71keb710gdgf	cmu2kzqeu00055t7mrgmescc1	+2250704366494	+2250704366494	\N	\N	2026-09-21 08:04:07.833	2026-09-21 08:04:07.833
cmuaylew000ht71kef3x757j2	cmu2kzqeu00055t7mrgmescc1	+2250712564939	+2250712564939	\N	\N	2026-09-21 08:04:07.969	2026-09-21 08:04:07.969
cmuaylews00hv71ke37rg7sac	cmu2kzqeu00055t7mrgmescc1	+2250712564939	+2250712564939	\N	\N	2026-09-21 08:04:07.996	2026-09-21 08:04:07.996
cmuaylezr00hx71ke2syjzj25	cmu2kzqeu00055t7mrgmescc1	+2250715564022	+2250715564022	\N	\N	2026-09-21 08:04:08.103	2026-09-21 08:04:08.103
cmuaylf0n00hz71keaxpl1qjy	cmu2kzqeu00055t7mrgmescc1	+2250715564022	+2250715564022	\N	\N	2026-09-21 08:04:08.135	2026-09-21 08:04:08.135
cmuaylf3f00i171keer271yrh	cmu2kzqeu00055t7mrgmescc1	+22507313578	+22507313578	\N	\N	2026-09-21 08:04:08.235	2026-09-21 08:04:08.235
cmuaylf4600i371kecmxmz3a4	cmu2kzqeu00055t7mrgmescc1	+22507313578	+22507313578	\N	\N	2026-09-21 08:04:08.262	2026-09-21 08:04:08.262
cmuaylf6m00i571keknl6bkub	cmu2kzqeu00055t7mrgmescc1	+22507727769	+22507727769	\N	\N	2026-09-21 08:04:08.351	2026-09-21 08:04:08.351
cmuaylf7j00i771kex4en71d5	cmu2kzqeu00055t7mrgmescc1	+22507727769	+22507727769	\N	\N	2026-09-21 08:04:08.383	2026-09-21 08:04:08.383
cmuaylfaj00i971kede9brhcg	cmu2kzqeu00055t7mrgmescc1	+22507729289	+22507729289	\N	\N	2026-09-21 08:04:08.491	2026-09-21 08:04:08.491
cmuaylfbd00ib71keuajlrde3	cmu2kzqeu00055t7mrgmescc1	+22507729289	+22507729289	\N	\N	2026-09-21 08:04:08.522	2026-09-21 08:04:08.522
cmuaylfeb00id71kewhcsqpfv	cmu2kzqeu00055t7mrgmescc1	+22508804758	+22508804758	\N	\N	2026-09-21 08:04:08.628	2026-09-21 08:04:08.628
cmuaylff900if71kens5fotij	cmu2kzqeu00055t7mrgmescc1	+22508804758	+22508804758	\N	\N	2026-09-21 08:04:08.662	2026-09-21 08:04:08.662
cmuaylfpj00ih71keukzz34u5	cmu2kzqeu00055t7mrgmescc1	+22509755577	+22509755577	\N	\N	2026-09-21 08:04:09.031	2026-09-21 08:04:09.031
cmuaylfqi00ij71kezkleg03u	cmu2kzqeu00055t7mrgmescc1	+22509755577	+22509755577	\N	\N	2026-09-21 08:04:09.066	2026-09-21 08:04:09.066
cmuaylksv00il71ke5xa11au5	cmu2kzqeu00055t7mrgmescc1	+237677917865	+237677917865	\N	\N	2026-09-21 08:04:15.631	2026-09-21 08:04:15.631
cmuaylkui00in71kemsr6eh8h	cmu2kzqeu00055t7mrgmescc1	+237677917865	+237677917865	\N	\N	2026-09-21 08:04:15.69	2026-09-21 08:04:15.69
cmuayloua00ip71kemucyblud	cmu2kzqeu00055t7mrgmescc1	+254756205488 Aviator	+254756205488	\N	\N	2026-09-21 08:04:20.866	2026-09-21 08:04:20.866
cmuayloyf00ir71kesd53fboa	cmu2kzqeu00055t7mrgmescc1	+254756205488 Aviator	+254756205488	\N	\N	2026-09-21 08:04:21.015	2026-09-21 08:04:21.015
cmuaylp8t00it71keodhbad15	cmu2kzqeu00055t7mrgmescc1	Alone	+237698271679	\N	\N	2026-09-21 08:04:21.389	2026-09-21 16:27:20.416
cmuaylpbb00iv71kev9xb9d4d	cmu2kzqeu00055t7mrgmescc1	-𝐢𝐧𝐠 𝐚̈𝐥𝐞𝐱 𝐬𝐭𝐞̂𝐩𝐡𝐚̊𝐧̃𝐞̨ 🇨🇦	+237698271679	\N	\N	2026-09-21 08:04:21.479	2026-09-21 08:04:21.479
cmuaylpgz00ix71ker4hnw5oo	cmu2kzqeu00055t7mrgmescc1	0x_Roy🔱	+2349030282761	\N	\N	2026-09-21 08:04:21.683	2026-09-21 08:04:21.683
cmuaylpi700iz71kehdznaq2j	cmu2kzqeu00055t7mrgmescc1	0x_Roy🔱	+2349030282761	\N	\N	2026-09-21 08:04:21.727	2026-09-21 08:04:21.727
cmuaylpmt00j171ke85c8ywf9	cmu2kzqeu00055t7mrgmescc1	1 Chat	+237674848503	\N	\N	2026-09-21 08:04:21.893	2026-09-21 08:04:21.893
cmuaylppn00j371keak4ohsuz	cmu2kzqeu00055t7mrgmescc1	1 Chat	+237674848503	\N	\N	2026-09-21 08:04:21.995	2026-09-21 08:04:21.995
cmuaylpvm00j571kekb8c80ez	cmu2kzqeu00055t7mrgmescc1	117	+237658828117	\N	\N	2026-09-21 08:04:22.21	2026-09-21 08:04:22.21
cmuaylpwr00j771keltl4o49q	cmu2kzqeu00055t7mrgmescc1	117	+237658828117	\N	\N	2026-09-21 08:04:22.251	2026-09-21 08:04:22.251
cmuaylq2y00j971kead2iw99v	cmu2kzqeu00055t7mrgmescc1	11:11🇫🇷😈	+237687008007	\N	\N	2026-09-21 08:04:22.474	2026-09-21 08:04:22.474
cmuaylq6700jb71keb8eug48y	cmu2kzqeu00055t7mrgmescc1	11:11🇫🇷😈	+237687008007	\N	\N	2026-09-21 08:04:22.592	2026-09-21 08:04:22.592
cmuaylq9c00jd71kepduyh8wh	cmu2kzqeu00055t7mrgmescc1	237 Palava	+237676855623	\N	\N	2026-09-21 08:04:22.704	2026-09-21 08:04:22.704
cmuaylqat00jf71ke0tp8efyg	cmu2kzqeu00055t7mrgmescc1	237 Palava	+237676855623	\N	\N	2026-09-21 08:04:22.757	2026-09-21 08:04:22.757
cmuaylqdo00jh71kexzxoxgzh	cmu2kzqeu00055t7mrgmescc1	2KISS	+237682432962	\N	\N	2026-09-21 08:04:22.86	2026-09-21 08:04:22.86
cmuaylqes00jj71keiz6qd9jy	cmu2kzqeu00055t7mrgmescc1	2KISS	+237682432962	\N	\N	2026-09-21 08:04:22.9	2026-09-21 08:04:22.9
cmuaylqhd00jl71ke5daa452a	cmu2kzqeu00055t7mrgmescc1	@Sammy Døllårs	+237691554803	\N	\N	2026-09-21 08:04:22.993	2026-09-21 08:04:22.993
cmuaylqig00jn71ke0r88bq7u	cmu2kzqeu00055t7mrgmescc1	@Sammy Døllårs	+237691554803	\N	\N	2026-09-21 08:04:23.032	2026-09-21 08:04:23.032
cmuaylqlh00jp71ke9haq3e2u	cmu2kzqeu00055t7mrgmescc1	A	+18298056463	\N	\N	2026-09-21 08:04:23.141	2026-09-21 08:04:23.141
cmuaylqml00jr71keg86a93rm	cmu2kzqeu00055t7mrgmescc1	A	+18298056463	\N	\N	2026-09-21 08:04:23.181	2026-09-21 08:04:23.181
cmuaylqpl00jt71ke7q76c9s7	cmu2kzqeu00055t7mrgmescc1	A.l.Y.S.S.O.N	+237653864781	\N	\N	2026-09-21 08:04:23.289	2026-09-21 08:04:23.289
cmuaylqqm00jv71keaolhk5yt	cmu2kzqeu00055t7mrgmescc1	A.l.Y.S.S.O.N	+237653864781	\N	\N	2026-09-21 08:04:23.326	2026-09-21 08:04:23.326
cmuaylqt300jx71ke28r0c8ew	cmu2kzqeu00055t7mrgmescc1	ALBERT NDAYA	+971557647756	\N	\N	2026-09-21 08:04:23.415	2026-09-21 08:04:23.415
cmuaylqu500jz71keyrw90sqt	cmu2kzqeu00055t7mrgmescc1	ALBERT NDAYA	+971557647756	\N	\N	2026-09-21 08:04:23.453	2026-09-21 08:04:23.453
cmuaylqwo00k171kezy4zboyc	cmu2kzqeu00055t7mrgmescc1	ARNOLD THYS	+237658589556	\N	\N	2026-09-21 08:04:23.544	2026-09-21 08:04:23.544
cmuaylqy300k371keb08ohlht	cmu2kzqeu00055t7mrgmescc1	ARNOLD THYS	+237658589556	\N	\N	2026-09-21 08:04:23.595	2026-09-21 08:04:23.595
cmuaylreu00k571ke0bow6qn4	cmu2kzqeu00055t7mrgmescc1	AURA🤳🏽	+237671212351	\N	\N	2026-09-21 08:04:24.199	2026-09-21 08:04:24.199
cmuaylro100k771key6q986ie	cmu2kzqeu00055t7mrgmescc1	AURA🤳🏽	+237671212351	\N	\N	2026-09-21 08:04:24.529	2026-09-21 08:04:24.529
cmuaylrqr00k971ke0qn8czq7	cmu2kzqeu00055t7mrgmescc1	AYDEN	+237694866676	\N	\N	2026-09-21 08:04:24.627	2026-09-21 08:04:24.627
cmuaylrrv00kb71kezygsaroo	cmu2kzqeu00055t7mrgmescc1	AYDEN	+237694866676	\N	\N	2026-09-21 08:04:24.668	2026-09-21 08:04:24.668
cmuaylrul00kd71ke4kqdbbp5	cmu2kzqeu00055t7mrgmescc1	AYO HUMBLE	+22961653666	\N	\N	2026-09-21 08:04:24.765	2026-09-21 08:04:24.765
cmuaylrvv00kf71ke50rc37zb	cmu2kzqeu00055t7mrgmescc1	AYO HUMBLE	+22961653666	\N	\N	2026-09-21 08:04:24.811	2026-09-21 08:04:24.811
cmuaylryb00kh71kesol5gxkl	cmu2kzqeu00055t7mrgmescc1	Aaron	+237689718875	\N	\N	2026-09-21 08:04:24.899	2026-09-21 08:04:24.899
cmuaylrzi00kj71kekwr0hpxf	cmu2kzqeu00055t7mrgmescc1	Aaron	+237689718875	\N	\N	2026-09-21 08:04:24.942	2026-09-21 08:04:24.942
cmuayls2j00kl71kejede6y33	cmu2kzqeu00055t7mrgmescc1	Aaronsamuel	+237687517636	\N	\N	2026-09-21 08:04:25.051	2026-09-21 08:04:25.051
cmuayls3t00kn71kelvceop2a	cmu2kzqeu00055t7mrgmescc1	Aaronsamuel	+237687517636	\N	\N	2026-09-21 08:04:25.097	2026-09-21 08:04:25.097
cmuayls6i00kp71kecnita486	cmu2kzqeu00055t7mrgmescc1	Abaka	+237657364650	\N	\N	2026-09-21 08:04:25.194	2026-09-21 08:04:25.194
cmuayls7n00kr71keiw7l7fr6	cmu2kzqeu00055t7mrgmescc1	Abaka	+237657364650	\N	\N	2026-09-21 08:04:25.235	2026-09-21 08:04:25.235
cmuaylsa400kt71ken4t5v2yi	cmu2kzqeu00055t7mrgmescc1	Abakwa	+237681447045	\N	\N	2026-09-21 08:04:25.324	2026-09-21 08:04:25.324
cmuaylsb500kv71kesz9dktli	cmu2kzqeu00055t7mrgmescc1	Abakwa	+237681447045	\N	\N	2026-09-21 08:04:25.361	2026-09-21 08:04:25.361
cmuaylsdt00kx71keh6egpiqk	cmu2kzqeu00055t7mrgmescc1	Abdoul	+2250565640619	\N	\N	2026-09-21 08:04:25.457	2026-09-21 08:04:25.457
cmuaylsev00kz71keuhb525c4	cmu2kzqeu00055t7mrgmescc1	Abdoul	+2250565640619	\N	\N	2026-09-21 08:04:25.495	2026-09-21 08:04:25.495
cmuaylshq00l171kego0qun0a	cmu2kzqeu00055t7mrgmescc1	Abi	+237683411391	\N	\N	2026-09-21 08:04:25.599	2026-09-21 08:04:25.599
cmuaylsit00l371ke2oi0h9bt	cmu2kzqeu00055t7mrgmescc1	Abi	+237683411391	\N	\N	2026-09-21 08:04:25.637	2026-09-21 08:04:25.637
cmuaylslp00l571kedzx1jobc	cmu2kzqeu00055t7mrgmescc1	Abiri	+237681445426	\N	\N	2026-09-21 08:04:25.741	2026-09-21 08:04:25.741
cmuaylsmt00l771ke1m7nrexb	cmu2kzqeu00055t7mrgmescc1	Abiri	+237681445426	\N	\N	2026-09-21 08:04:25.782	2026-09-21 08:04:25.782
cmuaylspf00l971keoi0sgt6i	cmu2kzqeu00055t7mrgmescc1	Abiti	+237680325981	\N	\N	2026-09-21 08:04:25.876	2026-09-21 08:04:25.876
cmuaylsqf00lb71kexftzfmy6	cmu2kzqeu00055t7mrgmescc1	Abiti	+237680325981	\N	\N	2026-09-21 08:04:25.912	2026-09-21 08:04:25.912
cmuaylssv00ld71kehf0f313k	cmu2kzqeu00055t7mrgmescc1	Abong Judith	+23777684104	\N	\N	2026-09-21 08:04:25.999	2026-09-21 08:04:25.999
cmuaylstw00lf71keikxlkf3h	cmu2kzqeu00055t7mrgmescc1	Abong Judith	+23777684104	\N	\N	2026-09-21 08:04:26.036	2026-09-21 08:04:26.036
cmuaylsx000lh71ke3cy09xtm	cmu2kzqeu00055t7mrgmescc1	Abou🦂⚔️اتيفث ابوبد	+237697469474	\N	\N	2026-09-21 08:04:26.148	2026-09-21 08:04:26.148
cmuaylsy500lj71ke2wgyk3rn	cmu2kzqeu00055t7mrgmescc1	Abou🦂⚔️اتيفث ابوبد	+237697469474	\N	\N	2026-09-21 08:04:26.19	2026-09-21 08:04:26.19
cmuaylt1100ll71ke1lpfyd24	cmu2kzqeu00055t7mrgmescc1	Abu Aja 2	+237672763039	\N	\N	2026-09-21 08:04:26.293	2026-09-21 08:04:26.293
cmuaylt2900ln71kezcga31np	cmu2kzqeu00055t7mrgmescc1	Abu Aja 2	+237672763039	\N	\N	2026-09-21 08:04:26.337	2026-09-21 08:04:26.337
cmuaylt4o00lp71ke5ccwexbs	cmu2kzqeu00055t7mrgmescc1	Abu Amboh	+237674879079	\N	\N	2026-09-21 08:04:26.425	2026-09-21 08:04:26.425
cmuaylt5o00lr71ke5g928et1	cmu2kzqeu00055t7mrgmescc1	Abu Amboh	+237674879079	\N	\N	2026-09-21 08:04:26.46	2026-09-21 08:04:26.46
cmuaylt8500lt71keh57k061f	cmu2kzqeu00055t7mrgmescc1	Abu Frank	+237694208372	\N	\N	2026-09-21 08:04:26.55	2026-09-21 08:04:26.55
cmuaylt9900lv71ke925336ye	cmu2kzqeu00055t7mrgmescc1	Abu Frank	+237694208372	\N	\N	2026-09-21 08:04:26.589	2026-09-21 08:04:26.589
cmuayltc500lx71kehvk7nw5j	cmu2kzqeu00055t7mrgmescc1	Abu Hali	+237671548165	\N	\N	2026-09-21 08:04:26.693	2026-09-21 08:04:26.693
cmuayltde00lz71kexg2abgal	cmu2kzqeu00055t7mrgmescc1	Abu Hali	+237671548165	\N	\N	2026-09-21 08:04:26.738	2026-09-21 08:04:26.738
cmuayltg000m171ke8e5yh81o	cmu2kzqeu00055t7mrgmescc1	Abu Njoma	+237675540175	\N	\N	2026-09-21 08:04:26.832	2026-09-21 08:04:26.832
cmuaylth900m371kebtjpsimc	cmu2kzqeu00055t7mrgmescc1	Abu Njoma	+237675540175	\N	\N	2026-09-21 08:04:26.878	2026-09-21 08:04:26.878
cmuayltju00m571kexjhd276a	cmu2kzqeu00055t7mrgmescc1	Abu Sandra	+237677094077	\N	\N	2026-09-21 08:04:26.97	2026-09-21 08:04:26.97
cmuayltky00m771keulk1lefq	cmu2kzqeu00055t7mrgmescc1	Abu Sandra	+237677094077	\N	\N	2026-09-21 08:04:27.01	2026-09-21 08:04:27.01
cmuayltnq00m971kegug3zc37	cmu2kzqeu00055t7mrgmescc1	Achonduh valentine	+237677428120	\N	\N	2026-09-21 08:04:27.11	2026-09-21 08:04:27.11
cmuayltop00mb71kea1wznjdu	cmu2kzqeu00055t7mrgmescc1	Achonduh valentine	+237677428120	\N	\N	2026-09-21 08:04:27.145	2026-09-21 08:04:27.145
cmuayltr400md71keytacg86q	cmu2kzqeu00055t7mrgmescc1	Achunduh Lilian	+237673937758	\N	\N	2026-09-21 08:04:27.232	2026-09-21 08:04:27.232
cmuayltsb00mf71keu6kf9f86	cmu2kzqeu00055t7mrgmescc1	Achunduh Lilian	+237673937758	\N	\N	2026-09-21 08:04:27.275	2026-09-21 08:04:27.275
cmuayltur00mh71kewm73qope	cmu2kzqeu00055t7mrgmescc1	Adams	+237686115197	\N	\N	2026-09-21 08:04:27.363	2026-09-21 08:04:27.363
cmuayltw000mj71kezfdmzsam	cmu2kzqeu00055t7mrgmescc1	Adams	+237686115197	\N	\N	2026-09-21 08:04:27.409	2026-09-21 08:04:27.409
cmuayltyj00ml71ken8kjkq2w	cmu2kzqeu00055t7mrgmescc1	Afopezi Moses	+237683792644	\N	\N	2026-09-21 08:04:27.499	2026-09-21 08:04:27.499
cmuayltzr00mn71kepxrk2m65	cmu2kzqeu00055t7mrgmescc1	Afopezi Moses	+237683792644	\N	\N	2026-09-21 08:04:27.543	2026-09-21 08:04:27.543
cmuaylu3200mp71kenk0jpv86	cmu2kzqeu00055t7mrgmescc1	Agent Mtn	+237671227347	\N	\N	2026-09-21 08:04:27.663	2026-09-21 08:04:27.663
cmuaylu7o00mr71keqniaxaax	cmu2kzqeu00055t7mrgmescc1	Agent Mtn	+237671227347	\N	\N	2026-09-21 08:04:27.828	2026-09-21 08:04:27.828
cmuayluen00mt71ke256j9kjh	cmu2kzqeu00055t7mrgmescc1	Ago	+237679352604	\N	\N	2026-09-21 08:04:28.079	2026-09-21 08:04:28.079
cmuayluhu00mv71kewkh6cmus	cmu2kzqeu00055t7mrgmescc1	Ago	+237679352604	\N	\N	2026-09-21 08:04:28.195	2026-09-21 08:04:28.195
cmuayluqz00mx71keyhos3ayj	cmu2kzqeu00055t7mrgmescc1	Agwa	+237693161752	\N	\N	2026-09-21 08:04:28.523	2026-09-21 08:04:28.523
cmuayluus00mz71keoq31587f	cmu2kzqeu00055t7mrgmescc1	Agwa	+237693161752	\N	\N	2026-09-21 08:04:28.66	2026-09-21 08:04:28.66
cmuaylv5400n171keqx8b1ijy	cmu2kzqeu00055t7mrgmescc1	Because He Live Agwa I Live, I	+237675411998	\N	\N	2026-09-21 08:04:29.032	2026-09-21 16:27:24.425
cmuaylvat00n371kefaeihllk	cmu2kzqeu00055t7mrgmescc1	Agwa	+237675411998	\N	\N	2026-09-21 08:04:29.237	2026-09-21 08:04:29.237
cmuaylvdl00n571ke08qo2r8m	cmu2kzqeu00055t7mrgmescc1	Ahjara💯🔥✅	+237693991006	\N	\N	2026-09-21 08:04:29.337	2026-09-21 08:04:29.337
cmuaylvet00n771keog76zom5	cmu2kzqeu00055t7mrgmescc1	Ahjara💯🔥✅	+237693991006	\N	\N	2026-09-21 08:04:29.382	2026-09-21 08:04:29.382
cmuaylvhl00n971kewwrsf0bs	cmu2kzqeu00055t7mrgmescc1	Aicha Chat😂🙌🏿	+237672397218	\N	\N	2026-09-21 08:04:29.482	2026-09-21 08:04:29.482
cmuaylviz00nb71kea1pvgdh2	cmu2kzqeu00055t7mrgmescc1	Aicha Chat😂🙌🏿	+237672397218	\N	\N	2026-09-21 08:04:29.532	2026-09-21 08:04:29.532
cmuaylvlr00nd71ke0ew53zy6	cmu2kzqeu00055t7mrgmescc1	Alasco Le Chancelier😷💪🤞❤️	+2250507434232	\N	\N	2026-09-21 08:04:29.631	2026-09-21 08:04:29.631
cmuaylvn600nf71kesfxpbt13	cmu2kzqeu00055t7mrgmescc1	Alasco Le Chancelier😷💪🤞❤️	+2250507434232	\N	\N	2026-09-21 08:04:29.683	2026-09-21 08:04:29.683
cmuaylvwg00nh71keo9fqhnjc	cmu2kzqeu00055t7mrgmescc1	Alex(+_+)	+237650584224	\N	\N	2026-09-21 08:04:30.017	2026-09-21 08:04:30.017
cmuaylvxn00nj71ke8trg4cfy	cmu2kzqeu00055t7mrgmescc1	Alex(+_+)	+237650584224	\N	\N	2026-09-21 08:04:30.059	2026-09-21 08:04:30.059
cmuaylw1200nl71ke1ot7361s	cmu2kzqeu00055t7mrgmescc1	Alexander Chya	+19044819539	\N	\N	2026-09-21 08:04:30.183	2026-09-21 08:04:30.183
cmuaylw2r00nn71kerevvdrqh	cmu2kzqeu00055t7mrgmescc1	Alexander Chya	+19044819539	\N	\N	2026-09-21 08:04:30.243	2026-09-21 08:04:30.243
cmuaylw6200np71kej0q4jggu	cmu2kzqeu00055t7mrgmescc1	Alexia💥	+237696923936	\N	\N	2026-09-21 08:04:30.362	2026-09-21 08:04:30.362
cmuaylw7g00nr71kei3fpxccm	cmu2kzqeu00055t7mrgmescc1	Alexia💥	+237696923936	\N	\N	2026-09-21 08:04:30.413	2026-09-21 08:04:30.413
cmuaylwev00nt71ke83za4w9x	cmu2kzqeu00055t7mrgmescc1	Alex💀	+237683405341	\N	\N	2026-09-21 08:04:30.68	2026-09-21 08:04:30.68
cmuaylwf900nv71keiqe3ar50	cmu2kzqeu00055t7mrgmescc1	Alex💀	+237683405341	\N	\N	2026-09-21 08:04:30.693	2026-09-21 08:04:30.693
cmuaylwog00nx71ke3ojq3oj0	cmu2kzqeu00055t7mrgmescc1	Alhamdulillah	+237652993351	\N	\N	2026-09-21 08:04:31.025	2026-09-21 08:04:31.025
cmuaylwop00nz71kes2mgdps1	cmu2kzqeu00055t7mrgmescc1	Alhamdulillah	+237652993351	\N	\N	2026-09-21 08:04:31.033	2026-09-21 08:04:31.033
cmuaylwsc00o171keppp60gzo	cmu2kzqeu00055t7mrgmescc1	Alia Chat😂	+237680753499	\N	\N	2026-09-21 08:04:31.164	2026-09-21 08:04:31.164
cmuaylwso00o371keabrlsxv0	cmu2kzqeu00055t7mrgmescc1	Alia Chat😂	+237680753499	\N	\N	2026-09-21 08:04:31.176	2026-09-21 08:04:31.176
cmuaylwwf00o571keg3avnx6v	cmu2kzqeu00055t7mrgmescc1	Alice Deluxe	+237652301400	\N	\N	2026-09-21 08:04:31.311	2026-09-21 08:04:31.311
cmuaylwwp00o771ken7ovrthj	cmu2kzqeu00055t7mrgmescc1	Alice Deluxe	+237652301400	\N	\N	2026-09-21 08:04:31.32	2026-09-21 08:04:31.32
cmuaylx0p00o971kek1qsachz	cmu2kzqeu00055t7mrgmescc1	Alice Nk	+237650959500	\N	\N	2026-09-21 08:04:31.465	2026-09-21 08:04:31.465
cmuaylx1000ob71keos04lzoo	cmu2kzqeu00055t7mrgmescc1	Alice Nk	+237650959500	\N	\N	2026-09-21 08:04:31.476	2026-09-21 08:04:31.476
cmuaylx6l00od71ked2znzpx1	cmu2kzqeu00055t7mrgmescc1	Alyah Chat😂	+237658709700	\N	\N	2026-09-21 08:04:31.678	2026-09-21 08:04:31.678
cmuaylx6v00of71ke8jrb32lj	cmu2kzqeu00055t7mrgmescc1	Alyah Chat😂	+237658709700	\N	\N	2026-09-21 08:04:31.687	2026-09-21 08:04:31.687
cmuaylxmn00oh71kehkr9jqcd	cmu2kzqeu00055t7mrgmescc1	Amand	+237678160506	\N	\N	2026-09-21 08:04:32.255	2026-09-21 08:04:32.255
cmuaylxmu00oj71kecv41ukwi	cmu2kzqeu00055t7mrgmescc1	Amand	+237678160506	\N	\N	2026-09-21 08:04:32.262	2026-09-21 08:04:32.262
cmuaylxrt00ol71kej6sntk86	cmu2kzqeu00055t7mrgmescc1	Amanda	+237672975240	\N	\N	2026-09-21 08:04:32.441	2026-09-21 08:04:32.441
cmuaylxsa00on71ke63v7bldr	cmu2kzqeu00055t7mrgmescc1	Amanda	+237672975240	\N	\N	2026-09-21 08:04:32.458	2026-09-21 08:04:32.458
cmuaylxzn00op71ke9w7sqqnn	cmu2kzqeu00055t7mrgmescc1	Ama🤳🏽	+237673681732	\N	\N	2026-09-21 08:04:32.723	2026-09-21 08:04:32.723
cmuayly0700or71kep2vd729m	cmu2kzqeu00055t7mrgmescc1	Ama🤳🏽	+237673681732	\N	\N	2026-09-21 08:04:32.744	2026-09-21 08:04:32.744
cmuayly6300ot71ke0tbfx4w9	cmu2kzqeu00055t7mrgmescc1	Anaelle	+237699799175	\N	\N	2026-09-21 08:04:32.955	2026-09-21 08:04:32.955
cmuayly6e00ov71kelktudh2t	cmu2kzqeu00055t7mrgmescc1	Anaelle	+237699799175	\N	\N	2026-09-21 08:04:32.966	2026-09-21 08:04:32.966
cmuaylyar00ox71kebca011pa	cmu2kzqeu00055t7mrgmescc1	Anastasia ☘️	+237674028513	\N	\N	2026-09-21 08:04:33.123	2026-09-21 08:04:33.123
cmuaylyb100oz71kekaq5o74d	cmu2kzqeu00055t7mrgmescc1	Anastasia ☘️	+237674028513	\N	\N	2026-09-21 08:04:33.133	2026-09-21 08:04:33.133
cmuaylyhr00p171kegjwrmaui	cmu2kzqeu00055t7mrgmescc1	Anaïs 🥰	+237694181624	\N	\N	2026-09-21 08:04:33.375	2026-09-21 08:04:33.375
cmuaylyi900p371ke33s7omb2	cmu2kzqeu00055t7mrgmescc1	Anaïs 🥰	+237694181624	\N	\N	2026-09-21 08:04:33.394	2026-09-21 08:04:33.394
cmuaylymh00p571ke7zn2yrgb	cmu2kzqeu00055t7mrgmescc1	Andi Rebeca	+237652920518	\N	\N	2026-09-21 08:04:33.545	2026-09-21 08:04:33.545
cmuaylymu00p771ked34gtpiw	cmu2kzqeu00055t7mrgmescc1	Andi Rebeca	+237652920518	\N	\N	2026-09-21 08:04:33.559	2026-09-21 08:04:33.559
cmuaylywk00p971keeqwacexf	cmu2kzqeu00055t7mrgmescc1	Ange Bri Chat😂	+237656204145	\N	\N	2026-09-21 08:04:33.908	2026-09-21 08:04:33.908
cmuaylywv00pb71ker7dycj5d	cmu2kzqeu00055t7mrgmescc1	Ange Bri Chat😂	+237656204145	\N	\N	2026-09-21 08:04:33.919	2026-09-21 08:04:33.919
cmuaylz2600pd71kefl25p9rf	cmu2kzqeu00055t7mrgmescc1	Ange Bri🔥💓	+237679720110	\N	\N	2026-09-21 08:04:34.11	2026-09-21 08:04:34.11
cmuaylz2d00pf71kehjsbuw3s	cmu2kzqeu00055t7mrgmescc1	Ange Bri🔥💓	+237679720110	\N	\N	2026-09-21 08:04:34.117	2026-09-21 08:04:34.117
cmuaylz6000ph71keqs82xrcs	cmu2kzqeu00055t7mrgmescc1	Ange Chatons😂	+237677406732	\N	\N	2026-09-21 08:04:34.248	2026-09-21 08:04:34.248
cmuaylz6b00pj71ke0thgs7et	cmu2kzqeu00055t7mrgmescc1	Ange Chatons😂	+237677406732	\N	\N	2026-09-21 08:04:34.259	2026-09-21 08:04:34.259
cmuaylzaq00pl71kedu580e66	cmu2kzqeu00055t7mrgmescc1	Ange Chat🎈👸	+237656149778	\N	\N	2026-09-21 08:04:34.418	2026-09-21 08:04:34.418
cmuaylzaz00pn71kej63b7sez	cmu2kzqeu00055t7mrgmescc1	Ange Chat🎈👸	+237656149778	\N	\N	2026-09-21 08:04:34.428	2026-09-21 08:04:34.428
cmuaylzfd00pp71kew3la5ysq	cmu2kzqeu00055t7mrgmescc1	Ange Laeticia🇨🇲	+237698255463	\N	\N	2026-09-21 08:04:34.585	2026-09-21 08:04:34.585
cmuaylzfl00pr71keidecok0f	cmu2kzqeu00055t7mrgmescc1	Ange Laeticia🇨🇲	+237698255463	\N	\N	2026-09-21 08:04:34.594	2026-09-21 08:04:34.594
cmuaylzjg00pt71ke6fwvk0rf	cmu2kzqeu00055t7mrgmescc1	Ange 🔥😆	+237657854332	\N	\N	2026-09-21 08:04:34.733	2026-09-21 08:04:34.733
cmuaylzjr00pv71kea5m6m4qx	cmu2kzqeu00055t7mrgmescc1	Ange 🔥😆	+237657854332	\N	\N	2026-09-21 08:04:34.743	2026-09-21 08:04:34.743
cmuaylzo100px71kea0iwyatb	cmu2kzqeu00055t7mrgmescc1	Angel 😇	+237673624630	\N	\N	2026-09-21 08:04:34.897	2026-09-21 08:04:34.897
cmuaylzob00pz71keiqaz610u	cmu2kzqeu00055t7mrgmescc1	Angel 😇	+237673624630	\N	\N	2026-09-21 08:04:34.907	2026-09-21 08:04:34.907
cmuaylzs600q171kellmqozpu	cmu2kzqeu00055t7mrgmescc1	Angela ❤️❤️	+237696064941	\N	\N	2026-09-21 08:04:35.046	2026-09-21 08:04:35.046
cmuaylzsg00q371keyi15uo6a	cmu2kzqeu00055t7mrgmescc1	Angela ❤️❤️	+237696064941	\N	\N	2026-09-21 08:04:35.056	2026-09-21 08:04:35.056
cmuaylzw100q571ke4a3zryd3	cmu2kzqeu00055t7mrgmescc1	Angella🍀	+237659412337	\N	\N	2026-09-21 08:04:35.185	2026-09-21 08:04:35.185
cmuaylzw900q771kej8edy2r2	cmu2kzqeu00055t7mrgmescc1	Angella🍀	+237659412337	\N	\N	2026-09-21 08:04:35.194	2026-09-21 08:04:35.194
cmuaym00r00q971ke4jof7tq5	cmu2kzqeu00055t7mrgmescc1	Ange~🥰	+237674468463	\N	\N	2026-09-21 08:04:35.356	2026-09-21 08:04:35.356
cmuaym01100qb71kezz7pgt24	cmu2kzqeu00055t7mrgmescc1	Ange~🥰	+237674468463	\N	\N	2026-09-21 08:04:35.365	2026-09-21 08:04:35.365
cmuaym04m00qd71kessmverpy	cmu2kzqeu00055t7mrgmescc1	Ange🔥💨	+237693601737	\N	\N	2026-09-21 08:04:35.494	2026-09-21 08:04:35.494
cmuaym04v00qf71ke3tz9zk60	cmu2kzqeu00055t7mrgmescc1	Ange🔥💨	+237693601737	\N	\N	2026-09-21 08:04:35.503	2026-09-21 08:04:35.503
cmuaym08b00qh71ketvkv0sgs	cmu2kzqeu00055t7mrgmescc1	Angi Chou🍀⭐️	+237695592337	\N	\N	2026-09-21 08:04:35.627	2026-09-21 08:04:35.627
cmuaym08k00qj71kejvu3ufq1	cmu2kzqeu00055t7mrgmescc1	Angi Chou🍀⭐️	+237695592337	\N	\N	2026-09-21 08:04:35.636	2026-09-21 08:04:35.636
cmuaym0ck00ql71kee289ylpn	cmu2kzqeu00055t7mrgmescc1	Anne❤️besty☘️	+237690456786	\N	\N	2026-09-21 08:04:35.78	2026-09-21 08:04:35.78
cmuaym0cv00qn71keks7rz5sv	cmu2kzqeu00055t7mrgmescc1	Anne❤️besty☘️	+237690456786	\N	\N	2026-09-21 08:04:35.792	2026-09-21 08:04:35.792
cmuaym0hy00qp71kecvhp7q7q	cmu2kzqeu00055t7mrgmescc1	Anni	+237656410541	\N	\N	2026-09-21 08:04:35.975	2026-09-21 08:04:35.975
cmuaym0i500qr71ke1mom54dp	cmu2kzqeu00055t7mrgmescc1	Anni	+237656410541	\N	\N	2026-09-21 08:04:35.982	2026-09-21 08:04:35.982
cmuaym0nl00qt71kezy8sx0zl	cmu2kzqeu00055t7mrgmescc1	Annie Sandy	+237698540126	\N	\N	2026-09-21 08:04:36.177	2026-09-21 08:04:36.177
cmuaym0o000qv71kevk9mo2g8	cmu2kzqeu00055t7mrgmescc1	Annie Sandy	+237698540126	\N	\N	2026-09-21 08:04:36.192	2026-09-21 08:04:36.192
cmuaym15n00qx71keu1i0h1dw	cmu2kzqeu00055t7mrgmescc1	Annie🎀	+237671285921	\N	\N	2026-09-21 08:04:36.827	2026-09-21 08:04:36.827
cmuaym15w00qz71keo7v9ll72	cmu2kzqeu00055t7mrgmescc1	Annie🎀	+237671285921	\N	\N	2026-09-21 08:04:36.836	2026-09-21 08:04:36.836
cmuaym1at00r171kempsvz8vi	cmu2kzqeu00055t7mrgmescc1	Antto	+237676737503	\N	\N	2026-09-21 08:04:37.013	2026-09-21 08:04:37.013
cmuaym1b300r371kewuz4txjc	cmu2kzqeu00055t7mrgmescc1	Antto	+237676737503	\N	\N	2026-09-21 08:04:37.024	2026-09-21 08:04:37.024
cmuaym1dx00r571ke1f2jh0jn	cmu2kzqeu00055t7mrgmescc1	Anty Comfort	+237677349855	\N	\N	2026-09-21 08:04:37.125	2026-09-21 08:04:37.125
cmuaym1e400r771ke2m6dm9og	cmu2kzqeu00055t7mrgmescc1	Anty Comfort	+237677349855	\N	\N	2026-09-21 08:04:37.131	2026-09-21 08:04:37.131
cmuaym1gy00r971ke96ra40ye	cmu2kzqeu00055t7mrgmescc1	Appartement 1	+237697396263	\N	\N	2026-09-21 08:04:37.235	2026-09-21 08:04:37.235
cmuaym1h500rb71keptluw24u	cmu2kzqeu00055t7mrgmescc1	Appartement 1	+237697396263	\N	\N	2026-09-21 08:04:37.242	2026-09-21 08:04:37.242
cmuaym1jj00rd71key0na34ul	cmu2kzqeu00055t7mrgmescc1	Arcelia	+237692222744	\N	\N	2026-09-21 08:04:37.327	2026-09-21 08:04:37.327
cmuaym1jr00rf71keut42kbnp	cmu2kzqeu00055t7mrgmescc1	Arcelia	+237692222744	\N	\N	2026-09-21 08:04:37.335	2026-09-21 08:04:37.335
cmuaym2j900rh71kew0k0413v	cmu2kzqeu00055t7mrgmescc1	Ariel 🔥	+237651727018	\N	\N	2026-09-21 08:04:38.613	2026-09-21 08:04:38.613
cmuaym2jh00rj71kebsmrk5lk	cmu2kzqeu00055t7mrgmescc1	Ariel 🔥	+237651727018	\N	\N	2026-09-21 08:04:38.622	2026-09-21 08:04:38.622
cmuaym2np00rl71ke0p5fa0dp	cmu2kzqeu00055t7mrgmescc1	Armel ❤️	+237640958305	\N	\N	2026-09-21 08:04:38.773	2026-09-21 08:04:38.773
cmuaym2nw00rn71ke3igvbd3k	cmu2kzqeu00055t7mrgmescc1	Armel ❤️	+237640958305	\N	\N	2026-09-21 08:04:38.78	2026-09-21 08:04:38.78
cmuaym2sn00rp71kecdr3fmas	cmu2kzqeu00055t7mrgmescc1	Arrole Ceo (Idem.Africa)	+237695404527	\N	\N	2026-09-21 08:04:38.951	2026-09-21 08:04:38.951
cmuaym2su00rr71kedvbrnq52	cmu2kzqeu00055t7mrgmescc1	Arrole Ceo (Idem.Africa)	+237695404527	\N	\N	2026-09-21 08:04:38.958	2026-09-21 08:04:38.958
cmuaym2wb00rt71kek7xw8t01	cmu2kzqeu00055t7mrgmescc1	Arthur	+237651740044	\N	\N	2026-09-21 08:04:39.084	2026-09-21 08:04:39.084
cmuaym2wj00rv71kekv2z1c2e	cmu2kzqeu00055t7mrgmescc1	Arthur	+237651740044	\N	\N	2026-09-21 08:04:39.092	2026-09-21 08:04:39.092
cmuaym2yz00rx71kem6damz3h	cmu2kzqeu00055t7mrgmescc1	Assonie📍	+237694733048	\N	\N	2026-09-21 08:04:39.179	2026-09-21 08:04:39.179
cmuaym2z700rz71kenaz70ibl	cmu2kzqeu00055t7mrgmescc1	Assonie📍	+237694733048	\N	\N	2026-09-21 08:04:39.188	2026-09-21 08:04:39.188
cmuaym31q00s171ke13dky0ix	cmu2kzqeu00055t7mrgmescc1	Atacan 2	+237670834228	\N	\N	2026-09-21 08:04:39.278	2026-09-21 08:04:39.278
cmuaym31x00s371kei7aial9x	cmu2kzqeu00055t7mrgmescc1	Atacan 2	+237670834228	\N	\N	2026-09-21 08:04:39.285	2026-09-21 08:04:39.285
cmuaym35w00s571kee7q00bgc	cmu2kzqeu00055t7mrgmescc1	Atali Hostiine	+237674169699	\N	\N	2026-09-21 08:04:39.428	2026-09-21 08:04:39.428
cmuaym36300s771kevzv1r8d7	cmu2kzqeu00055t7mrgmescc1	Atali Hostiine	+237674169699	\N	\N	2026-09-21 08:04:39.435	2026-09-21 08:04:39.435
cmuaym38r00s971keq9bfiph6	cmu2kzqeu00055t7mrgmescc1	Athalie Berenice🤗	+237693380157	\N	\N	2026-09-21 08:04:39.531	2026-09-21 08:04:39.531
cmuaym38z00sb71ke8ccft3ei	cmu2kzqeu00055t7mrgmescc1	Athalie Berenice🤗	+237693380157	\N	\N	2026-09-21 08:04:39.539	2026-09-21 08:04:39.539
cmuaym3bs00sd71keoulkyk7h	cmu2kzqeu00055t7mrgmescc1	Ati Elizabeth	+23779978803	\N	\N	2026-09-21 08:04:39.641	2026-09-21 08:04:39.641
cmuaym3c000sf71kej7e4pu2k	cmu2kzqeu00055t7mrgmescc1	Ati Elizabeth	+23779978803	\N	\N	2026-09-21 08:04:39.648	2026-09-21 08:04:39.648
cmuaym3ei00sh71kes4hcn6nz	cmu2kzqeu00055t7mrgmescc1	DNA.NKING	+237695857008	\N	\N	2026-09-21 08:04:39.738	2026-09-21 16:27:31.046
cmuaym3eo00sj71kemsomg1ul	cmu2kzqeu00055t7mrgmescc1	Audrey	+237695857008	\N	\N	2026-09-21 08:04:39.745	2026-09-21 08:04:39.745
cmuaym54s00sl71kenwoi66uf	cmu2kzqeu00055t7mrgmescc1	Auntie Sydo	+237680253552	\N	\N	2026-09-21 08:04:41.981	2026-09-21 08:04:41.981
cmuaym55500sn71kelo6dtnjm	cmu2kzqeu00055t7mrgmescc1	Auntie Sydo	+237680253552	\N	\N	2026-09-21 08:04:41.994	2026-09-21 08:04:41.994
cmuaym5kk00sp71ke98jd4ril	cmu2kzqeu00055t7mrgmescc1	Aunty  Flo	+237679195878	\N	\N	2026-09-21 08:04:42.548	2026-09-21 08:04:42.548
cmuaym5n000sr71kexw225wj0	cmu2kzqeu00055t7mrgmescc1	Aunty  Flo	+237679195878	\N	\N	2026-09-21 08:04:42.636	2026-09-21 08:04:42.636
cmuaym5w000st71ke758miwif	cmu2kzqeu00055t7mrgmescc1	Charlotte	+237677196788	\N	\N	2026-09-21 08:04:42.96	2026-09-21 16:27:28.915
cmuaym5w800sv71kejuw53enj	cmu2kzqeu00055t7mrgmescc1	Aunty Charlotte ♥️♥️🌹	+237677196788	\N	\N	2026-09-21 08:04:42.968	2026-09-21 08:04:42.968
cmuaym6b900sx71key8hw49dw	cmu2kzqeu00055t7mrgmescc1	Autorité Trésor MOUSSOKI	+242066351923	\N	\N	2026-09-21 08:04:43.509	2026-09-21 08:04:43.509
cmuaym6bh00sz71kelg2dgxnh	cmu2kzqeu00055t7mrgmescc1	Autorité Trésor MOUSSOKI	+242066351923	\N	\N	2026-09-21 08:04:43.517	2026-09-21 08:04:43.517
cmuaym6ff00t171ked4odje95	cmu2kzqeu00055t7mrgmescc1	Awa Brandon A.	+237658119167	\N	\N	2026-09-21 08:04:43.66	2026-09-21 08:04:43.66
cmuaym6fq00t371keiqojb4gh	cmu2kzqeu00055t7mrgmescc1	Awa Brandon A.	+237658119167	\N	\N	2026-09-21 08:04:43.67	2026-09-21 08:04:43.67
cmuaym6n700t571keowg35t0m	cmu2kzqeu00055t7mrgmescc1	Ayissi	+237696844098	\N	\N	2026-09-21 08:04:43.94	2026-09-21 08:04:43.94
cmuaym6ng00t771kegkd1xgyp	cmu2kzqeu00055t7mrgmescc1	Ayissi	+237696844098	\N	\N	2026-09-21 08:04:43.948	2026-09-21 08:04:43.948
cmuaym6xc00t971kecz7xwf6b	cmu2kzqeu00055t7mrgmescc1	Ayong	+12409702028	\N	\N	2026-09-21 08:04:44.304	2026-09-21 08:04:44.304
cmuaym6y000tb71kewci8mlb1	cmu2kzqeu00055t7mrgmescc1	Ayong	+12409702028	\N	\N	2026-09-21 08:04:44.328	2026-09-21 08:04:44.328
cmuaym77r00td71keds80zkd2	cmu2kzqeu00055t7mrgmescc1	Ayoola DC	+2349128738973	\N	\N	2026-09-21 08:04:44.679	2026-09-21 08:04:44.679
cmuaym78300tf71kedi72ffvl	cmu2kzqeu00055t7mrgmescc1	Ayoola DC	+2349128738973	\N	\N	2026-09-21 08:04:44.692	2026-09-21 08:04:44.692
cmuaym7uf00th71kejmlf4jth	cmu2kzqeu00055t7mrgmescc1	Ayuk Etta	+23776101785	\N	\N	2026-09-21 08:04:45.495	2026-09-21 08:04:45.495
cmuaym7uu00tj71kegbga3x49	cmu2kzqeu00055t7mrgmescc1	Ayuk Etta	+23776101785	\N	\N	2026-09-21 08:04:45.51	2026-09-21 08:04:45.51
cmuaym83r00tl71kegdh5e8wt	cmu2kzqeu00055t7mrgmescc1	Azinwi 👾	+237690709635	\N	\N	2026-09-21 08:04:45.831	2026-09-21 08:04:45.831
cmuaym84500tn71kewlgvmm33	cmu2kzqeu00055t7mrgmescc1	Azinwi 👾	+237690709635	\N	\N	2026-09-21 08:04:45.845	2026-09-21 08:04:45.845
cmuaym8c100tp71ke9hkp4ixv	cmu2kzqeu00055t7mrgmescc1	Aziz	+237675719158	\N	\N	2026-09-21 08:04:46.129	2026-09-21 08:04:46.129
cmuaym8ci00tr71ke6crte634	cmu2kzqeu00055t7mrgmescc1	Aziz	+237675719158	\N	\N	2026-09-21 08:04:46.146	2026-09-21 08:04:46.146
cmuaym8lp00tt71kep5xa3g5g	cmu2kzqeu00055t7mrgmescc1	BIG WANTED Uk🇮🇸	+237651180323	\N	\N	2026-09-21 08:04:46.477	2026-09-21 08:04:46.477
cmuaym8m200tv71keymgd9f7t	cmu2kzqeu00055t7mrgmescc1	BIG WANTED Uk🇮🇸	+237651180323	\N	\N	2026-09-21 08:04:46.49	2026-09-21 08:04:46.49
cmuaym8u500tx71kes65c2ffz	cmu2kzqeu00055t7mrgmescc1	BRAYAN NKOM 🧞‍♂️🧠	+237695759207	\N	\N	2026-09-21 08:04:46.781	2026-09-21 08:04:46.781
cmuaym8ug00tz71ke5rs9uqi1	cmu2kzqeu00055t7mrgmescc1	BRAYAN NKOM 🧞‍♂️🧠	+237695759207	\N	\N	2026-09-21 08:04:46.792	2026-09-21 08:04:46.792
cmuaym9cn00u171kecvcnlw6t	cmu2kzqeu00055t7mrgmescc1	BURUS	+237695212008	\N	\N	2026-09-21 08:04:47.447	2026-09-21 08:04:47.447
cmuaym9f800u371ke9idlamt4	cmu2kzqeu00055t7mrgmescc1	BURUS	+237695212008	\N	\N	2026-09-21 08:04:47.54	2026-09-21 08:04:47.54
cmuaym9m800u571keqa3pwm97	cmu2kzqeu00055t7mrgmescc1	Bah Emmanuel Kimeh	+237652370661	\N	\N	2026-09-21 08:04:47.792	2026-09-21 08:04:47.792
cmuaym9mm00u771ke828k70fi	cmu2kzqeu00055t7mrgmescc1	Bah Emmanuel Kimeh	+237652370661	\N	\N	2026-09-21 08:04:47.806	2026-09-21 08:04:47.806
cmuayma6600u971keukksg407	cmu2kzqeu00055t7mrgmescc1	Bahuma	+233536859133	\N	\N	2026-09-21 08:04:48.51	2026-09-21 08:04:48.51
cmuayma7x00ub71ke45an5jqo	cmu2kzqeu00055t7mrgmescc1	Bahuma	+233536859133	\N	\N	2026-09-21 08:04:48.573	2026-09-21 08:04:48.573
cmuaymadf00ud71ke9kawnj3s	cmu2kzqeu00055t7mrgmescc1	Franck La Carrure 🪫🖤	+237656965320	\N	\N	2026-09-21 08:04:48.771	2026-09-21 16:27:37.676
cmuaymae100uf71kexguwqpwa	cmu2kzqeu00055t7mrgmescc1	Bb Maeva ❤️🥹	+237656965320	\N	\N	2026-09-21 08:04:48.793	2026-09-21 08:04:48.793
cmuaymajz00uh71ke0g1zfc6r	cmu2kzqeu00055t7mrgmescc1	Erick Ngongang	+237659639978	\N	\N	2026-09-21 08:04:49.007	2026-09-21 16:27:36.038
cmuaymak700uj71kewatz492b	cmu2kzqeu00055t7mrgmescc1	Bby❤️🥹	+237659639978	\N	\N	2026-09-21 08:04:49.015	2026-09-21 08:04:49.015
cmuaymaor00ul71ke0dhepq8q	cmu2kzqeu00055t7mrgmescc1	Be Wise Fondator	+237673419058	\N	\N	2026-09-21 08:04:49.179	2026-09-21 08:04:49.179
cmuaymap700un71ke287b452p	cmu2kzqeu00055t7mrgmescc1	Be Wise Fondator	+237673419058	\N	\N	2026-09-21 08:04:49.195	2026-09-21 08:04:49.195
cmuaymavi00up71kepyjdfgrt	cmu2kzqeu00055t7mrgmescc1	Beads By Marian	+237673463912	\N	\N	2026-09-21 08:04:49.422	2026-09-21 08:04:49.422
cmuaymawk00ur71kevcl1xj6s	cmu2kzqeu00055t7mrgmescc1	Beads By Marian	+237673463912	\N	\N	2026-09-21 08:04:49.46	2026-09-21 08:04:49.46
cmuaymb7x00ut71ke3gx7cal6	cmu2kzqeu00055t7mrgmescc1	Bella	+237653926198	\N	\N	2026-09-21 08:04:49.869	2026-09-21 08:04:49.869
cmuaymb8600uv71keclq8kw46	cmu2kzqeu00055t7mrgmescc1	Bella	+237653926198	\N	\N	2026-09-21 08:04:49.878	2026-09-21 08:04:49.878
cmuaymbeh00ux71kevyw04l90	cmu2kzqeu00055t7mrgmescc1	Bella	+237675894964	\N	\N	2026-09-21 08:04:50.106	2026-09-21 08:04:50.106
cmuaymbep00uz71kete3p6bau	cmu2kzqeu00055t7mrgmescc1	Bella	+237675894964	\N	\N	2026-09-21 08:04:50.113	2026-09-21 08:04:50.113
cmuaymbi800v171kelx8uwiwi	cmu2kzqeu00055t7mrgmescc1	Bella❤️🔥🦋fanny	+237658156524	\N	\N	2026-09-21 08:04:50.24	2026-09-21 08:04:50.24
cmuaymbif00v371kew8ilkv1m	cmu2kzqeu00055t7mrgmescc1	Bella❤️🔥🦋fanny	+237658156524	\N	\N	2026-09-21 08:04:50.248	2026-09-21 08:04:50.248
cmuaymbme00v571keguwwy94e	cmu2kzqeu00055t7mrgmescc1	Belone	+237671320393	\N	\N	2026-09-21 08:04:50.39	2026-09-21 08:04:50.39
cmuaymbmm00v771ke6ct66voe	cmu2kzqeu00055t7mrgmescc1	Belone	+237671320393	\N	\N	2026-09-21 08:04:50.398	2026-09-21 08:04:50.398
cmuaymbqg00v971ke2wgrk9sl	cmu2kzqeu00055t7mrgmescc1	Ben Daoud🧠🇦🇩🇨🇲🇨🇵	+237696680360	\N	\N	2026-09-21 08:04:50.536	2026-09-21 08:04:50.536
cmuaymbqn00vb71keroe2f4cx	cmu2kzqeu00055t7mrgmescc1	Ben Daoud🧠🇦🇩🇨🇲🇨🇵	+237696680360	\N	\N	2026-09-21 08:04:50.543	2026-09-21 08:04:50.543
cmuaymbus00vd71keya2sl8b7	cmu2kzqeu00055t7mrgmescc1	Benie first son	+237680478635	\N	\N	2026-09-21 08:04:50.692	2026-09-21 08:04:50.692
cmuaymbuz00vf71ke9rpzaxno	cmu2kzqeu00055t7mrgmescc1	Benie first son	+237680478635	\N	\N	2026-09-21 08:04:50.699	2026-09-21 08:04:50.699
cmuaymbyo00vh71ke66b9pnyj	cmu2kzqeu00055t7mrgmescc1	Benista	+237691441261	\N	\N	2026-09-21 08:04:50.832	2026-09-21 08:04:50.832
cmuaymbyw00vj71ke1eqdxuo8	cmu2kzqeu00055t7mrgmescc1	Benista	+237691441261	\N	\N	2026-09-21 08:04:50.84	2026-09-21 08:04:50.84
cmuaymc2j00vl71keamidaqpc	cmu2kzqeu00055t7mrgmescc1	Benny Boy	+237683411917	\N	\N	2026-09-21 08:04:50.971	2026-09-21 08:04:50.971
cmuaymc2r00vn71keegtnjoqf	cmu2kzqeu00055t7mrgmescc1	Benny Boy	+237683411917	\N	\N	2026-09-21 08:04:50.98	2026-09-21 08:04:50.98
cmuaymchf00vp71keazs8oizc	cmu2kzqeu00055t7mrgmescc1	Bercky🍇	+237683264159	\N	\N	2026-09-21 08:04:51.507	2026-09-21 08:04:51.507
cmuaymcoy00vr71ketyx8e93t	cmu2kzqeu00055t7mrgmescc1	Bercky🍇	+237683264159	\N	\N	2026-09-21 08:04:51.778	2026-09-21 08:04:51.778
cmuaymd2m00vt71keh5zf4mqq	cmu2kzqeu00055t7mrgmescc1	Bethel🤳🏽	+237679436328	\N	\N	2026-09-21 08:04:52.27	2026-09-21 08:04:52.27
cmuaymd3400vv71keu4d333f4	cmu2kzqeu00055t7mrgmescc1	Bethel🤳🏽	+237679436328	\N	\N	2026-09-21 08:04:52.288	2026-09-21 08:04:52.288
cmuaymdao00vx71kepfr6rhhv	cmu2kzqeu00055t7mrgmescc1	Bibinailsart	+237696943716	\N	\N	2026-09-21 08:04:52.561	2026-09-21 08:04:52.561
cmuaymday00vz71kezzl5mj3b	cmu2kzqeu00055t7mrgmescc1	Bibinailsart	+237696943716	\N	\N	2026-09-21 08:04:52.57	2026-09-21 08:04:52.57
cmuaymdf600w171kextd3ut7a	cmu2kzqeu00055t7mrgmescc1	Big Boss Rajour	+237650505824	\N	\N	2026-09-21 08:04:52.722	2026-09-21 08:04:52.722
cmuaymdfd00w371kew1s6b0bc	cmu2kzqeu00055t7mrgmescc1	Big Boss Rajour	+237650505824	\N	\N	2026-09-21 08:04:52.729	2026-09-21 08:04:52.729
cmuaymdjd00w571ke8aivtcnr	cmu2kzqeu00055t7mrgmescc1	Big Fish	+237640252148	\N	\N	2026-09-21 08:04:52.873	2026-09-21 08:04:52.873
cmuaymdjk00w771kevbahv9mh	cmu2kzqeu00055t7mrgmescc1	Big Fish	+237640252148	\N	\N	2026-09-21 08:04:52.88	2026-09-21 08:04:52.88
cmuaymdqb00w971kehcmtkd2c	cmu2kzqeu00055t7mrgmescc1	Bill	+237694592772	\N	\N	2026-09-21 08:04:53.123	2026-09-21 08:04:53.123
cmuaymdqo00wb71ke83ik6tkc	cmu2kzqeu00055t7mrgmescc1	Bill	+237694592772	\N	\N	2026-09-21 08:04:53.136	2026-09-21 08:04:53.136
cmuaymdvs00wd71kei0snhjo6	cmu2kzqeu00055t7mrgmescc1	Bill 4tune🤳🏽	+237686144812	\N	\N	2026-09-21 08:04:53.32	2026-09-21 08:04:53.32
cmuaymdw200wf71kecif0m7kk	cmu2kzqeu00055t7mrgmescc1	Bill 4tune🤳🏽	+237686144812	\N	\N	2026-09-21 08:04:53.33	2026-09-21 08:04:53.33
cmuayme2000wh71ke3944qzbo	cmu2kzqeu00055t7mrgmescc1	Billie inz 💎	+237674426269	\N	\N	2026-09-21 08:04:53.544	2026-09-21 08:04:53.544
cmuayme2e00wj71key3jbm6x6	cmu2kzqeu00055t7mrgmescc1	Billie inz 💎	+237674426269	\N	\N	2026-09-21 08:04:53.558	2026-09-21 08:04:53.558
cmuayme9800wl71kehsmjyoeh	cmu2kzqeu00055t7mrgmescc1	Bily 229 Gr	+22942603293	\N	\N	2026-09-21 08:04:53.804	2026-09-21 08:04:53.804
cmuayme9l00wn71ke9pvk06ma	cmu2kzqeu00055t7mrgmescc1	Bily 229 Gr	+22942603293	\N	\N	2026-09-21 08:04:53.817	2026-09-21 08:04:53.817
cmuaymeel00wp71kenq5vjuhx	cmu2kzqeu00055t7mrgmescc1	Blanche Bailly	+237652692953	\N	\N	2026-09-21 08:04:53.997	2026-09-21 08:04:53.997
cmuaymeez00wr71ke48ow3n8e	cmu2kzqeu00055t7mrgmescc1	Blanche Bailly	+237652692953	\N	\N	2026-09-21 08:04:54.011	2026-09-21 08:04:54.011
cmuaymeij00wt71kehunlqrdk	cmu2kzqeu00055t7mrgmescc1	Blanche 💟	+237658004477	\N	\N	2026-09-21 08:04:54.139	2026-09-21 08:04:54.139
cmuaymeix00wv71kevtxue572	cmu2kzqeu00055t7mrgmescc1	Blanche 💟	+237658004477	\N	\N	2026-09-21 08:04:54.153	2026-09-21 08:04:54.153
cmuaymemf00wx71kev4wspcgr	cmu2kzqeu00055t7mrgmescc1	Bless	+237674336020	\N	\N	2026-09-21 08:04:54.279	2026-09-21 08:04:54.279
cmuaymemr00wz71keg2a4nypp	cmu2kzqeu00055t7mrgmescc1	Bless	+237674336020	\N	\N	2026-09-21 08:04:54.292	2026-09-21 08:04:54.292
cmuaymeqr00x171kee49zxjxs	cmu2kzqeu00055t7mrgmescc1	Blessing 🥰😘🥰	+237680674972	\N	\N	2026-09-21 08:04:54.435	2026-09-21 08:04:54.435
cmuaymeqy00x371kevya9rtws	cmu2kzqeu00055t7mrgmescc1	Blessing 🥰😘🥰	+237680674972	\N	\N	2026-09-21 08:04:54.443	2026-09-21 08:04:54.443
cmuaymfbs00x571kejzf5ld5g	cmu2kzqeu00055t7mrgmescc1	Blonde pretty	+237680493759	\N	\N	2026-09-21 08:04:55.193	2026-09-21 08:04:55.193
cmuaymfdj00x771kej73tvh5f	cmu2kzqeu00055t7mrgmescc1	Blonde pretty	+237680493759	\N	\N	2026-09-21 08:04:55.255	2026-09-21 08:04:55.255
cmuaymfkm00x971kedjm1wvs3	cmu2kzqeu00055t7mrgmescc1	Blondel New Bell🍀	+237698629876	\N	\N	2026-09-21 08:04:55.51	2026-09-21 08:04:55.51
cmuaymfkz00xb71keuenmhkni	cmu2kzqeu00055t7mrgmescc1	Blondel New Bell🍀	+237698629876	\N	\N	2026-09-21 08:04:55.523	2026-09-21 08:04:55.523
cmuaymfom00xd71keiu40o43m	cmu2kzqeu00055t7mrgmescc1	Blood Agent	+237656525240	\N	\N	2026-09-21 08:04:55.654	2026-09-21 08:04:55.654
cmuaymfot00xf71key54u1tif	cmu2kzqeu00055t7mrgmescc1	Blood Agent	+237656525240	\N	\N	2026-09-21 08:04:55.662	2026-09-21 08:04:55.662
cmuaymfsg00xh71ke5g3dqk1n	cmu2kzqeu00055t7mrgmescc1	Borel	+237620512903	\N	\N	2026-09-21 08:04:55.792	2026-09-21 08:04:55.792
cmuaymfst00xj71keuo3m869t	cmu2kzqeu00055t7mrgmescc1	Borel	+237620512903	\N	\N	2026-09-21 08:04:55.806	2026-09-21 08:04:55.806
cmuaymg3o00xl71keqemtzqmm	cmu2kzqeu00055t7mrgmescc1	Borel G✳️	+237680038011	\N	\N	2026-09-21 08:04:56.196	2026-09-21 08:04:56.196
cmuaymg3x00xn71keuw7inrkk	cmu2kzqeu00055t7mrgmescc1	Borel G✳️	+237680038011	\N	\N	2026-09-21 08:04:56.205	2026-09-21 08:04:56.205
cmuaymg7h00xp71kejx19go4h	cmu2kzqeu00055t7mrgmescc1	Bos Neighbor	+237674667891	\N	\N	2026-09-21 08:04:56.334	2026-09-21 08:04:56.334
cmuaymg7p00xr71ke9o71pohc	cmu2kzqeu00055t7mrgmescc1	Bos Neighbor	+237674667891	\N	\N	2026-09-21 08:04:56.341	2026-09-21 08:04:56.341
cmuaymgcx00xt71keodwoytf9	cmu2kzqeu00055t7mrgmescc1	Mrcomplique	+237693460847	\N	\N	2026-09-21 08:04:56.529	2026-09-21 16:27:58.188
cmuaymgd700xv71kevkbvwoez	cmu2kzqeu00055t7mrgmescc1	Brahim	+237693460847	\N	\N	2026-09-21 08:04:56.539	2026-09-21 08:04:56.539
cmuaymgic00xx71keelj4aqrv	cmu2kzqeu00055t7mrgmescc1	Brandon	+237671616229	\N	\N	2026-09-21 08:04:56.724	2026-09-21 08:04:56.724
cmuaymgim00xz71keootfhp6z	cmu2kzqeu00055t7mrgmescc1	Brandon	+237671616229	\N	\N	2026-09-21 08:04:56.734	2026-09-21 08:04:56.734
cmuaymgnj00y171ke7t0mlvur	cmu2kzqeu00055t7mrgmescc1	Brandy	+237622006096	\N	\N	2026-09-21 08:04:56.911	2026-09-21 08:04:56.911
cmuaymgo800y371kebzpj1ds3	cmu2kzqeu00055t7mrgmescc1	Brandy	+237622006096	\N	\N	2026-09-21 08:04:56.936	2026-09-21 08:04:56.936
cmuaymguu00y571kefro9x6oe	cmu2kzqeu00055t7mrgmescc1	Brayant	+237671567078	\N	\N	2026-09-21 08:04:57.174	2026-09-21 08:04:57.174
cmuaymgv500y771keulfqv8fd	cmu2kzqeu00055t7mrgmescc1	Brayant	+237671567078	\N	\N	2026-09-21 08:04:57.186	2026-09-21 08:04:57.186
cmuaymh0s00y971ke5xtj42u3	cmu2kzqeu00055t7mrgmescc1	Brenda Eyong	+237653123844	\N	\N	2026-09-21 08:04:57.388	2026-09-21 08:04:57.388
cmuaymh0z00yb71kep19h3qvn	cmu2kzqeu00055t7mrgmescc1	Brenda Eyong	+237653123844	\N	\N	2026-09-21 08:04:57.395	2026-09-21 08:04:57.395
cmuaymh6700yd71ke4da8v6ki	cmu2kzqeu00055t7mrgmescc1	Brenda Njayou 🇨🇲	+237692012463	\N	\N	2026-09-21 08:04:57.583	2026-09-21 08:04:57.583
cmuaymh6n00yf71kerseixl8j	cmu2kzqeu00055t7mrgmescc1	Brenda Njayou 🇨🇲	+237692012463	\N	\N	2026-09-21 08:04:57.6	2026-09-21 08:04:57.6
cmuaymhch00yh71keqqykpwsc	cmu2kzqeu00055t7mrgmescc1	Brenda 🌟	+237683382619	\N	\N	2026-09-21 08:04:57.81	2026-09-21 08:04:57.81
cmuaymhcu00yj71ke79fhy4ig	cmu2kzqeu00055t7mrgmescc1	Brenda 🌟	+237683382619	\N	\N	2026-09-21 08:04:57.822	2026-09-21 08:04:57.822
cmuaymhi900yl71keog32l54f	cmu2kzqeu00055t7mrgmescc1	Brian	+237651588107	\N	\N	2026-09-21 08:04:58.017	2026-09-21 08:04:58.017
cmuaymhig00yn71kei669c8nd	cmu2kzqeu00055t7mrgmescc1	Brian	+237651588107	\N	\N	2026-09-21 08:04:58.025	2026-09-21 08:04:58.025
cmuaymhml00yp71ke771naw76	cmu2kzqeu00055t7mrgmescc1	Brice	+237651021324	\N	\N	2026-09-21 08:04:58.174	2026-09-21 08:04:58.174
cmuaymhmt00yr71keyeue15mw	cmu2kzqeu00055t7mrgmescc1	Brice	+237651021324	\N	\N	2026-09-21 08:04:58.182	2026-09-21 08:04:58.182
cmuaymhs100yt71ke67tsqg6q	cmu2kzqeu00055t7mrgmescc1	Bro	+237671907838	\N	\N	2026-09-21 08:04:58.369	2026-09-21 08:04:58.369
cmuaymhse00yv71ke6g5lewlu	cmu2kzqeu00055t7mrgmescc1	Bro	+237671907838	\N	\N	2026-09-21 08:04:58.382	2026-09-21 08:04:58.382
cmuaymhws00yx71kev5vd2loc	cmu2kzqeu00055t7mrgmescc1	Bro Clovis	+237670543996	\N	\N	2026-09-21 08:04:58.541	2026-09-21 08:04:58.541
cmuaymhx300yz71ke2po1s2ch	cmu2kzqeu00055t7mrgmescc1	Bro Clovis	+237670543996	\N	\N	2026-09-21 08:04:58.551	2026-09-21 08:04:58.551
cmuaymi8w00z171kerikq99gh	cmu2kzqeu00055t7mrgmescc1	+212661500516	+212661500516	\N	\N	2026-09-21 08:04:58.976	2026-09-21 16:28:19.88
cmuaymi9600z371keei2dby0q	cmu2kzqeu00055t7mrgmescc1	Bro Key	+212661500516	\N	\N	2026-09-21 08:04:58.987	2026-09-21 08:04:58.987
cmuaymidh00z571kerwslqnbt	cmu2kzqeu00055t7mrgmescc1	Bro Luc	+237679776841	\N	\N	2026-09-21 08:04:59.141	2026-09-21 08:04:59.141
cmuaymidq00z771kexsdap8d3	cmu2kzqeu00055t7mrgmescc1	Bro Luc	+237679776841	\N	\N	2026-09-21 08:04:59.15	2026-09-21 08:04:59.15
cmuaymipk00z971kegpj9r75v	cmu2kzqeu00055t7mrgmescc1	Bro Reuben	+237655712366	\N	\N	2026-09-21 08:04:59.576	2026-09-21 08:04:59.576
cmuaymipv00zb71kera1mq1zr	cmu2kzqeu00055t7mrgmescc1	Bro Reuben	+237655712366	\N	\N	2026-09-21 08:04:59.588	2026-09-21 08:04:59.588
cmuaymiub00zd71kele5pqvbp	cmu2kzqeu00055t7mrgmescc1	Brother Augustine	+13014088293	\N	\N	2026-09-21 08:04:59.747	2026-09-21 08:04:59.747
cmuaymiuk00zf71kex3ixz7z1	cmu2kzqeu00055t7mrgmescc1	Brother Augustine	+13014088293	\N	\N	2026-09-21 08:04:59.756	2026-09-21 08:04:59.756
cmuaymiya00zh71ke4j1m6x2m	cmu2kzqeu00055t7mrgmescc1	Emma-Empire	+237679163945	\N	\N	2026-09-21 08:04:59.89	2026-09-21 16:27:34.934
cmuaymiyk00zj71kea59jnsp9	cmu2kzqeu00055t7mrgmescc1	Brother Emanuel Emmanuel CEM	+237679163945	\N	\N	2026-09-21 08:04:59.9	2026-09-21 08:04:59.9
cmuaymj3b00zl71kedu15ivw5	cmu2kzqeu00055t7mrgmescc1	Brother Glee😁	+237695737008	\N	\N	2026-09-21 08:05:00.072	2026-09-21 08:05:00.072
cmuaymj3i00zn71kes1u2mek5	cmu2kzqeu00055t7mrgmescc1	Brother Glee😁	+237695737008	\N	\N	2026-09-21 08:05:00.078	2026-09-21 08:05:00.078
cmuaymj7r00zp71ke70nvbmge	cmu2kzqeu00055t7mrgmescc1	Bruh	+237656619984	\N	\N	2026-09-21 08:05:00.231	2026-09-21 08:05:00.231
cmuaymj8000zr71kenftbt9od	cmu2kzqeu00055t7mrgmescc1	Bruh	+237656619984	\N	\N	2026-09-21 08:05:00.24	2026-09-21 08:05:00.24
cmuaymjbl00zt71keiqkz31hh	cmu2kzqeu00055t7mrgmescc1	Buma Lawrence	+237683153983	\N	\N	2026-09-21 08:05:00.37	2026-09-21 08:05:00.37
cmuaymjbx00zv71ke31cmu9tz	cmu2kzqeu00055t7mrgmescc1	Buma Lawrence	+237683153983	\N	\N	2026-09-21 08:05:00.381	2026-09-21 08:05:00.381
cmuaymjfw00zx71kehn8so15r	cmu2kzqeu00055t7mrgmescc1	Sylvie❤️	+237694978953	\N	\N	2026-09-21 08:05:00.524	2026-09-21 16:28:10.812
cmuaymjg500zz71kemvef8jxc	cmu2kzqeu00055t7mrgmescc1	Business Uniquement 💰	+237694978953	\N	\N	2026-09-21 08:05:00.533	2026-09-21 08:05:00.533
cmuaymjkl010171kehw67o7a8	cmu2kzqeu00055t7mrgmescc1	Bẽãũțĩfũl Tẽmptãtįøn🤳🏽	+237682515664	\N	\N	2026-09-21 08:05:00.693	2026-09-21 08:05:00.693
cmuaymjku010371kezx2jsig3	cmu2kzqeu00055t7mrgmescc1	Bẽãũțĩfũl Tẽmptãtįøn🤳🏽	+237682515664	\N	\N	2026-09-21 08:05:00.702	2026-09-21 08:05:00.702
cmuaymjoo010571kez22bhrlm	cmu2kzqeu00055t7mrgmescc1	CASH	+237681587147	\N	\N	2026-09-21 08:05:00.84	2026-09-21 08:05:00.84
cmuaymjov010771kee276brc2	cmu2kzqeu00055t7mrgmescc1	CASH	+237681587147	\N	\N	2026-09-21 08:05:00.847	2026-09-21 08:05:00.847
cmuaymjsp010971keeux22e28	cmu2kzqeu00055t7mrgmescc1	CHU Ada	+237698276611	\N	\N	2026-09-21 08:05:00.985	2026-09-21 08:05:00.985
cmuaymjsw010b71keas96aern	cmu2kzqeu00055t7mrgmescc1	CHU Ada	+237698276611	\N	\N	2026-09-21 08:05:00.992	2026-09-21 08:05:00.992
cmuaymjx0010d71ke3xrav7qf	cmu2kzqeu00055t7mrgmescc1	Caleb	+237656055155	\N	\N	2026-09-21 08:05:01.14	2026-09-21 08:05:01.14
cmuaymjxb010f71kekhs7bskw	cmu2kzqeu00055t7mrgmescc1	Caleb	+237656055155	\N	\N	2026-09-21 08:05:01.151	2026-09-21 08:05:01.151
cmuaymk1l010h71kexd0opi71	cmu2kzqeu00055t7mrgmescc1	Calista	+237653830644	\N	\N	2026-09-21 08:05:01.305	2026-09-21 08:05:01.305
cmuaymk1s010j71kerch24v37	cmu2kzqeu00055t7mrgmescc1	Calista	+237653830644	\N	\N	2026-09-21 08:05:01.312	2026-09-21 08:05:01.312
cmuaymk5u010l71kevlbgpkbc	cmu2kzqeu00055t7mrgmescc1	Calvin	+237679841576	\N	\N	2026-09-21 08:05:01.458	2026-09-21 08:05:01.458
cmuaymk65010n71kesh7d8oip	cmu2kzqeu00055t7mrgmescc1	Calvin	+237679841576	\N	\N	2026-09-21 08:05:01.469	2026-09-21 08:05:01.469
cmuaymkad010p71kelc5e27we	cmu2kzqeu00055t7mrgmescc1	Calvin Summer Challenge	+237699948671	\N	\N	2026-09-21 08:05:01.621	2026-09-21 16:27:28.38
cmuaymkak010r71kelvmduqzh	cmu2kzqeu00055t7mrgmescc1	Calvin KDA Osc	+237699948671	\N	\N	2026-09-21 08:05:01.629	2026-09-21 08:05:01.629
cmuaymkgj010t71kem1fi24sw	cmu2kzqeu00055t7mrgmescc1	Capreen ❤️	+237671961958	\N	\N	2026-09-21 08:05:01.844	2026-09-21 08:05:01.844
cmuaymkgu010v71ke2ogj1glk	cmu2kzqeu00055t7mrgmescc1	Capreen ❤️	+237671961958	\N	\N	2026-09-21 08:05:01.854	2026-09-21 08:05:01.854
cmuaymklo010x71ke3szyt4xe	cmu2kzqeu00055t7mrgmescc1	Carla Nk 😘	+237692743342	\N	\N	2026-09-21 08:05:02.028	2026-09-21 08:05:02.028
cmuaymklz010z71ket6nbvdlu	cmu2kzqeu00055t7mrgmescc1	Carla Nk 😘	+237692743342	\N	\N	2026-09-21 08:05:02.039	2026-09-21 08:05:02.039
cmuaymkqk011171keko15oln8	cmu2kzqeu00055t7mrgmescc1	Cassandra ☘️	+237672533220	\N	\N	2026-09-21 08:05:02.204	2026-09-21 08:05:02.204
cmuaymkqr011371ke4fnfhmdd	cmu2kzqeu00055t7mrgmescc1	Cassandra ☘️	+237672533220	\N	\N	2026-09-21 08:05:02.211	2026-09-21 08:05:02.211
cmuaymkuo011571ke62pewcyy	cmu2kzqeu00055t7mrgmescc1	Cassandra✨	+237693423786	\N	\N	2026-09-21 08:05:02.352	2026-09-21 08:05:02.352
cmuaymkuv011771keax4tead8	cmu2kzqeu00055t7mrgmescc1	Cassandra✨	+237693423786	\N	\N	2026-09-21 08:05:02.359	2026-09-21 08:05:02.359
cmuayml24011971ke63lrq8zv	cmu2kzqeu00055t7mrgmescc1	Castine	+23777738928	\N	\N	2026-09-21 08:05:02.62	2026-09-21 08:05:02.62
cmuayml2k011b71ke7bryceu2	cmu2kzqeu00055t7mrgmescc1	Castine	+23777738928	\N	\N	2026-09-21 08:05:02.636	2026-09-21 08:05:02.636
cmuayml88011d71ke2d7dbqeb	cmu2kzqeu00055t7mrgmescc1	Cayamata	+2370264299071	\N	\N	2026-09-21 08:05:02.84	2026-09-21 08:05:02.84
cmuayml8i011f71ke7lmc4amx	cmu2kzqeu00055t7mrgmescc1	Cayamata	+2370264299071	\N	\N	2026-09-21 08:05:02.85	2026-09-21 08:05:02.85
cmuaymlcb011h71ke3isoi8m5	cmu2kzqeu00055t7mrgmescc1	Celeste Ruth	+237680673854	\N	\N	2026-09-21 08:05:02.988	2026-09-21 08:05:02.988
cmuaymlck011j71keflm7fftr	cmu2kzqeu00055t7mrgmescc1	Celeste Ruth	+237680673854	\N	\N	2026-09-21 08:05:02.996	2026-09-21 08:05:02.996
cmuaymlg1011l71kedjbbnhw5	cmu2kzqeu00055t7mrgmescc1	Cena	+2347085763559	\N	\N	2026-09-21 08:05:03.122	2026-09-21 08:05:03.122
cmuaymlg9011n71kebnhn5whk	cmu2kzqeu00055t7mrgmescc1	Cena	+2347085763559	\N	\N	2026-09-21 08:05:03.129	2026-09-21 08:05:03.129
cmuaymlvt011p71kew3z9iixz	cmu2kzqeu00055t7mrgmescc1	Chanelle	+237682154454	\N	\N	2026-09-21 08:05:03.689	2026-09-21 08:05:03.689
cmuaymlwo011r71kex61vueyv	cmu2kzqeu00055t7mrgmescc1	Chanelle	+237682154454	\N	\N	2026-09-21 08:05:03.72	2026-09-21 08:05:03.72
cmuaymm3z011t71ke1kuvcpc4	cmu2kzqeu00055t7mrgmescc1	Chanou Makilo	+23675967842	\N	\N	2026-09-21 08:05:03.983	2026-09-21 08:05:03.983
cmuaymm48011v71ke7tngra42	cmu2kzqeu00055t7mrgmescc1	Chanou Makilo	+23675967842	\N	\N	2026-09-21 08:05:03.992	2026-09-21 08:05:03.992
cmuaymmck011x71kez2o7ouft	cmu2kzqeu00055t7mrgmescc1	Charlys	+237659336515	\N	\N	2026-09-21 08:05:04.292	2026-09-21 08:05:04.292
cmuaymmct011z71ke63sbyj98	cmu2kzqeu00055t7mrgmescc1	Charlys	+237659336515	\N	\N	2026-09-21 08:05:04.301	2026-09-21 08:05:04.301
cmuaymmg8012171ketd4s2cgs	cmu2kzqeu00055t7mrgmescc1	Charo Dollars💸💸💵💵	+237640605605	\N	\N	2026-09-21 08:05:04.424	2026-09-21 08:05:04.424
cmuaymmgk012371keu9hmtrka	cmu2kzqeu00055t7mrgmescc1	Charo Dollars💸💸💵💵	+237640605605	\N	\N	2026-09-21 08:05:04.437	2026-09-21 08:05:04.437
cmuaymmku012571kexbpxrqz0	cmu2kzqeu00055t7mrgmescc1	Chloé Noubissi	+237658099400	\N	\N	2026-09-21 08:05:04.59	2026-09-21 08:05:04.59
cmuaymml5012771kee9cnfiux	cmu2kzqeu00055t7mrgmescc1	Chloé Noubissi	+237658099400	\N	\N	2026-09-21 08:05:04.601	2026-09-21 08:05:04.601
cmuaymmp0012971keu8f6ny4r	cmu2kzqeu00055t7mrgmescc1	Choco	+237656914522	\N	\N	2026-09-21 08:05:04.741	2026-09-21 08:05:04.741
cmuaymmp8012b71kedyea9u7s	cmu2kzqeu00055t7mrgmescc1	Choco	+237656914522	\N	\N	2026-09-21 08:05:04.748	2026-09-21 08:05:04.748
cmuaymmsh012d71ke7g0w5v33	cmu2kzqeu00055t7mrgmescc1	Chocolat blanc ❤️‍🩹🤣🤍✝️🎭	+2250500451580	\N	\N	2026-09-21 08:05:04.865	2026-09-21 08:05:04.865
cmuaymmsp012f71ke0al7pcb7	cmu2kzqeu00055t7mrgmescc1	Chocolat blanc ❤️‍🩹🤣🤍✝️🎭	+2250500451580	\N	\N	2026-09-21 08:05:04.873	2026-09-21 08:05:04.873
cmuaymmyk012h71ke9s7b6ke6	cmu2kzqeu00055t7mrgmescc1	Chrinovic Keys	+237975452884	\N	\N	2026-09-21 08:05:05.084	2026-09-21 08:05:05.084
cmuaymmyr012j71kec14t7kwx	cmu2kzqeu00055t7mrgmescc1	Chrinovic Keys	+237975452884	\N	\N	2026-09-21 08:05:05.091	2026-09-21 08:05:05.091
cmuaymn1y012l71ke5f9efre8	cmu2kzqeu00055t7mrgmescc1	Christelle	+237657785440	\N	\N	2026-09-21 08:05:05.206	2026-09-21 08:05:05.206
cmuaymn2f012n71kepabibngh	cmu2kzqeu00055t7mrgmescc1	Christelle	+237657785440	\N	\N	2026-09-21 08:05:05.223	2026-09-21 08:05:05.223
cmuaymn6k012p71kead805hp8	cmu2kzqeu00055t7mrgmescc1	Christian Iut	+237695375042	\N	\N	2026-09-21 08:05:05.372	2026-09-21 08:05:05.372
cmuaymn6x012r71ke0r28nxdc	cmu2kzqeu00055t7mrgmescc1	Christian Iut	+237695375042	\N	\N	2026-09-21 08:05:05.385	2026-09-21 08:05:05.385
cmuaymnef012t71keobsypb6z	cmu2kzqeu00055t7mrgmescc1	≫∘❀♡🫧🌸Sharon😻💕♡❀∘≪	+237650196770	\N	\N	2026-09-21 08:05:05.655	2026-09-21 16:28:19.126
cmuaymnep012v71kec87su3hc	cmu2kzqeu00055t7mrgmescc1	Ck	+237650196770	\N	\N	2026-09-21 08:05:05.665	2026-09-21 08:05:05.665
cmuaymnub012x71ket16lsk4x	cmu2kzqeu00055t7mrgmescc1	Clara beauty	+237650321640	\N	\N	2026-09-21 08:05:06.227	2026-09-21 08:05:06.227
cmuaymnuz012z71keibrimtbi	cmu2kzqeu00055t7mrgmescc1	Clara beauty	+237650321640	\N	\N	2026-09-21 08:05:06.251	2026-09-21 08:05:06.251
cmuaymo0q013171kennkwm6xb	cmu2kzqeu00055t7mrgmescc1	Claudia	+237698784520	\N	\N	2026-09-21 08:05:06.458	2026-09-21 08:05:06.458
cmuaymo16013371keuje6nvxr	cmu2kzqeu00055t7mrgmescc1	Claudia	+237698784520	\N	\N	2026-09-21 08:05:06.474	2026-09-21 08:05:06.474
cmuaymo7r013571ke7to1ls8j	cmu2kzqeu00055t7mrgmescc1	Cliff 95	+237653111970	\N	\N	2026-09-21 08:05:06.711	2026-09-21 08:05:06.711
cmuaymo82013771keyr5ksw7w	cmu2kzqeu00055t7mrgmescc1	Cliff 95	+237653111970	\N	\N	2026-09-21 08:05:06.722	2026-09-21 08:05:06.722
cmuaymonw013971kek4dyl26m	cmu2kzqeu00055t7mrgmescc1	Cliff Scott	+2250566210159	\N	\N	2026-09-21 08:05:07.292	2026-09-21 08:05:07.292
cmuaymops013b71ke0fuk9zav	cmu2kzqeu00055t7mrgmescc1	Cliff Scott	+2250566210159	\N	\N	2026-09-21 08:05:07.36	2026-09-21 08:05:07.36
cmuaymp36013d71ke4c4nepsp	cmu2kzqeu00055t7mrgmescc1	Cliff Ugah	+237650163897	\N	\N	2026-09-21 08:05:07.842	2026-09-21 08:05:07.842
cmuaymp3l013f71kebt2jbomy	cmu2kzqeu00055t7mrgmescc1	Cliff Ugah	+237650163897	\N	\N	2026-09-21 08:05:07.857	2026-09-21 08:05:07.857
cmuaympjn013h71kepu6y8eh1	cmu2kzqeu00055t7mrgmescc1	Clinton Officiel🇨🇲🇨🇦	+237659242577	\N	\N	2026-09-21 08:05:08.436	2026-09-21 08:05:08.436
cmuaympk4013j71keshnjqimn	cmu2kzqeu00055t7mrgmescc1	Clinton Officiel🇨🇲🇨🇦	+237659242577	\N	\N	2026-09-21 08:05:08.452	2026-09-21 08:05:08.452
cmuaymrip013l71kerrl9y4jl	cmu2kzqeu00055t7mrgmescc1	Clovisclovis fearless1	+237698279877	\N	\N	2026-09-21 08:05:10.993	2026-09-21 16:27:30.056
cmuaymrkq013n71kedhog39u4	cmu2kzqeu00055t7mrgmescc1	Clovis	+237698279877	\N	\N	2026-09-21 08:05:11.066	2026-09-21 08:05:11.066
cmuayms4n013p71kei4i2zwhs	cmu2kzqeu00055t7mrgmescc1	Commy Hussy	+237653466708	\N	\N	2026-09-21 08:05:11.783	2026-09-21 08:05:11.783
cmuayms4u013r71ken25dll8c	cmu2kzqeu00055t7mrgmescc1	Commy Hussy	+237653466708	\N	\N	2026-09-21 08:05:11.79	2026-09-21 08:05:11.79
cmuayms92013t71kewe9rsy96	cmu2kzqeu00055t7mrgmescc1	Corinne☘️	+237659444482	\N	\N	2026-09-21 08:05:11.942	2026-09-21 08:05:11.942
cmuayms9e013v71kenozvtyq5	cmu2kzqeu00055t7mrgmescc1	Corinne☘️	+237659444482	\N	\N	2026-09-21 08:05:11.954	2026-09-21 08:05:11.954
cmuaymsdk013x71kez5f6djkg	cmu2kzqeu00055t7mrgmescc1	Croqueur De Briques	+237673561508	\N	\N	2026-09-21 08:05:12.104	2026-09-21 08:05:12.104
cmuaymsdu013z71kepz8tbu5k	cmu2kzqeu00055t7mrgmescc1	Croqueur De Briques	+237673561508	\N	\N	2026-09-21 08:05:12.114	2026-09-21 08:05:12.114
cmuaymsi9014171kezqzjuvlm	cmu2kzqeu00055t7mrgmescc1	Curtis📍	+237693919028	\N	\N	2026-09-21 08:05:12.273	2026-09-21 08:05:12.273
cmuaymsii014371keboq8xb3i	cmu2kzqeu00055t7mrgmescc1	Curtis📍	+237693919028	\N	\N	2026-09-21 08:05:12.282	2026-09-21 08:05:12.282
cmuaymsn7014571kekesa3lce	cmu2kzqeu00055t7mrgmescc1	Customer service	+2378900	\N	\N	2026-09-21 08:05:12.451	2026-09-21 08:05:12.451
cmuaymsne014771keitgq2sh8	cmu2kzqeu00055t7mrgmescc1	Customer service	+2378900	\N	\N	2026-09-21 08:05:12.458	2026-09-21 08:05:12.458
cmuaymsss014971kefovnk0y6	cmu2kzqeu00055t7mrgmescc1	Customer service	+2378787	\N	\N	2026-09-21 08:05:12.652	2026-09-21 08:05:12.652
cmuaymssz014b71kefaljel9z	cmu2kzqeu00055t7mrgmescc1	Customer service	+2378787	\N	\N	2026-09-21 08:05:12.659	2026-09-21 08:05:12.659
cmuaymszy014d71ketyf1bd0s	cmu2kzqeu00055t7mrgmescc1	Cyber-sphere 1	+237678316050	\N	\N	2026-09-21 08:05:12.91	2026-09-21 08:05:12.91
cmuaymt08014f71kek1mlz235	cmu2kzqeu00055t7mrgmescc1	Cyber-sphere 1	+237678316050	\N	\N	2026-09-21 08:05:12.92	2026-09-21 08:05:12.92
cmuaymt3s014h71kemv9eid55	cmu2kzqeu00055t7mrgmescc1	Cyber-sphere 2	+237670372734	\N	\N	2026-09-21 08:05:13.048	2026-09-21 08:05:13.048
cmuaymt40014j71ked7u696ad	cmu2kzqeu00055t7mrgmescc1	Cyber-sphere 2	+237670372734	\N	\N	2026-09-21 08:05:13.056	2026-09-21 08:05:13.056
cmuaymt7n014l71ke14ausq1u	cmu2kzqeu00055t7mrgmescc1	Cynthia Besty❤️💯	+237659629487	\N	\N	2026-09-21 08:05:13.187	2026-09-21 08:05:13.187
cmuaymt7w014n71keottqrbph	cmu2kzqeu00055t7mrgmescc1	Cynthia Besty❤️💯	+237659629487	\N	\N	2026-09-21 08:05:13.196	2026-09-21 08:05:13.196
cmuaymtbv014p71kejbi4u6jw	cmu2kzqeu00055t7mrgmescc1	Cyrille Bro	+237657851354	\N	\N	2026-09-21 08:05:13.339	2026-09-21 08:05:13.339
cmuaymtc7014r71kex3oecp09	cmu2kzqeu00055t7mrgmescc1	Cyrille Bro	+237657851354	\N	\N	2026-09-21 08:05:13.352	2026-09-21 08:05:13.352
cmuaymth9014t71ke8agoz0m0	cmu2kzqeu00055t7mrgmescc1	D D🇪🇺	+237658926173	\N	\N	2026-09-21 08:05:13.533	2026-09-21 08:05:13.533
cmuaymthj014v71kejxdllm1t	cmu2kzqeu00055t7mrgmescc1	D D🇪🇺	+237658926173	\N	\N	2026-09-21 08:05:13.543	2026-09-21 08:05:13.543
cmuaymtrv014x71kewb4nqk10	cmu2kzqeu00055t7mrgmescc1	DAD	+237675341706	\N	\N	2026-09-21 08:05:13.915	2026-09-21 08:05:13.915
cmuaymtse014z71kev5j09j2w	cmu2kzqeu00055t7mrgmescc1	DAD	+237675341706	\N	\N	2026-09-21 08:05:13.934	2026-09-21 08:05:13.934
cmuaymu0x015171keoxsm6ruu	cmu2kzqeu00055t7mrgmescc1	DAMIEN EMMANUEL	+237656267621	\N	\N	2026-09-21 08:05:14.241	2026-09-21 08:05:14.241
cmuaymu1n015371keemdaoh9u	cmu2kzqeu00055t7mrgmescc1	DAMIEN EMMANUEL	+237656267621	\N	\N	2026-09-21 08:05:14.267	2026-09-21 08:05:14.267
cmuaymuyk015571keawdbp4pl	cmu2kzqeu00055t7mrgmescc1	DAYAN👿👿🔥	+237679187636	\N	\N	2026-09-21 08:05:15.452	2026-09-21 08:05:15.452
cmuaymuzl015771kemhq8p5o4	cmu2kzqeu00055t7mrgmescc1	DAYAN👿👿🔥	+237679187636	\N	\N	2026-09-21 08:05:15.489	2026-09-21 08:05:15.489
cmuaymvpt015971kefgetab85	cmu2kzqeu00055t7mrgmescc1	DIABLI OFFICIAL (MV)	+237656752005	\N	\N	2026-09-21 08:05:16.433	2026-09-21 08:05:16.433
cmuaymvqd015b71keki4wbxih	cmu2kzqeu00055t7mrgmescc1	DIABLI OFFICIAL (MV)	+237656752005	\N	\N	2026-09-21 08:05:16.453	2026-09-21 08:05:16.453
cmuaymwe3015d71ke9k2ykw5c	cmu2kzqeu00055t7mrgmescc1	DM	+237658657171	\N	\N	2026-09-21 08:05:17.308	2026-09-21 08:05:17.308
cmuaymwed015f71kevcj1lpnx	cmu2kzqeu00055t7mrgmescc1	DM	+237658657171	\N	\N	2026-09-21 08:05:17.317	2026-09-21 08:05:17.317
cmuaymwm8015h71ke52g7ojcr	cmu2kzqeu00055t7mrgmescc1	DRAMSSI CIV ❤️🥰🥰🙏	+22506413515	\N	\N	2026-09-21 08:05:17.6	2026-09-21 08:05:17.6
cmuaymwmj015j71kels7l94ae	cmu2kzqeu00055t7mrgmescc1	DRAMSSI CIV ❤️🥰🥰🙏	+22506413515	\N	\N	2026-09-21 08:05:17.611	2026-09-21 08:05:17.611
cmuaymx0q015l71keg6k0vytl	cmu2kzqeu00055t7mrgmescc1	DYLAN MBANG🇨🇲	+237656952995	\N	\N	2026-09-21 08:05:18.122	2026-09-21 08:05:18.122
cmuaymx14015n71kejmn5xb6q	cmu2kzqeu00055t7mrgmescc1	DYLAN MBANG🇨🇲	+237656952995	\N	\N	2026-09-21 08:05:18.136	2026-09-21 08:05:18.136
cmuaymx63015p71ke8uozm8gc	cmu2kzqeu00055t7mrgmescc1	Darling	+237682842133	\N	\N	2026-09-21 08:05:18.315	2026-09-21 16:27:32.037
cmuaymx6a015r71kewkpf1gjk	cmu2kzqeu00055t7mrgmescc1	Dad ❤️❤️	+237682842133	\N	\N	2026-09-21 08:05:18.323	2026-09-21 08:05:18.323
cmuaymxca015t71kekm1c8n2j	cmu2kzqeu00055t7mrgmescc1	Daddy Čhøcō	+237691782849	\N	\N	2026-09-21 08:05:18.538	2026-09-21 08:05:18.538
cmuaymxcj015v71kefaucjrow	cmu2kzqeu00055t7mrgmescc1	Daddy Čhøcō	+237691782849	\N	\N	2026-09-21 08:05:18.547	2026-09-21 08:05:18.547
cmuaymxgr015x71kelwttiaf4	cmu2kzqeu00055t7mrgmescc1	Daisy	+237652318563	\N	\N	2026-09-21 08:05:18.699	2026-09-21 08:05:18.699
cmuaymxh5015z71ke4pcr3nov	cmu2kzqeu00055t7mrgmescc1	Daisy	+237652318563	\N	\N	2026-09-21 08:05:18.714	2026-09-21 08:05:18.714
cmuaymxlh016171ke5p3ze8md	cmu2kzqeu00055t7mrgmescc1	Daline Morgane 🥰❤️	+237655516539	\N	\N	2026-09-21 08:05:18.869	2026-09-21 08:05:18.869
cmuaymxlp016371keyf2ll42o	cmu2kzqeu00055t7mrgmescc1	Daline Morgane 🥰❤️	+237655516539	\N	\N	2026-09-21 08:05:18.878	2026-09-21 08:05:18.878
cmuaymxq3016571kex7lqbm9i	cmu2kzqeu00055t7mrgmescc1	Dame David	+237671358994	\N	\N	2026-09-21 08:05:19.035	2026-09-21 08:05:19.035
cmuaymxqb016771kewv66sp48	cmu2kzqeu00055t7mrgmescc1	Dame David	+237671358994	\N	\N	2026-09-21 08:05:19.043	2026-09-21 08:05:19.043
cmuaymxuc016971keomu59nyj	cmu2kzqeu00055t7mrgmescc1	Daniel Emmanuel 💕💞💞	+2349049060309	\N	\N	2026-09-21 08:05:19.188	2026-09-21 08:05:19.188
cmuaymxuk016b71ke6e302hfk	cmu2kzqeu00055t7mrgmescc1	Daniel Emmanuel 💕💞💞	+2349049060309	\N	\N	2026-09-21 08:05:19.196	2026-09-21 08:05:19.196
cmuaymxyf016d71keosgfchxj	cmu2kzqeu00055t7mrgmescc1	Daniel TiesDi	+243979852007	\N	\N	2026-09-21 08:05:19.335	2026-09-21 08:05:19.335
cmuaymxys016f71ke0phlizbg	cmu2kzqeu00055t7mrgmescc1	Daniel TiesDi	+243979852007	\N	\N	2026-09-21 08:05:19.348	2026-09-21 08:05:19.348
cmuaymysu016h71kegn42s4p1	cmu2kzqeu00055t7mrgmescc1	Daniela 🥰❤️	+237683692306	\N	\N	2026-09-21 08:05:20.43	2026-09-21 08:05:20.43
cmuaymyt3016j71kerbwminhd	cmu2kzqeu00055t7mrgmescc1	Daniela 🥰❤️	+237683692306	\N	\N	2026-09-21 08:05:20.44	2026-09-21 08:05:20.44
cmuaymyy3016l71kev59dibfn	cmu2kzqeu00055t7mrgmescc1	Daniella🖤📍	+237692408043	\N	\N	2026-09-21 08:05:20.619	2026-09-21 08:05:20.619
cmuaymyyb016n71ke172lq5zq	cmu2kzqeu00055t7mrgmescc1	Daniella🖤📍	+237692408043	\N	\N	2026-09-21 08:05:20.627	2026-09-21 08:05:20.627
cmuaymz29016p71kex01jnh1l	cmu2kzqeu00055t7mrgmescc1	Daniella 🥰❤️	+237677134661	\N	\N	2026-09-21 08:05:20.769	2026-09-21 08:05:20.769
cmuaymz2i016r71keuhq7bsrd	cmu2kzqeu00055t7mrgmescc1	Daniella 🥰❤️	+237677134661	\N	\N	2026-09-21 08:05:20.778	2026-09-21 08:05:20.778
cmuaymz71016t71kemjvjrcsm	cmu2kzqeu00055t7mrgmescc1	Daniel💕	+237686489730	\N	\N	2026-09-21 08:05:20.941	2026-09-21 08:05:20.941
cmuaymz7a016v71kekafke3h2	cmu2kzqeu00055t7mrgmescc1	Daniel💕	+237686489730	\N	\N	2026-09-21 08:05:20.951	2026-09-21 08:05:20.951
cmuaymzc6016x71kek5be12gg	cmu2kzqeu00055t7mrgmescc1	Darel	+237696883699	\N	\N	2026-09-21 08:05:21.127	2026-09-21 08:05:21.127
cmuaymzcg016z71kemw41j99j	cmu2kzqeu00055t7mrgmescc1	Darel	+237696883699	\N	\N	2026-09-21 08:05:21.136	2026-09-21 08:05:21.136
cmuaymzgq017171ke488mo070	cmu2kzqeu00055t7mrgmescc1	Darios Tido	+237658240194	\N	\N	2026-09-21 08:05:21.291	2026-09-21 08:05:21.291
cmuaymzgz017371ke2aciisvv	cmu2kzqeu00055t7mrgmescc1	Darios Tido	+237658240194	\N	\N	2026-09-21 08:05:21.3	2026-09-21 08:05:21.3
cmuaymzs7017571kem637irc2	cmu2kzqeu00055t7mrgmescc1	Darling Jesus🥰🥹	+237653186686	\N	\N	2026-09-21 08:05:21.704	2026-09-21 08:05:21.704
cmuaymzsj017771kedl0e8sou	cmu2kzqeu00055t7mrgmescc1	Darling Jesus🥰🥹	+237653186686	\N	\N	2026-09-21 08:05:21.715	2026-09-21 08:05:21.715
cmuaymzxa017971ke7k7vw4bb	cmu2kzqeu00055t7mrgmescc1	Dave	+237690598653	\N	\N	2026-09-21 08:05:21.887	2026-09-21 08:05:21.887
cmuaymzxo017b71keea95t6r8	cmu2kzqeu00055t7mrgmescc1	Dave	+237690598653	\N	\N	2026-09-21 08:05:21.9	2026-09-21 08:05:21.9
cmuayn03a017d71kej08lomw9	cmu2kzqeu00055t7mrgmescc1	David Dif	+237691314992	\N	\N	2026-09-21 08:05:22.102	2026-09-21 08:05:22.102
cmuayn03h017f71kenf1hbrxl	cmu2kzqeu00055t7mrgmescc1	David Dif	+237691314992	\N	\N	2026-09-21 08:05:22.109	2026-09-21 08:05:22.109
cmuayn08u017h71keckvexmwz	cmu2kzqeu00055t7mrgmescc1	David Eyidi😎🍀✨	+237676077170	\N	\N	2026-09-21 08:05:22.302	2026-09-21 08:05:22.302
cmuayn09a017j71keza7xnfwx	cmu2kzqeu00055t7mrgmescc1	David Eyidi😎🍀✨	+237676077170	\N	\N	2026-09-21 08:05:22.318	2026-09-21 08:05:22.318
cmuayn0ks017l71ke8iber5r4	cmu2kzqeu00055t7mrgmescc1	Davila Thalia	+237656065926	\N	\N	2026-09-21 08:05:22.732	2026-09-21 08:05:22.732
cmuayn0l8017n71ke6kya6we5	cmu2kzqeu00055t7mrgmescc1	Davila Thalia	+237656065926	\N	\N	2026-09-21 08:05:22.748	2026-09-21 08:05:22.748
cmuayn0tc017p71kec9x26hkq	cmu2kzqeu00055t7mrgmescc1	Dax Big	+237651183177	\N	\N	2026-09-21 08:05:23.04	2026-09-21 08:05:23.04
cmuayn0ty017r71kej3w4foel	cmu2kzqeu00055t7mrgmescc1	Dax Big	+237651183177	\N	\N	2026-09-21 08:05:23.062	2026-09-21 08:05:23.062
cmuayn0yq017t71keplwedxrc	cmu2kzqeu00055t7mrgmescc1	Dayann walker	+237659263293	\N	\N	2026-09-21 08:05:23.234	2026-09-21 08:05:23.234
cmuayn0z4017v71kev5lkks0b	cmu2kzqeu00055t7mrgmescc1	Dayann walker	+237659263293	\N	\N	2026-09-21 08:05:23.248	2026-09-21 08:05:23.248
cmuayn14p017x71ke93n0enko	cmu2kzqeu00055t7mrgmescc1	Deborah ♥️	+237658836019	\N	\N	2026-09-21 08:05:23.449	2026-09-21 08:05:23.449
cmuayn14w017z71keynj4oqzo	cmu2kzqeu00055t7mrgmescc1	Deborah ♥️	+237658836019	\N	\N	2026-09-21 08:05:23.457	2026-09-21 08:05:23.457
cmuayn224018171keltdy31uc	cmu2kzqeu00055t7mrgmescc1	Debruyne 1er	+237692931773	\N	\N	2026-09-21 08:05:24.652	2026-09-21 08:05:24.652
cmuayn22i018371keppn87o9v	cmu2kzqeu00055t7mrgmescc1	Debruyne 1er	+237692931773	\N	\N	2026-09-21 08:05:24.666	2026-09-21 08:05:24.666
cmuayn2db018571ke30vhh0eb	cmu2kzqeu00055t7mrgmescc1	Del Castillo	+237683597481	\N	\N	2026-09-21 08:05:25.056	2026-09-21 08:05:25.056
cmuayn2dt018771ke7p99iv2d	cmu2kzqeu00055t7mrgmescc1	Del Castillo	+237683597481	\N	\N	2026-09-21 08:05:25.073	2026-09-21 08:05:25.073
cmuayn2jy018971kesjvmr4mw	cmu2kzqeu00055t7mrgmescc1	Delguy Shopp	+237683272168	\N	\N	2026-09-21 08:05:25.294	2026-09-21 08:05:25.294
cmuayn2k6018b71kefmtxh945	cmu2kzqeu00055t7mrgmescc1	Delguy Shopp	+237683272168	\N	\N	2026-09-21 08:05:25.302	2026-09-21 08:05:25.302
cmuayn2p5018d71kek6w6vo7x	cmu2kzqeu00055t7mrgmescc1	Delor	+237698993933	\N	\N	2026-09-21 08:05:25.481	2026-09-21 08:05:25.481
cmuayn2pd018f71keungma7ib	cmu2kzqeu00055t7mrgmescc1	Delor	+237698993933	\N	\N	2026-09-21 08:05:25.489	2026-09-21 08:05:25.489
cmuayn2ub018h71ke5at9ajke	cmu2kzqeu00055t7mrgmescc1	Delvinho😎	+237693532260	\N	\N	2026-09-21 08:05:25.667	2026-09-21 08:05:25.667
cmuayn2uh018j71kelvt6d5wt	cmu2kzqeu00055t7mrgmescc1	Delvinho😎	+237693532260	\N	\N	2026-09-21 08:05:25.674	2026-09-21 08:05:25.674
cmuayn2yf018l71kev7bi875r	cmu2kzqeu00055t7mrgmescc1	Desmond 👿👿🔥	+237673105448	\N	\N	2026-09-21 08:05:25.815	2026-09-21 08:05:25.815
cmuayn2ym018n71keogw16k08	cmu2kzqeu00055t7mrgmescc1	Desmond 👿👿🔥	+237673105448	\N	\N	2026-09-21 08:05:25.822	2026-09-21 08:05:25.822
cmuayn3dp018p71ke54mlankm	cmu2kzqeu00055t7mrgmescc1	DevLili	+237677079559	\N	\N	2026-09-21 08:05:26.366	2026-09-21 08:05:26.366
cmuayn3e7018r71ke8zh4sj4w	cmu2kzqeu00055t7mrgmescc1	DevLili	+237677079559	\N	\N	2026-09-21 08:05:26.383	2026-09-21 08:05:26.383
cmuayn3lz018t71keu3qtd472	cmu2kzqeu00055t7mrgmescc1	Devops Contract	+33744902087	\N	\N	2026-09-21 08:05:26.663	2026-09-21 08:05:26.663
cmuayn3m8018v71ke9qb8elj0	cmu2kzqeu00055t7mrgmescc1	Devops Contract	+33744902087	\N	\N	2026-09-21 08:05:26.672	2026-09-21 08:05:26.672
cmuayn3qc018x71kerbj1i0vq	cmu2kzqeu00055t7mrgmescc1	Dgsn	+237682426003	\N	\N	2026-09-21 08:05:26.821	2026-09-21 08:05:26.821
cmuayn3qn018z71kebhuu2mrp	cmu2kzqeu00055t7mrgmescc1	Dgsn	+237682426003	\N	\N	2026-09-21 08:05:26.831	2026-09-21 08:05:26.831
cmuayn3vw019171ke0g8abe32	cmu2kzqeu00055t7mrgmescc1	Diabate	+237651486886	\N	\N	2026-09-21 08:05:27.02	2026-09-21 08:05:27.02
cmuayn3wa019371kedovhho6a	cmu2kzqeu00055t7mrgmescc1	Diabate	+237651486886	\N	\N	2026-09-21 08:05:27.034	2026-09-21 08:05:27.034
cmuayn40q019571kenygdns9k	cmu2kzqeu00055t7mrgmescc1	Diabaté Officiel🧰	+237687088972	\N	\N	2026-09-21 08:05:27.194	2026-09-21 08:05:27.194
cmuayn41c019771kemaaafq9t	cmu2kzqeu00055t7mrgmescc1	Diabaté Officiel🧰	+237687088972	\N	\N	2026-09-21 08:05:27.216	2026-09-21 08:05:27.216
cmuayn456019971keo9dd4vkw	cmu2kzqeu00055t7mrgmescc1	Diallø🧠	+237698319875	\N	\N	2026-09-21 08:05:27.354	2026-09-21 08:05:27.354
cmuayn45f019b71keest4ieub	cmu2kzqeu00055t7mrgmescc1	Diallø🧠	+237698319875	\N	\N	2026-09-21 08:05:27.363	2026-09-21 08:05:27.363
cmuayn4b3019d71keirqnkvjs	cmu2kzqeu00055t7mrgmescc1	Dian Wata Yassa	+237682739842	\N	\N	2026-09-21 08:05:27.567	2026-09-21 08:05:27.567
cmuayn4bz019f71kee7nzgbnx	cmu2kzqeu00055t7mrgmescc1	Dian Wata Yassa	+237682739842	\N	\N	2026-09-21 08:05:27.599	2026-09-21 08:05:27.599
cmuayn4iv019h71keo5uwzj29	cmu2kzqeu00055t7mrgmescc1	Diane	+237677970535	\N	\N	2026-09-21 08:05:27.847	2026-09-21 08:05:27.847
cmuayn4j2019j71ke6wqzr862	cmu2kzqeu00055t7mrgmescc1	Diane	+237677970535	\N	\N	2026-09-21 08:05:27.854	2026-09-21 08:05:27.854
cmuayn4oi019l71ke01iasr77	cmu2kzqeu00055t7mrgmescc1	Dicap's 🇨🇲Rg	+237671023562	\N	\N	2026-09-21 08:05:28.05	2026-09-21 08:05:28.05
cmuayn4p2019n71kesq1ol2m6	cmu2kzqeu00055t7mrgmescc1	Dicap's 🇨🇲Rg	+237671023562	\N	\N	2026-09-21 08:05:28.07	2026-09-21 08:05:28.07
cmuayn53t019p71ke7td6zjmo	cmu2kzqeu00055t7mrgmescc1	Dimitri Avrel	+237693318099	\N	\N	2026-09-21 08:05:28.601	2026-09-21 08:05:28.601
cmuayn54f019r71kez7w2tv0c	cmu2kzqeu00055t7mrgmescc1	Dimitri Avrel	+237693318099	\N	\N	2026-09-21 08:05:28.623	2026-09-21 08:05:28.623
cmuayn59p019t71kee6pfmc9l	cmu2kzqeu00055t7mrgmescc1	Dimitry Payet ⚽️	+237696258701	\N	\N	2026-09-21 08:05:28.814	2026-09-21 08:05:28.814
cmuayn59x019v71ke91bpwxm7	cmu2kzqeu00055t7mrgmescc1	Dimitry Payet ⚽️	+237696258701	\N	\N	2026-09-21 08:05:28.821	2026-09-21 08:05:28.821
cmuayn5g6019x71keomthqw42	cmu2kzqeu00055t7mrgmescc1	Diormassy718	+22365529687	\N	\N	2026-09-21 08:05:29.046	2026-09-21 08:05:29.046
cmuayn5gd019z71kedt9x5lov	cmu2kzqeu00055t7mrgmescc1	Diormassy718	+22365529687	\N	\N	2026-09-21 08:05:29.054	2026-09-21 08:05:29.054
cmuayn5ji01a171kej4ur184m	cmu2kzqeu00055t7mrgmescc1	Divakemg Makeup	+23779433629	\N	\N	2026-09-21 08:05:29.166	2026-09-21 08:05:29.166
cmuayn5jq01a371ketrif0fqz	cmu2kzqeu00055t7mrgmescc1	Divakemg Makeup	+23779433629	\N	\N	2026-09-21 08:05:29.174	2026-09-21 08:05:29.174
cmuayn5mv01a571kerlyyqg3m	cmu2kzqeu00055t7mrgmescc1	Divine Larissa	+237692895702	\N	\N	2026-09-21 08:05:29.287	2026-09-21 08:05:29.287
cmuayn5n301a771keot6cofob	cmu2kzqeu00055t7mrgmescc1	Divine Larissa	+237692895702	\N	\N	2026-09-21 08:05:29.295	2026-09-21 08:05:29.295
cmuayn5qf01a971ke9f29cda4	cmu2kzqeu00055t7mrgmescc1	Djamelio😎🤘🤬	+22655661747	\N	\N	2026-09-21 08:05:29.416	2026-09-21 08:05:29.416
cmuayn5qm01ab71kepw4b5iyr	cmu2kzqeu00055t7mrgmescc1	Djamelio😎🤘🤬	+22655661747	\N	\N	2026-09-21 08:05:29.423	2026-09-21 08:05:29.423
cmuayn64901ad71ke3kntoi77	cmu2kzqeu00055t7mrgmescc1	Djialvar L'intouchable	+237693188975	\N	\N	2026-09-21 08:05:29.913	2026-09-21 08:05:29.913
cmuayn64u01af71keppgffm2t	cmu2kzqeu00055t7mrgmescc1	Djialvar L'intouchable	+237693188975	\N	\N	2026-09-21 08:05:29.935	2026-09-21 08:05:29.935
cmuayn6ay01ah71ke6zrwusy0	cmu2kzqeu00055t7mrgmescc1	Dollar💸 Youngie🥷	+237652059503	\N	\N	2026-09-21 08:05:30.154	2026-09-21 08:05:30.154
cmuayn6b901aj71ke7elkh7w4	cmu2kzqeu00055t7mrgmescc1	Dollar💸 Youngie🥷	+237652059503	\N	\N	2026-09-21 08:05:30.166	2026-09-21 08:05:30.166
cmuayn6gr01al71kerh2o178t	cmu2kzqeu00055t7mrgmescc1	Donald	+237670282512	\N	\N	2026-09-21 08:05:30.363	2026-09-21 08:05:30.363
cmuayn6gz01an71keg763pu4d	cmu2kzqeu00055t7mrgmescc1	Donald	+237670282512	\N	\N	2026-09-21 08:05:30.371	2026-09-21 08:05:30.371
cmuayn6xo01ap71keflbt7spq	cmu2kzqeu00055t7mrgmescc1	Dong Nelson	+393512396762	\N	\N	2026-09-21 08:05:30.973	2026-09-21 08:05:30.973
cmuayn6yu01ar71kehpl9mh4i	cmu2kzqeu00055t7mrgmescc1	Dong Nelson	+393512396762	\N	\N	2026-09-21 08:05:31.014	2026-09-21 08:05:31.014
cmuayn76201at71keemtmgmib	cmu2kzqeu00055t7mrgmescc1	Dorado	+237679048708	\N	\N	2026-09-21 08:05:31.274	2026-09-21 08:05:31.274
cmuayn76b01av71ke9a52yuy3	cmu2kzqeu00055t7mrgmescc1	Dorado	+237679048708	\N	\N	2026-09-21 08:05:31.283	2026-09-21 08:05:31.283
cmuayn7rd01ax71keuz0vypco	cmu2kzqeu00055t7mrgmescc1	Dorian Keyn	+237691511831	\N	\N	2026-09-21 08:05:32.041	2026-09-21 08:05:32.041
cmuayn7rr01az71kewr8he5kh	cmu2kzqeu00055t7mrgmescc1	Dorian Keyn	+237691511831	\N	\N	2026-09-21 08:05:32.055	2026-09-21 08:05:32.055
cmuayn8cm01b171ke4cme4aby	cmu2kzqeu00055t7mrgmescc1	Dorine☘️⚡️	+237658332829	\N	\N	2026-09-21 08:05:32.806	2026-09-21 08:05:32.806
cmuayn8cy01b371ke88qo8rrc	cmu2kzqeu00055t7mrgmescc1	Dorine☘️⚡️	+237658332829	\N	\N	2026-09-21 08:05:32.818	2026-09-21 08:05:32.818
cmuayn90401b571keunkxh9sl	cmu2kzqeu00055t7mrgmescc1	Doudou Meganne	+237691563625	\N	\N	2026-09-21 08:05:33.653	2026-09-21 08:05:33.653
cmuayn91101b771keg91rpqbb	cmu2kzqeu00055t7mrgmescc1	Doudou Meganne	+237691563625	\N	\N	2026-09-21 08:05:33.685	2026-09-21 08:05:33.685
cmuayn9e401b971kefrf6shxe	cmu2kzqeu00055t7mrgmescc1	Dr.Love	+237656945140	\N	\N	2026-09-21 08:05:34.156	2026-09-21 08:05:34.156
cmuayn9gv01bb71ke4p5k0ct0	cmu2kzqeu00055t7mrgmescc1	Dr.Love	+237656945140	\N	\N	2026-09-21 08:05:34.255	2026-09-21 08:05:34.255
cmuayn9qy01bd71kel7naywxk	cmu2kzqeu00055t7mrgmescc1	MV 293	+237659016752	\N	\N	2026-09-21 08:05:34.618	2026-09-21 16:27:51.966
cmuayn9rq01bf71ke3g0wh6m1	cmu2kzqeu00055t7mrgmescc1	Drey❤️🎲🎲🎲	+237659016752	\N	\N	2026-09-21 08:05:34.646	2026-09-21 08:05:34.646
cmuaynacs01bh71kew7tmv1p5	cmu2kzqeu00055t7mrgmescc1	Dugari Farm	+237650499462	\N	\N	2026-09-21 08:05:35.404	2026-09-21 08:05:35.404
cmuaynad401bj71kev3f4hgl2	cmu2kzqeu00055t7mrgmescc1	Dugari Farm	+237650499462	\N	\N	2026-09-21 08:05:35.416	2026-09-21 08:05:35.416
cmuaynalu01bl71kevzrj3isw	cmu2kzqeu00055t7mrgmescc1	Dv🌌	+237659202875	\N	\N	2026-09-21 08:05:35.73	2026-09-21 08:05:35.73
cmuaynam901bn71kel0bf2fbm	cmu2kzqeu00055t7mrgmescc1	Dv🌌	+237659202875	\N	\N	2026-09-21 08:05:35.745	2026-09-21 08:05:35.745
cmuaynasi01bp71keqh9695s7	cmu2kzqeu00055t7mrgmescc1	Dymi New🚦❤️🎊	+237698537108	\N	\N	2026-09-21 08:05:35.97	2026-09-21 08:05:35.97
cmuaynass01br71kerkqeoguf	cmu2kzqeu00055t7mrgmescc1	Dymi New🚦❤️🎊	+237698537108	\N	\N	2026-09-21 08:05:35.981	2026-09-21 08:05:35.981
cmuaynaxk01bt71kewyfwmaez	cmu2kzqeu00055t7mrgmescc1	EDWIN😎	+237682453013	\N	\N	2026-09-21 08:05:36.153	2026-09-21 08:05:36.153
cmuaynaxt01bv71kekr6vmkoc	cmu2kzqeu00055t7mrgmescc1	EDWIN😎	+237682453013	\N	\N	2026-09-21 08:05:36.161	2026-09-21 08:05:36.161
cmuaynb3v01bx71ke7oyfl829	cmu2kzqeu00055t7mrgmescc1	Earth Heritage	+237620295425	\N	\N	2026-09-21 08:05:36.379	2026-09-21 08:05:36.379
cmuaynb4501bz71kekiz4o4da	cmu2kzqeu00055t7mrgmescc1	Earth Heritage	+237620295425	\N	\N	2026-09-21 08:05:36.389	2026-09-21 08:05:36.389
cmuaynbcb01c171keg2882yq9	cmu2kzqeu00055t7mrgmescc1	Edan	+237694122200	\N	\N	2026-09-21 08:05:36.683	2026-09-21 08:05:36.683
cmuaynbcm01c371kes2e71j8y	cmu2kzqeu00055t7mrgmescc1	Edan	+237694122200	\N	\N	2026-09-21 08:05:36.694	2026-09-21 08:05:36.694
cmuaynbs001c571kekc3yq93l	cmu2kzqeu00055t7mrgmescc1	Eden ❤️🇨🇲	+237680253386	\N	\N	2026-09-21 08:05:37.248	2026-09-21 08:05:37.248
cmuaynbsd01c771keyzv8lt41	cmu2kzqeu00055t7mrgmescc1	Eden ❤️🇨🇲	+237680253386	\N	\N	2026-09-21 08:05:37.261	2026-09-21 08:05:37.261
cmuaync1a01c971ke0ozkpi7o	cmu2kzqeu00055t7mrgmescc1	Eden👏🏿💓	+237659902893	\N	\N	2026-09-21 08:05:37.582	2026-09-21 08:05:37.582
cmuaync1n01cb71ke8xzocg0e	cmu2kzqeu00055t7mrgmescc1	Eden👏🏿💓	+237659902893	\N	\N	2026-09-21 08:05:37.596	2026-09-21 08:05:37.596
cmuaynca201cd71kek6npff63	cmu2kzqeu00055t7mrgmescc1	Efugenum Edwin Udonghoi	+18329495719	\N	\N	2026-09-21 08:05:37.898	2026-09-21 08:05:37.898
cmuayncaa01cf71ke7p65x7d7	cmu2kzqeu00055t7mrgmescc1	Efugenum Edwin Udonghoi	+18329495719	\N	\N	2026-09-21 08:05:37.906	2026-09-21 08:05:37.906
cmuayncfi01ch71kev1wmgmg8	cmu2kzqeu00055t7mrgmescc1	Elder Gerald	+237650101703	\N	\N	2026-09-21 08:05:38.095	2026-09-21 08:05:38.095
cmuayncfp01cj71ke8wcct2mz	cmu2kzqeu00055t7mrgmescc1	Elder Gerald	+237650101703	\N	\N	2026-09-21 08:05:38.102	2026-09-21 08:05:38.102
cmuayncuu01cl71kepemjuuik	cmu2kzqeu00055t7mrgmescc1	Elfride	+237658023328	\N	\N	2026-09-21 08:05:38.646	2026-09-21 08:05:38.646
cmuayncve01cn71kep7jz1kuc	cmu2kzqeu00055t7mrgmescc1	Elfride	+237658023328	\N	\N	2026-09-21 08:05:38.666	2026-09-21 08:05:38.666
cmuaynd3q01cp71kedgp8nny8	cmu2kzqeu00055t7mrgmescc1	Elisee	+237679115357	\N	\N	2026-09-21 08:05:38.966	2026-09-21 08:05:38.966
cmuaynd4a01cr71ke8j9kayzz	cmu2kzqeu00055t7mrgmescc1	Elisee	+237679115357	\N	\N	2026-09-21 08:05:38.986	2026-09-21 08:05:38.986
cmuaynee201ct71kecomjgvkf	cmu2kzqeu00055t7mrgmescc1	Elisée	+237686951826	\N	\N	2026-09-21 08:05:40.635	2026-09-21 08:05:40.635
cmuayneea01cv71kek4fv9liv	cmu2kzqeu00055t7mrgmescc1	Elisée	+237686951826	\N	\N	2026-09-21 08:05:40.643	2026-09-21 08:05:40.643
cmuaynfw901cx71keaaq8r0v6	cmu2kzqeu00055t7mrgmescc1	Eliz(Mougnol)	+237690121801	\N	\N	2026-09-21 08:05:42.585	2026-09-21 08:05:42.585
cmuayngcb01cz71kevvnrikem	cmu2kzqeu00055t7mrgmescc1	Eliz(Mougnol)	+237690121801	\N	\N	2026-09-21 08:05:43.163	2026-09-21 08:05:43.163
cmuaynh8801d171kebsu8tx7r	cmu2kzqeu00055t7mrgmescc1	Elvira 😊	+237688415028	\N	\N	2026-09-21 08:05:44.312	2026-09-21 08:05:44.312
cmuaynh8g01d371kejxafenxo	cmu2kzqeu00055t7mrgmescc1	Elvira 😊	+237688415028	\N	\N	2026-09-21 08:05:44.32	2026-09-21 08:05:44.32
cmuaynhl601d571kehc3dhqv7	cmu2kzqeu00055t7mrgmescc1	Elvira✨	+237657901623	\N	\N	2026-09-21 08:05:44.778	2026-09-21 08:05:44.778
cmuaynhlo01d771kegoqr4vyv	cmu2kzqeu00055t7mrgmescc1	Elvira✨	+237657901623	\N	\N	2026-09-21 08:05:44.796	2026-09-21 08:05:44.796
cmuayni2v01d971ke481bkemr	cmu2kzqeu00055t7mrgmescc1	Emeraude Benista	+237689837179	\N	\N	2026-09-21 08:05:45.415	2026-09-21 08:05:45.415
cmuayni3901db71kee3rtuj09	cmu2kzqeu00055t7mrgmescc1	Emeraude Benista	+237689837179	\N	\N	2026-09-21 08:05:45.429	2026-09-21 08:05:45.429
cmuaynifs01dd71keh2qgoiw5	cmu2kzqeu00055t7mrgmescc1	Emile 👽🐥	+237679305079	\N	\N	2026-09-21 08:05:45.88	2026-09-21 08:05:45.88
cmuaynigg01df71ke5ei6lsyj	cmu2kzqeu00055t7mrgmescc1	Emile 👽🐥	+237679305079	\N	\N	2026-09-21 08:05:45.905	2026-09-21 08:05:45.905
cmuaynivi01dh71kehpznnfjd	cmu2kzqeu00055t7mrgmescc1	Emmanuel	+237698990336	\N	\N	2026-09-21 08:05:46.447	2026-09-21 08:05:46.447
cmuaynivz01dj71ke5oasijjc	cmu2kzqeu00055t7mrgmescc1	Emmanuel	+237698990336	\N	\N	2026-09-21 08:05:46.463	2026-09-21 08:05:46.463
cmuaynj1601dl71kesvmnp6gh	cmu2kzqeu00055t7mrgmescc1	Emmanuel Fosso	+237674051182	\N	\N	2026-09-21 08:05:46.65	2026-09-21 08:05:46.65
cmuaynj1i01dn71keovl25ywj	cmu2kzqeu00055t7mrgmescc1	Emmanuel Fosso	+237674051182	\N	\N	2026-09-21 08:05:46.662	2026-09-21 08:05:46.662
cmuaynj7j01dp71keoby7airy	cmu2kzqeu00055t7mrgmescc1	Emmanuel Key	+237671499400	\N	\N	2026-09-21 08:05:46.88	2026-09-21 08:05:46.88
cmuaynj8101dr71kee6d1i9v6	cmu2kzqeu00055t7mrgmescc1	Emmanuel Key	+237671499400	\N	\N	2026-09-21 08:05:46.897	2026-09-21 08:05:46.897
cmuaynjib01dt71keq19smaoy	cmu2kzqeu00055t7mrgmescc1	Emmanuel Piano	+237686627623	\N	\N	2026-09-21 08:05:47.267	2026-09-21 08:05:47.267
cmuaynjij01dv71keqz90suuj	cmu2kzqeu00055t7mrgmescc1	Emmanuel Piano	+237686627623	\N	\N	2026-09-21 08:05:47.275	2026-09-21 08:05:47.275
cmuaynjmp01dx71keubw04s60	cmu2kzqeu00055t7mrgmescc1	Emmanuell🥰❤️	+237670418334	\N	\N	2026-09-21 08:05:47.425	2026-09-21 08:05:47.425
cmuaynjmx01dz71kegxznsm5b	cmu2kzqeu00055t7mrgmescc1	Emmanuell🥰❤️	+237670418334	\N	\N	2026-09-21 08:05:47.434	2026-09-21 08:05:47.434
cmuaynjql01e171ke1lttu2gg	cmu2kzqeu00055t7mrgmescc1	Emmysparkes	+237672694672	\N	\N	2026-09-21 08:05:47.565	2026-09-21 08:05:47.565
cmuaynjqv01e371keq265a84a	cmu2kzqeu00055t7mrgmescc1	Emmysparkes	+237672694672	\N	\N	2026-09-21 08:05:47.575	2026-09-21 08:05:47.575
cmuaynk3l01e571keh50tmkip	cmu2kzqeu00055t7mrgmescc1	Empire	+237674454057	\N	\N	2026-09-21 08:05:48.033	2026-09-21 08:05:48.033
cmuaynk3y01e771ke23okb25j	cmu2kzqeu00055t7mrgmescc1	Empire	+237674454057	\N	\N	2026-09-21 08:05:48.046	2026-09-21 08:05:48.046
cmuaynka001e971ke268fa16j	cmu2kzqeu00055t7mrgmescc1	Emploi	+237681454484	\N	\N	2026-09-21 08:05:48.264	2026-09-21 08:05:48.264
cmuaynka701eb71kembcm4vdo	cmu2kzqeu00055t7mrgmescc1	Emploi	+237681454484	\N	\N	2026-09-21 08:05:48.271	2026-09-21 08:05:48.271
cmuaynkdp01ed71keljqevzxz	cmu2kzqeu00055t7mrgmescc1	Endah Olivia	+23777370509	\N	\N	2026-09-21 08:05:48.397	2026-09-21 08:05:48.397
cmuaynkdw01ef71ke5efqzi0a	cmu2kzqeu00055t7mrgmescc1	Endah Olivia	+23777370509	\N	\N	2026-09-21 08:05:48.404	2026-09-21 08:05:48.404
cmuaynkhe01eh71keycmersf3	cmu2kzqeu00055t7mrgmescc1	Epale	+237678599956	\N	\N	2026-09-21 08:05:48.53	2026-09-21 08:05:48.53
cmuaynkhl01ej71kew8nsjkcv	cmu2kzqeu00055t7mrgmescc1	Epale	+237678599956	\N	\N	2026-09-21 08:05:48.537	2026-09-21 08:05:48.537
cmuaynkl101el71ke79zl138j	cmu2kzqeu00055t7mrgmescc1	Epale	+237670734418	\N	\N	2026-09-21 08:05:48.662	2026-09-21 08:05:48.662
cmuaynkl801en71kedmie6ig3	cmu2kzqeu00055t7mrgmescc1	Epale	+237670734418	\N	\N	2026-09-21 08:05:48.669	2026-09-21 08:05:48.669
cmuaynkoe01ep71kejiikrj5r	cmu2kzqeu00055t7mrgmescc1	Eric	+22664652734	\N	\N	2026-09-21 08:05:48.782	2026-09-21 08:05:48.782
cmuaynkol01er71ke1f3ion9b	cmu2kzqeu00055t7mrgmescc1	Eric	+22664652734	\N	\N	2026-09-21 08:05:48.789	2026-09-21 08:05:48.789
cmuaynksg01et71kegaw3pl13	cmu2kzqeu00055t7mrgmescc1	Eric	+237683094583	\N	\N	2026-09-21 08:05:48.928	2026-09-21 08:05:48.928
cmuaynkso01ev71kexgy2jt8c	cmu2kzqeu00055t7mrgmescc1	Eric	+237683094583	\N	\N	2026-09-21 08:05:48.936	2026-09-21 08:05:48.936
cmuaynkx401ex71ke9wwttqvv	cmu2kzqeu00055t7mrgmescc1	Erica Aseli 2	+237673755034	\N	\N	2026-09-21 08:05:49.097	2026-09-21 08:05:49.097
cmuaynkxf01ez71ker829hn17	cmu2kzqeu00055t7mrgmescc1	Erica Aseli 2	+237673755034	\N	\N	2026-09-21 08:05:49.106	2026-09-21 08:05:49.106
cmuaynl4701f171kexesvzw1c	cmu2kzqeu00055t7mrgmescc1	Erica😇	+233596767635	\N	\N	2026-09-21 08:05:49.352	2026-09-21 08:05:49.352
cmuaynl4z01f371kep14pmk4g	cmu2kzqeu00055t7mrgmescc1	Erica😇	+233596767635	\N	\N	2026-09-21 08:05:49.38	2026-09-21 08:05:49.38
cmuaynlck01f571kewcik5cjk	cmu2kzqeu00055t7mrgmescc1	Ericka	+237658011073	\N	\N	2026-09-21 08:05:49.653	2026-09-21 08:05:49.653
cmuaynlcx01f771ke81k4ycvs	cmu2kzqeu00055t7mrgmescc1	Ericka	+237658011073	\N	\N	2026-09-21 08:05:49.665	2026-09-21 08:05:49.665
cmuaynlg801f971kebwtastpl	cmu2kzqeu00055t7mrgmescc1	Erilove	+237676652237	\N	\N	2026-09-21 08:05:49.784	2026-09-21 08:05:49.784
cmuaynlgh01fb71keecq8yni7	cmu2kzqeu00055t7mrgmescc1	Erilove	+237676652237	\N	\N	2026-09-21 08:05:49.793	2026-09-21 08:05:49.793
cmuaynlko01fd71ke6yuiylqo	cmu2kzqeu00055t7mrgmescc1	Espoir KH	+22998650299	\N	\N	2026-09-21 08:05:49.944	2026-09-21 08:05:49.944
cmuaynlkv01ff71keaedqezeb	cmu2kzqeu00055t7mrgmescc1	Espoir KH	+22998650299	\N	\N	2026-09-21 08:05:49.952	2026-09-21 08:05:49.952
cmuaynlp801fh71kekomnu1xk	cmu2kzqeu00055t7mrgmescc1	Esther	+237677022767	\N	\N	2026-09-21 08:05:50.109	2026-09-21 08:05:50.109
cmuaynlpf01fj71keg9gpih9p	cmu2kzqeu00055t7mrgmescc1	Esther	+237677022767	\N	\N	2026-09-21 08:05:50.116	2026-09-21 08:05:50.116
cmuaynltc01fl71ke1kx2l82p	cmu2kzqeu00055t7mrgmescc1	Esther Bright 🍃	+237676428555	\N	\N	2026-09-21 08:05:50.256	2026-09-21 08:05:50.256
cmuaynltk01fn71kel4dqwlwa	cmu2kzqeu00055t7mrgmescc1	Esther Bright 🍃	+237676428555	\N	\N	2026-09-21 08:05:50.264	2026-09-21 08:05:50.264
cmuaynlxc01fp71keogbevu8y	cmu2kzqeu00055t7mrgmescc1	The Seven Academy	+237658066982	\N	\N	2026-09-21 08:05:50.4	2026-09-21 16:28:11.749
cmuaynlxj01fr71kes5oj7kbq	cmu2kzqeu00055t7mrgmescc1	Ethical Hacking	+237658066982	\N	\N	2026-09-21 08:05:50.407	2026-09-21 08:05:50.407
cmuaynm1b01ft71kee1igxs42	cmu2kzqeu00055t7mrgmescc1	Eunice	+237657819921	\N	\N	2026-09-21 08:05:50.543	2026-09-21 08:05:50.543
cmuaynm1i01fv71kepkrmbynz	cmu2kzqeu00055t7mrgmescc1	Eunice	+237657819921	\N	\N	2026-09-21 08:05:50.55	2026-09-21 08:05:50.55
cmuaynm5a01fx71keplpaibzg	cmu2kzqeu00055t7mrgmescc1	Eva	+2376526510911	\N	\N	2026-09-21 08:05:50.686	2026-09-21 08:05:50.686
cmuaynm5i01fz71ke9qq4c0m3	cmu2kzqeu00055t7mrgmescc1	Eva	+2376526510911	\N	\N	2026-09-21 08:05:50.694	2026-09-21 08:05:50.694
cmuaynm9c01g171ket71h8v2i	cmu2kzqeu00055t7mrgmescc1	Eva 💫❤️	+237691616891	\N	\N	2026-09-21 08:05:50.832	2026-09-21 08:05:50.832
cmuaynm9j01g371kee94gdvpu	cmu2kzqeu00055t7mrgmescc1	Eva 💫❤️	+237691616891	\N	\N	2026-09-21 08:05:50.839	2026-09-21 08:05:50.839
cmuaynmdf01g571keb7pg01qe	cmu2kzqeu00055t7mrgmescc1	Evaris	+237681327589	\N	\N	2026-09-21 08:05:50.98	2026-09-21 08:05:50.98
cmuaynmdn01g771kedzg7lsyo	cmu2kzqeu00055t7mrgmescc1	Evaris	+237681327589	\N	\N	2026-09-21 08:05:50.987	2026-09-21 08:05:50.987
cmuaynmh301g971ke09dlwqgj	cmu2kzqeu00055t7mrgmescc1	Ewi	+237651514640	\N	\N	2026-09-21 08:05:51.111	2026-09-21 08:05:51.111
cmuaynmha01gb71ke1rkqj7d6	cmu2kzqeu00055t7mrgmescc1	Ewi	+237651514640	\N	\N	2026-09-21 08:05:51.118	2026-09-21 08:05:51.118
cmuaynmlc01gd71kerhw6u03z	cmu2kzqeu00055t7mrgmescc1	Ezekiel	+237696307982	\N	\N	2026-09-21 08:05:51.264	2026-09-21 08:05:51.264
cmuaynmlm01gf71ke26mjh743	cmu2kzqeu00055t7mrgmescc1	Ezekiel	+237696307982	\N	\N	2026-09-21 08:05:51.274	2026-09-21 08:05:51.274
cmuaynmqf01gh71kev7q7ze28	cmu2kzqeu00055t7mrgmescc1	Fabiola	+237658520327	\N	\N	2026-09-21 08:05:51.447	2026-09-21 08:05:51.447
cmuaynmqo01gj71kegy0ithqa	cmu2kzqeu00055t7mrgmescc1	Fabiola	+237658520327	\N	\N	2026-09-21 08:05:51.456	2026-09-21 08:05:51.456
cmuaynmu001gl71keh80ueyqm	cmu2kzqeu00055t7mrgmescc1	Fabiola🍀	+237659047928	\N	\N	2026-09-21 08:05:51.576	2026-09-21 08:05:51.576
cmuaynmu701gn71kezzkfa1p2	cmu2kzqeu00055t7mrgmescc1	Fabiola🍀	+237659047928	\N	\N	2026-09-21 08:05:51.583	2026-09-21 08:05:51.583
cmuaynn3z01gp71ke2slenoow	cmu2kzqeu00055t7mrgmescc1	Faith ☘️🌸	+237653945882	\N	\N	2026-09-21 08:05:51.935	2026-09-21 08:05:51.935
cmuaynn4801gr71ke208bnepl	cmu2kzqeu00055t7mrgmescc1	Faith ☘️🌸	+237653945882	\N	\N	2026-09-21 08:05:51.945	2026-09-21 08:05:51.945
cmuaynn7m01gt71kewbws2tqi	cmu2kzqeu00055t7mrgmescc1	Faith 🤍🥰	+237658197026	\N	\N	2026-09-21 08:05:52.066	2026-09-21 08:05:52.066
cmuaynn7u01gv71ke115p6xn3	cmu2kzqeu00055t7mrgmescc1	Faith 🤍🥰	+237658197026	\N	\N	2026-09-21 08:05:52.074	2026-09-21 08:05:52.074
cmuaynncu01gx71kesd3izpha	cmu2kzqeu00055t7mrgmescc1	Fanny 💫	+237688560085	\N	\N	2026-09-21 08:05:52.254	2026-09-21 08:05:52.254
cmuaynnd201gz71kenow3t0kp	cmu2kzqeu00055t7mrgmescc1	Fanny 💫	+237688560085	\N	\N	2026-09-21 08:05:52.262	2026-09-21 08:05:52.262
cmuaynngw01h171keqtowm27k	cmu2kzqeu00055t7mrgmescc1	Fashion💫	+237653270843	\N	\N	2026-09-21 08:05:52.4	2026-09-21 08:05:52.4
cmuaynnh601h371kesvri0hvq	cmu2kzqeu00055t7mrgmescc1	Fashion💫	+237653270843	\N	\N	2026-09-21 08:05:52.411	2026-09-21 08:05:52.411
cmuaynnkn01h571ket9eavk66	cmu2kzqeu00055t7mrgmescc1	Fastina Akwagoh	+4791257344	\N	\N	2026-09-21 08:05:52.535	2026-09-21 08:05:52.535
cmuaynnkx01h771ke2x8uq9i9	cmu2kzqeu00055t7mrgmescc1	Fastina Akwagoh	+4791257344	\N	\N	2026-09-21 08:05:52.545	2026-09-21 08:05:52.545
cmuaynnp001h971kembxr99qx	cmu2kzqeu00055t7mrgmescc1	Favour. Vera Akwa go	+23752487549	\N	\N	2026-09-21 08:05:52.692	2026-09-21 08:05:52.692
cmuaynnp701hb71ke2dr8oapl	cmu2kzqeu00055t7mrgmescc1	Favour. Vera Akwa go	+23752487549	\N	\N	2026-09-21 08:05:52.699	2026-09-21 08:05:52.699
cmuaynnsu01hd71kedkrf7esv	cmu2kzqeu00055t7mrgmescc1	Fille Quartier Numéro 9	+237698827246	\N	\N	2026-09-21 08:05:52.83	2026-09-21 08:05:52.83
cmuaynnt201hf71kehv3xnpb8	cmu2kzqeu00055t7mrgmescc1	Fille Quartier Numéro 9	+237698827246	\N	\N	2026-09-21 08:05:52.838	2026-09-21 08:05:52.838
cmuaynnxa01hh71ke8r7gyr2b	cmu2kzqeu00055t7mrgmescc1	Fine Boy😎  Vas	+23777323119	\N	\N	2026-09-21 08:05:52.99	2026-09-21 08:05:52.99
cmuaynnxi01hj71kefyx11qr8	cmu2kzqeu00055t7mrgmescc1	Fine Boy😎  Vas	+23777323119	\N	\N	2026-09-21 08:05:52.998	2026-09-21 08:05:52.998
cmuayno1001hl71ket5wrkpdq	cmu2kzqeu00055t7mrgmescc1	Florine♥️	+237698416594	\N	\N	2026-09-21 08:05:53.124	2026-09-21 08:05:53.124
cmuayno1701hn71kedz43v3u7	cmu2kzqeu00055t7mrgmescc1	Florine♥️	+237698416594	\N	\N	2026-09-21 08:05:53.131	2026-09-21 08:05:53.131
cmuayno4r01hp71ke86lfm2sa	cmu2kzqeu00055t7mrgmescc1	Fobisong Micheal	+237679262994	\N	\N	2026-09-21 08:05:53.259	2026-09-21 08:05:53.259
cmuayno4y01hr71kex23a5zq0	cmu2kzqeu00055t7mrgmescc1	Fobisong Micheal	+237679262994	\N	\N	2026-09-21 08:05:53.266	2026-09-21 08:05:53.266
cmuaynopn01ht71ketsrwshbi	cmu2kzqeu00055t7mrgmescc1	Fokou	+237677287346	\N	\N	2026-09-21 08:05:54.011	2026-09-21 08:05:54.011
cmuaynoq501hv71kea7vg1ue7	cmu2kzqeu00055t7mrgmescc1	Fokou	+237677287346	\N	\N	2026-09-21 08:05:54.029	2026-09-21 08:05:54.029
cmuaynoz701hx71ke2wa0deye	cmu2kzqeu00055t7mrgmescc1	Fon Napoleon	+237681642338	\N	\N	2026-09-21 08:05:54.355	2026-09-21 08:05:54.355
cmuaynozf01hz71keikchzukd	cmu2kzqeu00055t7mrgmescc1	Fon Napoleon	+237681642338	\N	\N	2026-09-21 08:05:54.363	2026-09-21 08:05:54.363
cmuaynp3001i171kekeb556jo	cmu2kzqeu00055t7mrgmescc1	Forbin	+237680210743	\N	\N	2026-09-21 08:05:54.492	2026-09-21 08:05:54.492
cmuaynp3701i371ke45qp6dxr	cmu2kzqeu00055t7mrgmescc1	Forbin	+237680210743	\N	\N	2026-09-21 08:05:54.499	2026-09-21 08:05:54.499
cmuaynp7701i571kergv8ayia	cmu2kzqeu00055t7mrgmescc1	Fowa	+237677187711	\N	\N	2026-09-21 08:05:54.643	2026-09-21 08:05:54.643
cmuaynp7e01i771ke9yqn6rqa	cmu2kzqeu00055t7mrgmescc1	Fowa	+237677187711	\N	\N	2026-09-21 08:05:54.65	2026-09-21 08:05:54.65
cmuaynpb701i971kea3phb3ne	cmu2kzqeu00055t7mrgmescc1	Fowa	+971504119838	\N	\N	2026-09-21 08:05:54.786	2026-09-21 08:05:54.786
cmuaynpbl01ib71ked308d235	cmu2kzqeu00055t7mrgmescc1	Fowa	+971504119838	\N	\N	2026-09-21 08:05:54.802	2026-09-21 08:05:54.802
cmuaynpfb01id71keltfm0yi6	cmu2kzqeu00055t7mrgmescc1	Francine Maurane☘️	+237656759885	\N	\N	2026-09-21 08:05:54.936	2026-09-21 08:05:54.936
cmuaynpfl01if71keiarrsk74	cmu2kzqeu00055t7mrgmescc1	Francine Maurane☘️	+237656759885	\N	\N	2026-09-21 08:05:54.945	2026-09-21 08:05:54.945
cmuaynpl801ih71keq4l1w9fu	cmu2kzqeu00055t7mrgmescc1	Franckel	+237657370256	\N	\N	2026-09-21 08:05:55.148	2026-09-21 08:05:55.148
cmuaynpli01ij71kemzisyt07	cmu2kzqeu00055t7mrgmescc1	Franckel	+237657370256	\N	\N	2026-09-21 08:05:55.158	2026-09-21 08:05:55.158
cmuaynpp701il71ke44sbfqho	cmu2kzqeu00055t7mrgmescc1	Franckel777✝️	+237652106267	\N	\N	2026-09-21 08:05:55.291	2026-09-21 08:05:55.291
cmuaynppf01in71kegsdm3lr3	cmu2kzqeu00055t7mrgmescc1	Franckel777✝️	+237652106267	\N	\N	2026-09-21 08:05:55.299	2026-09-21 08:05:55.299
cmuaynpzh01ip71ke7k328mu2	cmu2kzqeu00055t7mrgmescc1	Francline	+237679832839	\N	\N	2026-09-21 08:05:55.661	2026-09-21 08:05:55.661
cmuaynpzo01ir71ke2ug6swlr	cmu2kzqeu00055t7mrgmescc1	Francline	+237679832839	\N	\N	2026-09-21 08:05:55.669	2026-09-21 08:05:55.669
cmuaynq2x01it71keq6w1gd9a	cmu2kzqeu00055t7mrgmescc1	Frank Kurry🥚	+237698568071	\N	\N	2026-09-21 08:05:55.785	2026-09-21 08:05:55.785
cmuaynq3501iv71keqwfnjh2t	cmu2kzqeu00055t7mrgmescc1	Frank Kurry🥚	+237698568071	\N	\N	2026-09-21 08:05:55.794	2026-09-21 08:05:55.794
cmuaynq6i01ix71kechxyt75b	cmu2kzqeu00055t7mrgmescc1	Frankline	+237680434810	\N	\N	2026-09-21 08:05:55.914	2026-09-21 08:05:55.914
cmuaynq6p01iz71ke3nk7r33j	cmu2kzqeu00055t7mrgmescc1	Frankline	+237680434810	\N	\N	2026-09-21 08:05:55.921	2026-09-21 08:05:55.921
cmuaynq9t01j171keocpy18jw	cmu2kzqeu00055t7mrgmescc1	Fred Store	+237658128190	\N	\N	2026-09-21 08:05:56.033	2026-09-21 08:05:56.033
cmuaynqa101j371keux6rnmjl	cmu2kzqeu00055t7mrgmescc1	Fred Store	+237658128190	\N	\N	2026-09-21 08:05:56.041	2026-09-21 08:05:56.041
cmuaynqdi01j571kexfjlrmds	cmu2kzqeu00055t7mrgmescc1	Frisie	+237675004127	\N	\N	2026-09-21 08:05:56.166	2026-09-21 08:05:56.166
cmuaynqdr01j771kesricm1fu	cmu2kzqeu00055t7mrgmescc1	Frisie	+237675004127	\N	\N	2026-09-21 08:05:56.176	2026-09-21 08:05:56.176
cmuaynqh501j971ket2qq4g58	cmu2kzqeu00055t7mrgmescc1	Fruck Life😈😈😈	+237682249056	\N	\N	2026-09-21 08:05:56.297	2026-09-21 08:05:56.297
cmuaynqhc01jb71ketu92kf8f	cmu2kzqeu00055t7mrgmescc1	Fruck Life😈😈😈	+237682249056	\N	\N	2026-09-21 08:05:56.304	2026-09-21 08:05:56.304
cmuaynqku01jd71keqhxczv33	cmu2kzqeu00055t7mrgmescc1	Frånk Krūsh💞	+237677471396	\N	\N	2026-09-21 08:05:56.43	2026-09-21 08:05:56.43
cmuaynql101jf71kegbgwnl0i	cmu2kzqeu00055t7mrgmescc1	Frånk Krūsh💞	+237677471396	\N	\N	2026-09-21 08:05:56.437	2026-09-21 08:05:56.437
cmuaynqoj01jh71keofg3r1kv	cmu2kzqeu00055t7mrgmescc1	Frère Hervé	+237673525543	\N	\N	2026-09-21 08:05:56.563	2026-09-21 08:05:56.563
cmuaynqoq01jj71keic2d83e1	cmu2kzqeu00055t7mrgmescc1	Frère Hervé	+237673525543	\N	\N	2026-09-21 08:05:56.57	2026-09-21 08:05:56.57
cmuaynqrx01jl71kezckrc5fu	cmu2kzqeu00055t7mrgmescc1	GASSU Loic	+237692777382	\N	\N	2026-09-21 08:05:56.685	2026-09-21 08:05:56.685
cmuaynqs601jn71ke1fkif6u1	cmu2kzqeu00055t7mrgmescc1	GASSU Loic	+237692777382	\N	\N	2026-09-21 08:05:56.694	2026-09-21 08:05:56.694
cmuaynqvt01jp71kepob1c7gm	cmu2kzqeu00055t7mrgmescc1	GEN-PUB ELECTRONICS	+23780297124	\N	\N	2026-09-21 08:05:56.825	2026-09-21 08:05:56.825
cmuaynqw001jr71kepaew0f6w	cmu2kzqeu00055t7mrgmescc1	GEN-PUB ELECTRONICS	+23780297124	\N	\N	2026-09-21 08:05:56.832	2026-09-21 08:05:56.832
cmuaynqzi01jt71ked3ui7xkm	cmu2kzqeu00055t7mrgmescc1	Gabango❤️	+237691272449	\N	\N	2026-09-21 08:05:56.958	2026-09-21 08:05:56.958
cmuaynqzp01jv71kexq9sd9zs	cmu2kzqeu00055t7mrgmescc1	Gabango❤️	+237691272449	\N	\N	2026-09-21 08:05:56.965	2026-09-21 08:05:56.965
cmuaynr2r01jx71keuq055vqx	cmu2kzqeu00055t7mrgmescc1	Gabin	+237698444388	\N	\N	2026-09-21 08:05:57.076	2026-09-21 08:05:57.076
cmuaynr3101jz71kevunfalpz	cmu2kzqeu00055t7mrgmescc1	Gabin	+237698444388	\N	\N	2026-09-21 08:05:57.085	2026-09-21 08:05:57.085
cmuaynr6e01k171ke2rev92hq	cmu2kzqeu00055t7mrgmescc1	Gabriel	+237674718923	\N	\N	2026-09-21 08:05:57.206	2026-09-21 08:05:57.206
cmuaynr6m01k371keh6tu4gfj	cmu2kzqeu00055t7mrgmescc1	Gabriel	+237674718923	\N	\N	2026-09-21 08:05:57.214	2026-09-21 08:05:57.214
cmuaynr9p01k571keirzphyrf	cmu2kzqeu00055t7mrgmescc1	Gassu Loic	+237690812305	\N	\N	2026-09-21 08:05:57.325	2026-09-21 08:05:57.325
cmuaynr9x01k771kew0zfk5ne	cmu2kzqeu00055t7mrgmescc1	Gassu Loic	+237690812305	\N	\N	2026-09-21 08:05:57.333	2026-09-21 08:05:57.333
cmuaynrde01k971keb5ej7st8	cmu2kzqeu00055t7mrgmescc1	Gieee🫶🏽💕🎲🎲🎲	+237693688707	\N	\N	2026-09-21 08:05:57.458	2026-09-21 16:27:39.445
cmuaynrds01kb71keipu55ynz	cmu2kzqeu00055t7mrgmescc1	Georgie Fam	+237693688707	\N	\N	2026-09-21 08:05:57.472	2026-09-21 08:05:57.472
cmuaynrj501kd71ke0rdvueet	cmu2kzqeu00055t7mrgmescc1	Ghislaine	+237652824775	\N	\N	2026-09-21 08:05:57.665	2026-09-21 08:05:57.665
cmuaynrjf01kf71ke2be0akex	cmu2kzqeu00055t7mrgmescc1	Ghislaine	+237652824775	\N	\N	2026-09-21 08:05:57.675	2026-09-21 08:05:57.675
cmuaynrmv01kh71ke96ok7u35	cmu2kzqeu00055t7mrgmescc1	Gibson	+254108095311	\N	\N	2026-09-21 08:05:57.799	2026-09-21 08:05:57.799
cmuaynrn601kj71keiedwhv9m	cmu2kzqeu00055t7mrgmescc1	Gibson	+254108095311	\N	\N	2026-09-21 08:05:57.81	2026-09-21 08:05:57.81
cmuaynrsv01kl71ke2qftlyrp	cmu2kzqeu00055t7mrgmescc1	Ma Maney	+237683286769	\N	\N	2026-09-21 08:05:58.015	2026-09-21 16:27:52.772
cmuaynrt401kn71ke5p6lqdzb	cmu2kzqeu00055t7mrgmescc1	Glory	+237683286769	\N	\N	2026-09-21 08:05:58.024	2026-09-21 08:05:58.024
cmuaynrwf01kp71keowy3naev	cmu2kzqeu00055t7mrgmescc1	Glory Ef	+237670511242	\N	\N	2026-09-21 08:05:58.144	2026-09-21 08:05:58.144
cmuaynrwn01kr71keg48qw0sj	cmu2kzqeu00055t7mrgmescc1	Glory Ef	+237670511242	\N	\N	2026-09-21 08:05:58.152	2026-09-21 08:05:58.152
cmuaynrzs01kt71ke3k21s3bk	cmu2kzqeu00055t7mrgmescc1	Glory💎	+237656035094	\N	\N	2026-09-21 08:05:58.265	2026-09-21 08:05:58.265
cmuayns0001kv71ke18pmrsw7	cmu2kzqeu00055t7mrgmescc1	Glory💎	+237656035094	\N	\N	2026-09-21 08:05:58.272	2026-09-21 08:05:58.272
cmuayns3s01kx71ke7ocfdmwt	cmu2kzqeu00055t7mrgmescc1	Gouverneur De londre🪐🦅🌙	+237681413586	\N	\N	2026-09-21 08:05:58.408	2026-09-21 08:05:58.408
cmuayns4001kz71keq9ct5frl	cmu2kzqeu00055t7mrgmescc1	Gouverneur De londre🪐🦅🌙	+237681413586	\N	\N	2026-09-21 08:05:58.417	2026-09-21 08:05:58.417
cmuaynsac01l171keirg3yagn	cmu2kzqeu00055t7mrgmescc1	Grace	+237676982178	\N	\N	2026-09-21 08:05:58.645	2026-09-21 08:05:58.645
cmuaynsak01l371ke3s1jqh4h	cmu2kzqeu00055t7mrgmescc1	Grace	+237676982178	\N	\N	2026-09-21 08:05:58.652	2026-09-21 08:05:58.652
cmuaynsk801l571kerzvc1flr	cmu2kzqeu00055t7mrgmescc1	Grace 🥰	+237694877716	\N	\N	2026-09-21 08:05:59	2026-09-21 08:05:59
cmuaynslx01l771kebne2vtzv	cmu2kzqeu00055t7mrgmescc1	Grace 🥰	+237694877716	\N	\N	2026-09-21 08:05:59.061	2026-09-21 08:05:59.061
cmuaynstq01l971ke7jmy66ii	cmu2kzqeu00055t7mrgmescc1	Gran Shoppe	+237677790584	\N	\N	2026-09-21 08:05:59.342	2026-09-21 08:05:59.342
cmuaynstx01lb71kemmzol5gi	cmu2kzqeu00055t7mrgmescc1	Gran Shoppe	+237677790584	\N	\N	2026-09-21 08:05:59.349	2026-09-21 08:05:59.349
cmuaynsxw01ld71kek2gwrrnx	cmu2kzqeu00055t7mrgmescc1	Grand Prospy🤞	+237676688673	\N	\N	2026-09-21 08:05:59.493	2026-09-21 08:05:59.493
cmuaynsz301lf71ke62l0m7ce	cmu2kzqeu00055t7mrgmescc1	Grand Prospy🤞	+237676688673	\N	\N	2026-09-21 08:05:59.535	2026-09-21 08:05:59.535
cmuaynt2y01lh71ke3e3blk2w	cmu2kzqeu00055t7mrgmescc1	Gustave	+237673810901	\N	\N	2026-09-21 08:05:59.674	2026-09-21 08:05:59.674
cmuaynt3601lj71keaaiu18c9	cmu2kzqeu00055t7mrgmescc1	Gustave	+237673810901	\N	\N	2026-09-21 08:05:59.682	2026-09-21 08:05:59.682
cmuaynt6f01ll71keax5yk5gj	cmu2kzqeu00055t7mrgmescc1	Happiness❤️💓🥰	+237680612870	\N	\N	2026-09-21 08:05:59.799	2026-09-21 08:05:59.799
cmuaynt6o01ln71kea3y126cz	cmu2kzqeu00055t7mrgmescc1	Happiness❤️💓🥰	+237680612870	\N	\N	2026-09-21 08:05:59.808	2026-09-21 08:05:59.808
cmuaynta601lp71kecigufz2q	cmu2kzqeu00055t7mrgmescc1	Harry B🫶🦋🌹	+237673805299	\N	\N	2026-09-21 08:05:59.934	2026-09-21 08:05:59.934
cmuayntaf01lr71kezypq8ote	cmu2kzqeu00055t7mrgmescc1	Harry B🫶🦋🌹	+237673805299	\N	\N	2026-09-21 08:05:59.944	2026-09-21 08:05:59.944
cmuayntdp01lt71kebdsyyzd3	cmu2kzqeu00055t7mrgmescc1	Hashley❤️🍀	+237691453786	\N	\N	2026-09-21 08:06:00.061	2026-09-21 08:06:00.061
cmuayntdw01lv71ke9b1b87j0	cmu2kzqeu00055t7mrgmescc1	Hashley❤️🍀	+237691453786	\N	\N	2026-09-21 08:06:00.068	2026-09-21 08:06:00.068
cmuaynth601lx71keisv5hp3p	cmu2kzqeu00055t7mrgmescc1	Herbal Solutions	+237674547323	\N	\N	2026-09-21 08:06:00.186	2026-09-21 08:06:00.186
cmuaynthf01lz71kehfrahd3m	cmu2kzqeu00055t7mrgmescc1	Herbal Solutions	+237674547323	\N	\N	2026-09-21 08:06:00.195	2026-09-21 08:06:00.195
cmuayntko01m171kep9axup34	cmu2kzqeu00055t7mrgmescc1	Hiulda	+237653540463	\N	\N	2026-09-21 08:06:00.312	2026-09-21 08:06:00.312
cmuayntkv01m371ke5e798930	cmu2kzqeu00055t7mrgmescc1	Hiulda	+237653540463	\N	\N	2026-09-21 08:06:00.319	2026-09-21 08:06:00.319
cmuayntoi01m571kedt6glvro	cmu2kzqeu00055t7mrgmescc1	Hk	+237670754317	\N	\N	2026-09-21 08:06:00.45	2026-09-21 08:06:00.45
cmuayntor01m771kete2twsa0	cmu2kzqeu00055t7mrgmescc1	Hk	+237670754317	\N	\N	2026-09-21 08:06:00.459	2026-09-21 08:06:00.459
cmuayntww01m971keavhftwdi	cmu2kzqeu00055t7mrgmescc1	Ma Dylan	+23752557463	\N	\N	2026-09-21 08:06:00.752	2026-09-21 16:27:52.537
cmuayntx501mb71kew1jq7pkp	cmu2kzqeu00055t7mrgmescc1	Honorine	+23752557463	\N	\N	2026-09-21 08:06:00.761	2026-09-21 08:06:00.761
cmuaynu0201md71kentrrt34i	cmu2kzqeu00055t7mrgmescc1	Horace Toukem	+237691601846	\N	\N	2026-09-21 08:06:00.866	2026-09-21 08:06:00.866
cmuaynu0c01mf71kesf66eqzz	cmu2kzqeu00055t7mrgmescc1	Horace Toukem	+237691601846	\N	\N	2026-09-21 08:06:00.877	2026-09-21 08:06:00.877
cmuaynu3k01mh71kesj11xghj	cmu2kzqeu00055t7mrgmescc1	Hortense ❤️🥰	+237694301507	\N	\N	2026-09-21 08:06:00.993	2026-09-21 08:06:00.993
cmuaynu3s01mj71ke2cl5gznm	cmu2kzqeu00055t7mrgmescc1	Hortense ❤️🥰	+237694301507	\N	\N	2026-09-21 08:06:01.001	2026-09-21 08:06:01.001
cmuaynu8001ml71keap1stgy2	cmu2kzqeu00055t7mrgmescc1	Hpc Ma Fille☘️✅	+237679238772	\N	\N	2026-09-21 08:06:01.152	2026-09-21 08:06:01.152
cmuaynu8901mn71ketf7l8prb	cmu2kzqeu00055t7mrgmescc1	Hpc Ma Fille☘️✅	+237679238772	\N	\N	2026-09-21 08:06:01.161	2026-09-21 08:06:01.161
cmuaynuee01mp71ke9grqn79c	cmu2kzqeu00055t7mrgmescc1	Ibrahim	+237678020438	\N	\N	2026-09-21 08:06:01.382	2026-09-21 08:06:01.382
cmuaynuep01mr71keyxvcgvqi	cmu2kzqeu00055t7mrgmescc1	Ibrahim	+237678020438	\N	\N	2026-09-21 08:06:01.393	2026-09-21 08:06:01.393
cmuaynui501mt71ke9cxmmit6	cmu2kzqeu00055t7mrgmescc1	Ico.Nk♻️	+237693712797	\N	\N	2026-09-21 08:06:01.517	2026-09-21 08:06:01.517
cmuaynuij01mv71ke5v0il4pc	cmu2kzqeu00055t7mrgmescc1	Ico.Nk♻️	+237693712797	\N	\N	2026-09-21 08:06:01.532	2026-09-21 08:06:01.532
cmuaynum401mx71keiqrjlyd0	cmu2kzqeu00055t7mrgmescc1	Igb Mic	+237681842983	\N	\N	2026-09-21 08:06:01.661	2026-09-21 08:06:01.661
cmuaynumd01mz71kegiial0xo	cmu2kzqeu00055t7mrgmescc1	Igb Mic	+237681842983	\N	\N	2026-09-21 08:06:01.669	2026-09-21 08:06:01.669
cmuaynupt01n171kedhmi2bkx	cmu2kzqeu00055t7mrgmescc1	Ingrid	+237655411686	\N	\N	2026-09-21 08:06:01.794	2026-09-21 08:06:01.794
cmuaynuq201n371ke9vzmz4gf	cmu2kzqeu00055t7mrgmescc1	Ingrid	+237655411686	\N	\N	2026-09-21 08:06:01.802	2026-09-21 08:06:01.802
cmuaynuto01n571kebf993mqb	cmu2kzqeu00055t7mrgmescc1	Inouss	+2250720603695	\N	\N	2026-09-21 08:06:01.932	2026-09-21 08:06:01.932
cmuaynuty01n771kefano3vdk	cmu2kzqeu00055t7mrgmescc1	Inouss	+2250720603695	\N	\N	2026-09-21 08:06:01.942	2026-09-21 08:06:01.942
cmuaynuxg01n971ke6qivbvcd	cmu2kzqeu00055t7mrgmescc1	Irine Ekayung	+13464601069	\N	\N	2026-09-21 08:06:02.068	2026-09-21 08:06:02.068
cmuaynuxq01nb71ke6euw2xm7	cmu2kzqeu00055t7mrgmescc1	Irine Ekayung	+13464601069	\N	\N	2026-09-21 08:06:02.078	2026-09-21 08:06:02.078
cmuaynvk501nd71ket4av24b3	cmu2kzqeu00055t7mrgmescc1	Ismaila cesar	+237694326363	\N	\N	2026-09-21 08:06:02.885	2026-09-21 08:06:02.885
cmuaynvke01nf71keqhm9xvnv	cmu2kzqeu00055t7mrgmescc1	Ismaila cesar	+237694326363	\N	\N	2026-09-21 08:06:02.894	2026-09-21 08:06:02.894
cmuaynvnt01nh71kesgp0ami6	cmu2kzqeu00055t7mrgmescc1	Issa	+237673190839	\N	\N	2026-09-21 08:06:03.017	2026-09-21 08:06:03.017
cmuaynvo301nj71kequwy1gqy	cmu2kzqeu00055t7mrgmescc1	Issa	+237673190839	\N	\N	2026-09-21 08:06:03.027	2026-09-21 08:06:03.027
cmuaynvre01nl71kevd4ekjrn	cmu2kzqeu00055t7mrgmescc1	Issouf Valian 🇧🇫� ���🇯	+22674853246	\N	\N	2026-09-21 08:06:03.147	2026-09-21 08:06:03.147
cmuaynvrn01nn71kexlw0wbtf	cmu2kzqeu00055t7mrgmescc1	Issouf Valian 🇧🇫� ���🇯	+22674853246	\N	\N	2026-09-21 08:06:03.155	2026-09-21 08:06:03.155
cmuaynvwy01np71ke51s4ae5w	cmu2kzqeu00055t7mrgmescc1	Itachi Uchiwa	+237691087464	\N	\N	2026-09-21 08:06:03.346	2026-09-21 08:06:03.346
cmuaynvxa01nr71kebjysg5el	cmu2kzqeu00055t7mrgmescc1	Itachi Uchiwa	+237691087464	\N	\N	2026-09-21 08:06:03.358	2026-09-21 08:06:03.358
cmuaynw6901nt71ke9uhttjpq	cmu2kzqeu00055t7mrgmescc1	Itz Blessing 🥰😘	+237679496805	\N	\N	2026-09-21 08:06:03.681	2026-09-21 08:06:03.681
cmuaynw6i01nv71kesi94l6jg	cmu2kzqeu00055t7mrgmescc1	Itz Blessing 🥰😘	+237679496805	\N	\N	2026-09-21 08:06:03.69	2026-09-21 08:06:03.69
cmuaynwal01nx71keq8yq8dh7	cmu2kzqeu00055t7mrgmescc1	Ivan Bounya	+237680681777	\N	\N	2026-09-21 08:06:03.837	2026-09-21 08:06:03.837
cmuaynwat01nz71kegbfllvf4	cmu2kzqeu00055t7mrgmescc1	Ivan Bounya	+237680681777	\N	\N	2026-09-21 08:06:03.846	2026-09-21 08:06:03.846
cmuaynwe001o171kej99rjj6s	cmu2kzqeu00055t7mrgmescc1	Ivo	+23757982570	\N	\N	2026-09-21 08:06:03.96	2026-09-21 08:06:03.96
cmuaynwe701o371ke8i4c4wyw	cmu2kzqeu00055t7mrgmescc1	Ivo	+23757982570	\N	\N	2026-09-21 08:06:03.967	2026-09-21 08:06:03.967
cmuaynwh901o571ke526wtvta	cmu2kzqeu00055t7mrgmescc1	Ivo Akunji	+237678232694	\N	\N	2026-09-21 08:06:04.077	2026-09-21 08:06:04.077
cmuaynwhf01o771kekubyl8q7	cmu2kzqeu00055t7mrgmescc1	Ivo Akunji	+237678232694	\N	\N	2026-09-21 08:06:04.084	2026-09-21 08:06:04.084
cmuaynwkq01o971ke2vdroqv7	cmu2kzqeu00055t7mrgmescc1	J	+237682053127	\N	\N	2026-09-21 08:06:04.202	2026-09-21 08:06:04.202
cmuaynwkx01ob71keju4qbdtu	cmu2kzqeu00055t7mrgmescc1	J	+237682053127	\N	\N	2026-09-21 08:06:04.21	2026-09-21 08:06:04.21
cmuaynwob01od71kew4qz8him	cmu2kzqeu00055t7mrgmescc1	JABKEL GRACE...	+237672681108	\N	\N	2026-09-21 08:06:04.331	2026-09-21 08:06:04.331
cmuaynwok01of71ket9x2z551	cmu2kzqeu00055t7mrgmescc1	JABKEL GRACE...	+237672681108	\N	\N	2026-09-21 08:06:04.34	2026-09-21 08:06:04.34
cmuaynwry01oh71ke6jyesd5t	cmu2kzqeu00055t7mrgmescc1	JC SHOP	+237680301768	\N	\N	2026-09-21 08:06:04.462	2026-09-21 08:06:04.462
cmuaynws901oj71ke4skrqd19	cmu2kzqeu00055t7mrgmescc1	JC SHOP	+237680301768	\N	\N	2026-09-21 08:06:04.473	2026-09-21 08:06:04.473
cmuaynwvj01ol71keuvjqt7st	cmu2kzqeu00055t7mrgmescc1	JD	+237691821607	\N	\N	2026-09-21 08:06:04.591	2026-09-21 08:06:04.591
cmuaynwvu01on71keqyhz5tnp	cmu2kzqeu00055t7mrgmescc1	JD	+237691821607	\N	\N	2026-09-21 08:06:04.602	2026-09-21 08:06:04.602
cmuaynwyx01op71ke3n2sp3yj	cmu2kzqeu00055t7mrgmescc1	JR LE BOSS♥️🏴‍☠️	+2250555975588	\N	\N	2026-09-21 08:06:04.713	2026-09-21 08:06:04.713
cmuaynwz801or71ket73k833n	cmu2kzqeu00055t7mrgmescc1	JR LE BOSS♥️🏴‍☠️	+2250555975588	\N	\N	2026-09-21 08:06:04.724	2026-09-21 08:06:04.724
cmuaynx2o01ot71keslyn2blr	cmu2kzqeu00055t7mrgmescc1	JUNIOR BUSINESS	+22674742676	\N	\N	2026-09-21 08:06:04.848	2026-09-21 08:06:04.848
cmuaynx2w01ov71keao8i46ta	cmu2kzqeu00055t7mrgmescc1	JUNIOR BUSINESS	+22674742676	\N	\N	2026-09-21 08:06:04.856	2026-09-21 08:06:04.856
cmuaynx5x01ox71kenp0tmpjf	cmu2kzqeu00055t7mrgmescc1	JUWAN	+237651445607	\N	\N	2026-09-21 08:06:04.965	2026-09-21 08:06:04.965
cmuaynx6901oz71kejbrsia6s	cmu2kzqeu00055t7mrgmescc1	JUWAN	+237651445607	\N	\N	2026-09-21 08:06:04.977	2026-09-21 08:06:04.977
cmuaynx9m01p171keot6whtna	cmu2kzqeu00055t7mrgmescc1	Jackson Etwii	+237682845158	\N	\N	2026-09-21 08:06:05.099	2026-09-21 08:06:05.099
cmuaynx9x01p371keunle9hfv	cmu2kzqeu00055t7mrgmescc1	Jackson Etwii	+237682845158	\N	\N	2026-09-21 08:06:05.109	2026-09-21 08:06:05.109
cmuaynxcx01p571kessz4gvbm	cmu2kzqeu00055t7mrgmescc1	Jagoo Vibes	+237678863045	\N	\N	2026-09-21 08:06:05.217	2026-09-21 08:06:05.217
cmuaynxd701p771ke2wdgy9gg	cmu2kzqeu00055t7mrgmescc1	Jagoo Vibes	+237678863045	\N	\N	2026-09-21 08:06:05.227	2026-09-21 08:06:05.227
cmuaynxgj01p971kerebj4pez	cmu2kzqeu00055t7mrgmescc1	James	+237672842946	\N	\N	2026-09-21 08:06:05.347	2026-09-21 08:06:05.347
cmuaynxgx01pb71ke2gy3ouwn	cmu2kzqeu00055t7mrgmescc1	James	+237672842946	\N	\N	2026-09-21 08:06:05.361	2026-09-21 08:06:05.361
cmuaynxki01pd71ke16ubxp1g	cmu2kzqeu00055t7mrgmescc1	Japhet	+237681146824	\N	\N	2026-09-21 08:06:05.49	2026-09-21 08:06:05.49
cmuaynxkp01pf71keh1mdpezg	cmu2kzqeu00055t7mrgmescc1	Japhet	+237681146824	\N	\N	2026-09-21 08:06:05.497	2026-09-21 08:06:05.497
cmuaynxnx01ph71keqdp0kh0h	cmu2kzqeu00055t7mrgmescc1	Jessica	+237651422760	\N	\N	2026-09-21 08:06:05.613	2026-09-21 08:06:05.613
cmuaynxo701pj71kew9wm0s9y	cmu2kzqeu00055t7mrgmescc1	Jessica	+237651422760	\N	\N	2026-09-21 08:06:05.623	2026-09-21 08:06:05.623
cmuaynxr201pl71kejx2l3k6s	cmu2kzqeu00055t7mrgmescc1	Jessica 🇨🇲	+237656914252	\N	\N	2026-09-21 08:06:05.727	2026-09-21 08:06:05.727
cmuaynxra01pn71kepovoc4mz	cmu2kzqeu00055t7mrgmescc1	Jessica 🇨🇲	+237656914252	\N	\N	2026-09-21 08:06:05.734	2026-09-21 08:06:05.734
cmuaynxuu01pp71kevhyrlu1m	cmu2kzqeu00055t7mrgmescc1	Jessie Ta Poupee	+237694073418	\N	\N	2026-09-21 08:06:05.863	2026-09-21 08:06:05.863
cmuaynxv401pr71kegi5a1nge	cmu2kzqeu00055t7mrgmescc1	Jessie Ta Poupee	+237694073418	\N	\N	2026-09-21 08:06:05.872	2026-09-21 08:06:05.872
cmuaynxy601pt71ke4ll62ba8	cmu2kzqeu00055t7mrgmescc1	Jj	+237691348330	\N	\N	2026-09-21 08:06:05.982	2026-09-21 08:06:05.982
cmuaynxye01pv71ked2yg4c4t	cmu2kzqeu00055t7mrgmescc1	Jj	+237691348330	\N	\N	2026-09-21 08:06:05.991	2026-09-21 08:06:05.991
cmuayny7i01px71keatqiyb77	cmu2kzqeu00055t7mrgmescc1	Job	+237670227680	\N	\N	2026-09-21 08:06:06.318	2026-09-21 08:06:06.318
cmuayny7q01pz71ke6km4jqb5	cmu2kzqeu00055t7mrgmescc1	Job	+237670227680	\N	\N	2026-09-21 08:06:06.327	2026-09-21 08:06:06.327
cmuaynyb501q171ke19g9f8rf	cmu2kzqeu00055t7mrgmescc1	Job 1	+237676751148	\N	\N	2026-09-21 08:06:06.449	2026-09-21 08:06:06.449
cmuaynybe01q371ke2f4ii9tl	cmu2kzqeu00055t7mrgmescc1	Job 1	+237676751148	\N	\N	2026-09-21 08:06:06.459	2026-09-21 08:06:06.459
cmuaynyeg01q571keyjk5m8l3	cmu2kzqeu00055t7mrgmescc1	Job 2	+237656605540	\N	\N	2026-09-21 08:06:06.568	2026-09-21 08:06:06.568
cmuaynyep01q771kelc08z0o3	cmu2kzqeu00055t7mrgmescc1	Job 2	+237656605540	\N	\N	2026-09-21 08:06:06.577	2026-09-21 08:06:06.577
cmuaynyi101q971kec6qtmqix	cmu2kzqeu00055t7mrgmescc1	Johana 🇨🇲🫂	+237693228991	\N	\N	2026-09-21 08:06:06.697	2026-09-21 08:06:06.697
cmuaynyie01qb71kea6gjn2d9	cmu2kzqeu00055t7mrgmescc1	Johana 🇨🇲🫂	+237693228991	\N	\N	2026-09-21 08:06:06.71	2026-09-21 08:06:06.71
cmuaynynx01qd71ke6dmxj092	cmu2kzqeu00055t7mrgmescc1	Johanna😚	+237681385261	\N	\N	2026-09-21 08:06:06.91	2026-09-21 08:06:06.91
cmuaynyo501qf71ke7jobrltu	cmu2kzqeu00055t7mrgmescc1	Johanna😚	+237681385261	\N	\N	2026-09-21 08:06:06.917	2026-09-21 08:06:06.917
cmuaynys001qh71ke7k75ghv0	cmu2kzqeu00055t7mrgmescc1	Jordan 😌	+237656688191	\N	\N	2026-09-21 08:06:07.056	2026-09-21 08:06:07.056
cmuaynys701qj71keqbn6alqk	cmu2kzqeu00055t7mrgmescc1	Jordan 😌	+237656688191	\N	\N	2026-09-21 08:06:07.064	2026-09-21 08:06:07.064
cmuaynyyz01ql71ke7xnaosvg	cmu2kzqeu00055t7mrgmescc1	Josiane	+23795475945	\N	\N	2026-09-21 08:06:07.307	2026-09-21 08:06:07.307
cmuaynyz601qn71ketqtupety	cmu2kzqeu00055t7mrgmescc1	Josiane	+23795475945	\N	\N	2026-09-21 08:06:07.315	2026-09-21 08:06:07.315
cmuaynz3001qp71ke9dbic9bq	cmu2kzqeu00055t7mrgmescc1	Jovis	+237652251906	\N	\N	2026-09-21 08:06:07.452	2026-09-21 08:06:07.452
cmuaynz3801qr71kez3pas7cz	cmu2kzqeu00055t7mrgmescc1	Jovis	+237652251906	\N	\N	2026-09-21 08:06:07.46	2026-09-21 08:06:07.46
cmuaynz6801qt71kej00e8rye	cmu2kzqeu00055t7mrgmescc1	Joy	+237680354018	\N	\N	2026-09-21 08:06:07.568	2026-09-21 08:06:07.568
cmuaynz6i01qv71kep1razak2	cmu2kzqeu00055t7mrgmescc1	Joy	+237680354018	\N	\N	2026-09-21 08:06:07.578	2026-09-21 08:06:07.578
cmuaynz9t01qx71ke9ofp2dop	cmu2kzqeu00055t7mrgmescc1	Smallie ❤️❤️	+237680599531	\N	\N	2026-09-21 08:06:07.697	2026-09-21 16:28:09.664
cmuaynza601qz71kelvrqrh0s	cmu2kzqeu00055t7mrgmescc1	Joy  2	+237680599531	\N	\N	2026-09-21 08:06:07.71	2026-09-21 08:06:07.71
cmuaynzdg01r171ke5apmbf59	cmu2kzqeu00055t7mrgmescc1	Joy Sävãgë 💕❣️	+237652569962	\N	\N	2026-09-21 08:06:07.828	2026-09-21 08:06:07.828
cmuaynzdu01r371ke76cvzsqk	cmu2kzqeu00055t7mrgmescc1	Joy Sävãgë 💕❣️	+237652569962	\N	\N	2026-09-21 08:06:07.843	2026-09-21 08:06:07.843
cmuaynzhc01r571kewaiaycek	cmu2kzqeu00055t7mrgmescc1	Joy 💞💕	+237683767769	\N	\N	2026-09-21 08:06:07.968	2026-09-21 08:06:07.968
cmuaynzhk01r771kez9b2nsld	cmu2kzqeu00055t7mrgmescc1	Joy 💞💕	+237683767769	\N	\N	2026-09-21 08:06:07.976	2026-09-21 08:06:07.976
cmuaynzkx01r971ke89ea00nw	cmu2kzqeu00055t7mrgmescc1	Joyce🥲	+237657604111	\N	\N	2026-09-21 08:06:08.098	2026-09-21 08:06:08.098
cmuaynzl701rb71kekw3hchnn	cmu2kzqeu00055t7mrgmescc1	Joyce🥲	+237657604111	\N	\N	2026-09-21 08:06:08.107	2026-09-21 08:06:08.107
cmuaynzok01rd71ke81olqsl0	cmu2kzqeu00055t7mrgmescc1	Junior	+237671303444	\N	\N	2026-09-21 08:06:08.229	2026-09-21 08:06:08.229
cmuaynzov01rf71ked89owdfg	cmu2kzqeu00055t7mrgmescc1	Junior	+237671303444	\N	\N	2026-09-21 08:06:08.24	2026-09-21 08:06:08.24
cmuaynzs301rh71ke53u8dhzc	cmu2kzqeu00055t7mrgmescc1	Junior Musician	+237674526952	\N	\N	2026-09-21 08:06:08.355	2026-09-21 08:06:08.355
cmuaynzsa01rj71kesd49kad4	cmu2kzqeu00055t7mrgmescc1	Junior Musician	+237674526952	\N	\N	2026-09-21 08:06:08.363	2026-09-21 08:06:08.363
cmuaynzvh01rl71kesg4iya9d	cmu2kzqeu00055t7mrgmescc1	Just Me	+237657863522	\N	\N	2026-09-21 08:06:08.477	2026-09-21 08:06:08.477
cmuaynzvp01rn71ke9yf9jphj	cmu2kzqeu00055t7mrgmescc1	Just Me	+237657863522	\N	\N	2026-09-21 08:06:08.485	2026-09-21 08:06:08.485
cmuaynzz201rp71kefh9pft23	cmu2kzqeu00055t7mrgmescc1	Just Me 🇫🇷	+237657750946	\N	\N	2026-09-21 08:06:08.607	2026-09-21 08:06:08.607
cmuaynzz901rr71kezre3lnp7	cmu2kzqeu00055t7mrgmescc1	Just Me 🇫🇷	+237657750946	\N	\N	2026-09-21 08:06:08.613	2026-09-21 08:06:08.613
cmuayo02m01rt71kex72s2psj	cmu2kzqeu00055t7mrgmescc1	Juvanel😊	+237678232602	\N	\N	2026-09-21 08:06:08.734	2026-09-21 08:06:08.734
cmuayo02v01rv71ken7pv1a1h	cmu2kzqeu00055t7mrgmescc1	Juvanel😊	+237678232602	\N	\N	2026-09-21 08:06:08.743	2026-09-21 08:06:08.743
cmuayo06401rx71kevp6i76p1	cmu2kzqeu00055t7mrgmescc1	K.D❤️.🇨🇦.✝️	+237697094147	\N	\N	2026-09-21 08:06:08.86	2026-09-21 08:06:08.86
cmuayo06b01rz71keacgu3ae4	cmu2kzqeu00055t7mrgmescc1	K.D❤️.🇨🇦.✝️	+237697094147	\N	\N	2026-09-21 08:06:08.868	2026-09-21 08:06:08.868
cmuayo0bk01s171ke2zwgkg8e	cmu2kzqeu00055t7mrgmescc1	Kachou❣️🚨	+237697190815	\N	\N	2026-09-21 08:06:09.057	2026-09-21 08:06:09.057
cmuayo0bs01s371kexskakicm	cmu2kzqeu00055t7mrgmescc1	Kachou❣️🚨	+237697190815	\N	\N	2026-09-21 08:06:09.064	2026-09-21 08:06:09.064
cmuayo0f301s571kex70px75j	cmu2kzqeu00055t7mrgmescc1	Kalai	+237692950012	\N	\N	2026-09-21 08:06:09.183	2026-09-21 08:06:09.183
cmuayo0fd01s771keo4ytg2i3	cmu2kzqeu00055t7mrgmescc1	Kalai	+237692950012	\N	\N	2026-09-21 08:06:09.193	2026-09-21 08:06:09.193
cmuayo0ir01s971keyww9eivh	cmu2kzqeu00055t7mrgmescc1	Kamis Luis	+237675175616	\N	\N	2026-09-21 08:06:09.315	2026-09-21 08:06:09.315
cmuayo0j001sb71ke7jv9ndfm	cmu2kzqeu00055t7mrgmescc1	Kamis Luis	+237675175616	\N	\N	2026-09-21 08:06:09.324	2026-09-21 08:06:09.324
cmuayo0n401sd71ke60z43lbn	cmu2kzqeu00055t7mrgmescc1	Kareem Jalal	+237670973182	\N	\N	2026-09-21 08:06:09.473	2026-09-21 08:06:09.473
cmuayo0nc01sf71keisd1ysep	cmu2kzqeu00055t7mrgmescc1	Kareem Jalal	+237670973182	\N	\N	2026-09-21 08:06:09.48	2026-09-21 08:06:09.48
cmuayo0qr01sh71keasqstq3k	cmu2kzqeu00055t7mrgmescc1	Karim Dif	+237689510317	\N	\N	2026-09-21 08:06:09.603	2026-09-21 08:06:09.603
cmuayo0qz01sj71keb2jznkbi	cmu2kzqeu00055t7mrgmescc1	Karim Dif	+237689510317	\N	\N	2026-09-21 08:06:09.611	2026-09-21 08:06:09.611
cmuayo0ua01sl71kebbehk3qb	cmu2kzqeu00055t7mrgmescc1	Karl Smith	+237692860695	\N	\N	2026-09-21 08:06:09.731	2026-09-21 08:06:09.731
cmuayo0un01sn71kehiklv5de	cmu2kzqeu00055t7mrgmescc1	Karl Smith	+237692860695	\N	\N	2026-09-21 08:06:09.744	2026-09-21 08:06:09.744
cmuayo0xx01sp71keg8pqln5z	cmu2kzqeu00055t7mrgmescc1	Kassim	+237698216512	\N	\N	2026-09-21 08:06:09.861	2026-09-21 08:06:09.861
cmuayo0ya01sr71keujqdcqo5	cmu2kzqeu00055t7mrgmescc1	Kassim	+237698216512	\N	\N	2026-09-21 08:06:09.875	2026-09-21 08:06:09.875
cmuayo11o01st71ke0miyy9qb	cmu2kzqeu00055t7mrgmescc1	Katty	+237698288489	\N	\N	2026-09-21 08:06:09.997	2026-09-21 08:06:09.997
cmuayo11w01sv71ke9xp062b5	cmu2kzqeu00055t7mrgmescc1	Katty	+237698288489	\N	\N	2026-09-21 08:06:10.004	2026-09-21 08:06:10.004
cmuayo15e01sx71kez2i9op6d	cmu2kzqeu00055t7mrgmescc1	Keliane Jj🤞	+237651415022	\N	\N	2026-09-21 08:06:10.13	2026-09-21 08:06:10.13
cmuayo15m01sz71kepthgmghz	cmu2kzqeu00055t7mrgmescc1	Keliane Jj🤞	+237651415022	\N	\N	2026-09-21 08:06:10.138	2026-09-21 08:06:10.138
cmuayo18o01t171kehd2oiwzb	cmu2kzqeu00055t7mrgmescc1	Kellz🤳🏽	+237651791374	\N	\N	2026-09-21 08:06:10.248	2026-09-21 08:06:10.248
cmuayo18w01t371kexli356tk	cmu2kzqeu00055t7mrgmescc1	Kellz🤳🏽	+237651791374	\N	\N	2026-09-21 08:06:10.256	2026-09-21 08:06:10.256
cmuayo1c801t571ke7xi6vdiq	cmu2kzqeu00055t7mrgmescc1	Kendra Belinga📍	+237656324929	\N	\N	2026-09-21 08:06:10.377	2026-09-21 08:06:10.377
cmuayo1cf01t771ke43ubbhqd	cmu2kzqeu00055t7mrgmescc1	Kendra Belinga📍	+237656324929	\N	\N	2026-09-21 08:06:10.383	2026-09-21 08:06:10.383
cmuayo1fz01t971keefsidrc6	cmu2kzqeu00055t7mrgmescc1	Kenzo 🏴‍☠️	+237690889646	\N	\N	2026-09-21 08:06:10.511	2026-09-21 08:06:10.511
cmuayo1gd01tb71kelzwwks9j	cmu2kzqeu00055t7mrgmescc1	Kenzo 🏴‍☠️	+237690889646	\N	\N	2026-09-21 08:06:10.525	2026-09-21 08:06:10.525
cmuayo1k201td71kevvurojpa	cmu2kzqeu00055t7mrgmescc1	Kessy🕉️	+237657449216	\N	\N	2026-09-21 08:06:10.659	2026-09-21 08:06:10.659
cmuayo1ki01tf71kei35xiu3c	cmu2kzqeu00055t7mrgmescc1	Kessy🕉️	+237657449216	\N	\N	2026-09-21 08:06:10.675	2026-09-21 08:06:10.675
cmuayo1o601th71kecauwpzwh	cmu2kzqeu00055t7mrgmescc1	Kevin de lùxe ✨	+237659525380	\N	\N	2026-09-21 08:06:10.806	2026-09-21 08:06:10.806
cmuayo1oc01tj71kej0ul02er	cmu2kzqeu00055t7mrgmescc1	Kevin de lùxe ✨	+237659525380	\N	\N	2026-09-21 08:06:10.812	2026-09-21 08:06:10.812
cmuayo1s001tl71keelaptury	cmu2kzqeu00055t7mrgmescc1	Kim🍀❤️	+237677914809	\N	\N	2026-09-21 08:06:10.944	2026-09-21 08:06:10.944
cmuayo1s801tn71ke3ps18k9k	cmu2kzqeu00055t7mrgmescc1	Kim🍀❤️	+237677914809	\N	\N	2026-09-21 08:06:10.952	2026-09-21 08:06:10.952
cmuayo20601tp71keqf57vskd	cmu2kzqeu00055t7mrgmescc1	King Kako	+237679669333	\N	\N	2026-09-21 08:06:11.238	2026-09-21 08:06:11.238
cmuayo20e01tr71kegc5rgrla	cmu2kzqeu00055t7mrgmescc1	King Kako	+237679669333	\N	\N	2026-09-21 08:06:11.247	2026-09-21 08:06:11.247
cmuayo25b01tt71ke4jyuugj0	cmu2kzqeu00055t7mrgmescc1	Kruger	+23797021761	\N	\N	2026-09-21 08:06:11.423	2026-09-21 08:06:11.423
cmuayo25i01tv71ke1jnhctw8	cmu2kzqeu00055t7mrgmescc1	Kruger	+23797021761	\N	\N	2026-09-21 08:06:11.43	2026-09-21 08:06:11.43
cmuayo28s01tx71kecb249yz4	cmu2kzqeu00055t7mrgmescc1	Kujay	+237680695293	\N	\N	2026-09-21 08:06:11.549	2026-09-21 08:06:11.549
cmuayo29501tz71keqwew2ybr	cmu2kzqeu00055t7mrgmescc1	Kujay	+237680695293	\N	\N	2026-09-21 08:06:11.562	2026-09-21 08:06:11.562
cmuayo2cc01u171ke2q3lfvmn	cmu2kzqeu00055t7mrgmescc1	Kylian Telecom🇨🇲	+237691640110	\N	\N	2026-09-21 08:06:11.676	2026-09-21 08:06:11.676
cmuayo2cj01u371ke69mw4ics	cmu2kzqeu00055t7mrgmescc1	Kylian Telecom🇨🇲	+237691640110	\N	\N	2026-09-21 08:06:11.683	2026-09-21 08:06:11.683
cmuayo2g501u571kepog8v1ov	cmu2kzqeu00055t7mrgmescc1	Kęnzõ Smïth	+237698683120	\N	\N	2026-09-21 08:06:11.813	2026-09-21 08:06:11.813
cmuayo2gd01u771keypw19ccm	cmu2kzqeu00055t7mrgmescc1	Kęnzõ Smïth	+237698683120	\N	\N	2026-09-21 08:06:11.821	2026-09-21 08:06:11.821
cmuayo36501u971keekuaodwj	cmu2kzqeu00055t7mrgmescc1	L'acteur	+237659597254	\N	\N	2026-09-21 08:06:12.749	2026-09-21 08:06:12.749
cmuayo36f01ub71kemecjqzzk	cmu2kzqeu00055t7mrgmescc1	L'acteur	+237659597254	\N	\N	2026-09-21 08:06:12.759	2026-09-21 08:06:12.759
cmuayo39p01ud71kexpsxew8p	cmu2kzqeu00055t7mrgmescc1	LA MASCOTTE	+237655521852	\N	\N	2026-09-21 08:06:12.878	2026-09-21 08:06:12.878
cmuayo39x01uf71kenmbpc8u5	cmu2kzqeu00055t7mrgmescc1	LA MASCOTTE	+237655521852	\N	\N	2026-09-21 08:06:12.885	2026-09-21 08:06:12.885
cmuayo3k201uh71ke4rcr4d7k	cmu2kzqeu00055t7mrgmescc1	LAVERY SHOPE	+237675181103	\N	\N	2026-09-21 08:06:13.25	2026-09-21 08:06:13.25
cmuayo3kb01uj71keluxzz18a	cmu2kzqeu00055t7mrgmescc1	LAVERY SHOPE	+237675181103	\N	\N	2026-09-21 08:06:13.259	2026-09-21 08:06:13.259
cmuayo3nn01ul71ke990obti5	cmu2kzqeu00055t7mrgmescc1	LAndLoRD🏠🛐👻	+237680682065	\N	\N	2026-09-21 08:06:13.38	2026-09-21 08:06:13.38
cmuayo3ny01un71ke5vpgiv7w	cmu2kzqeu00055t7mrgmescc1	LAndLoRD🏠🛐👻	+237680682065	\N	\N	2026-09-21 08:06:13.39	2026-09-21 08:06:13.39
cmuayo3ru01up71key22z0r75	cmu2kzqeu00055t7mrgmescc1	LE FUTUR-DS ❤‍🩹☀️ 🐘😎	+2250799539948	\N	\N	2026-09-21 08:06:13.53	2026-09-21 08:06:13.53
cmuayo3s201ur71kejoy288x9	cmu2kzqeu00055t7mrgmescc1	LE FUTUR-DS ❤‍🩹☀️ 🐘😎	+2250799539948	\N	\N	2026-09-21 08:06:13.538	2026-09-21 08:06:13.538
cmuayo3ve01ut71kereezbaem	cmu2kzqeu00055t7mrgmescc1	LE SUCCÈS	+22951400182	\N	\N	2026-09-21 08:06:13.658	2026-09-21 08:06:13.658
cmuayo3vl01uv71keggvzuzpw	cmu2kzqeu00055t7mrgmescc1	LE SUCCÈS	+22951400182	\N	\N	2026-09-21 08:06:13.666	2026-09-21 08:06:13.666
cmuayo3yp01ux71keu4smh5m1	cmu2kzqeu00055t7mrgmescc1	LOIN SUN 😈😈🔥	+237653879685	\N	\N	2026-09-21 08:06:13.777	2026-09-21 08:06:13.777
cmuayo3yw01uz71ke74aifzhq	cmu2kzqeu00055t7mrgmescc1	LOIN SUN 😈😈🔥	+237653879685	\N	\N	2026-09-21 08:06:13.784	2026-09-21 08:06:13.784
cmuayo42f01v171kev07piwae	cmu2kzqeu00055t7mrgmescc1	La Melo	+237676798771	\N	\N	2026-09-21 08:06:13.911	2026-09-21 08:06:13.911
cmuayo42m01v371kesi8zq2th	cmu2kzqeu00055t7mrgmescc1	La Melo	+237676798771	\N	\N	2026-09-21 08:06:13.918	2026-09-21 08:06:13.918
cmuayo46501v571keczulo434	cmu2kzqeu00055t7mrgmescc1	La Menace	+237679022315	\N	\N	2026-09-21 08:06:14.045	2026-09-21 08:06:14.045
cmuayo46g01v771keyd18838n	cmu2kzqeu00055t7mrgmescc1	La Menace	+237679022315	\N	\N	2026-09-21 08:06:14.056	2026-09-21 08:06:14.056
cmuayo4dz01v971kej2pkwls1	cmu2kzqeu00055t7mrgmescc1	𝐀𝐈𝐙𝐄𝐍 𝐃𝐄́𝐌𝐎𝐍	+237658018320	\N	\N	2026-09-21 08:06:14.327	2026-09-21 16:28:19.329
cmuayo4e701vb71kedu5h2w61	cmu2kzqeu00055t7mrgmescc1	La Pensé📍	+237658018320	\N	\N	2026-09-21 08:06:14.335	2026-09-21 08:06:14.335
cmuayo4hp01vd71kebw5xewta	cmu2kzqeu00055t7mrgmescc1	La Poupée Blanche	+2250777575602	\N	\N	2026-09-21 08:06:14.461	2026-09-21 08:06:14.461
cmuayo4i101vf71kekvqxw2zf	cmu2kzqeu00055t7mrgmescc1	La Poupée Blanche	+2250777575602	\N	\N	2026-09-21 08:06:14.474	2026-09-21 08:06:14.474
cmuayo4lc01vh71keqqoiydni	cmu2kzqeu00055t7mrgmescc1	La Poupée Chinoise😘❤️	+22666742381	\N	\N	2026-09-21 08:06:14.592	2026-09-21 08:06:14.592
cmuayo4lr01vj71kegg25tfnr	cmu2kzqeu00055t7mrgmescc1	La Poupée Chinoise😘❤️	+22666742381	\N	\N	2026-09-21 08:06:14.607	2026-09-21 08:06:14.607
cmuayo4p001vl71kek9g05is4	cmu2kzqeu00055t7mrgmescc1	La rock_star	+237656036411	\N	\N	2026-09-21 08:06:14.725	2026-09-21 08:06:14.725
cmuayo4p901vn71ke7qusqijj	cmu2kzqeu00055t7mrgmescc1	La rock_star	+237656036411	\N	\N	2026-09-21 08:06:14.733	2026-09-21 08:06:14.733
cmuayo4sc01vp71keny8rke4w	cmu2kzqeu00055t7mrgmescc1	Ladope	+237655859481	\N	\N	2026-09-21 08:06:14.844	2026-09-21 08:06:14.844
cmuayo4sj01vr71ke3v3ojk7x	cmu2kzqeu00055t7mrgmescc1	Ladope	+237655859481	\N	\N	2026-09-21 08:06:14.851	2026-09-21 08:06:14.851
cmuayo4vm01vt71keoczv56cd	cmu2kzqeu00055t7mrgmescc1	Laeti	+237691451417	\N	\N	2026-09-21 08:06:14.962	2026-09-21 08:06:14.962
cmuayo4vw01vv71kevapoqif4	cmu2kzqeu00055t7mrgmescc1	Laeti	+237691451417	\N	\N	2026-09-21 08:06:14.972	2026-09-21 08:06:14.972
cmuayo4zg01vx71kete1oskl0	cmu2kzqeu00055t7mrgmescc1	Lamine Yamal 🇪🇸🇪🇸🇦🇷🇦🇷🇦🇷	+2250596354489	\N	\N	2026-09-21 08:06:15.099	2026-09-21 08:06:15.099
cmuayo4zo01vz71kefen696b3	cmu2kzqeu00055t7mrgmescc1	Lamine Yamal 🇪🇸🇪🇸🇦🇷🇦🇷🇦🇷	+2250596354489	\N	\N	2026-09-21 08:06:15.109	2026-09-21 08:06:15.109
cmuayo52w01w171ke680xrwti	cmu2kzqeu00055t7mrgmescc1	Landlord Cg	+237651253998	\N	\N	2026-09-21 08:06:15.225	2026-09-21 08:06:15.225
cmuayo53301w371ke3ol11lwj	cmu2kzqeu00055t7mrgmescc1	Landlord Cg	+237651253998	\N	\N	2026-09-21 08:06:15.231	2026-09-21 08:06:15.231
cmuayo56b01w571kefo7m4je0	cmu2kzqeu00055t7mrgmescc1	Landry Ball Boost	+237690450195	\N	\N	2026-09-21 08:06:15.347	2026-09-21 08:06:15.347
cmuayo56j01w771ke6skhader	cmu2kzqeu00055t7mrgmescc1	Landry Ball Boost	+237690450195	\N	\N	2026-09-21 08:06:15.355	2026-09-21 08:06:15.355
cmuayo59i01w971ke9exbnhlk	cmu2kzqeu00055t7mrgmescc1	Latifah Ndoumi	+237657381036	\N	\N	2026-09-21 08:06:15.463	2026-09-21 08:06:15.463
cmuayo59s01wb71ke79ttfub7	cmu2kzqeu00055t7mrgmescc1	Latifah Ndoumi	+237657381036	\N	\N	2026-09-21 08:06:15.472	2026-09-21 08:06:15.472
cmuayo5db01wd71ke7wg7b5al	cmu2kzqeu00055t7mrgmescc1	Laudivin Danger 😎🥰	+237670987746	\N	\N	2026-09-21 08:06:15.599	2026-09-21 08:06:15.599
cmuayo5dj01wf71ke639gaycp	cmu2kzqeu00055t7mrgmescc1	Laudivin Danger 😎🥰	+237670987746	\N	\N	2026-09-21 08:06:15.608	2026-09-21 08:06:15.608
cmuayo5ko01wh71keu0s1peyp	cmu2kzqeu00055t7mrgmescc1	Laudivin Danger😍😎	+237657076676	\N	\N	2026-09-21 08:06:15.864	2026-09-21 08:06:15.864
cmuayo5l401wj71ke7lzzgogc	cmu2kzqeu00055t7mrgmescc1	Laudivin Danger😍😎	+237657076676	\N	\N	2026-09-21 08:06:15.88	2026-09-21 08:06:15.88
cmuayo5ou01wl71ke9vhrlmyi	cmu2kzqeu00055t7mrgmescc1	Laura🇨🇲	+23775290364	\N	\N	2026-09-21 08:06:16.015	2026-09-21 08:06:16.015
cmuayo5p401wn71ke4amo1wlb	cmu2kzqeu00055t7mrgmescc1	Laura🇨🇲	+23775290364	\N	\N	2026-09-21 08:06:16.025	2026-09-21 08:06:16.025
cmuayo5sg01wp71kesdnrzg1o	cmu2kzqeu00055t7mrgmescc1	Le Général👮👮� �	+2250706575507	\N	\N	2026-09-21 08:06:16.144	2026-09-21 08:06:16.144
cmuayo5ss01wr71kerkot9h5q	cmu2kzqeu00055t7mrgmescc1	Le Général👮👮� �	+2250706575507	\N	\N	2026-09-21 08:06:16.156	2026-09-21 08:06:16.156
cmuayo5we01wt71kewfu0sv5f	cmu2kzqeu00055t7mrgmescc1	Le Mal 😈🔥💀	+237657638781	\N	\N	2026-09-21 08:06:16.286	2026-09-21 08:06:16.286
cmuayo5wn01wv71ken5wcopbi	cmu2kzqeu00055t7mrgmescc1	Le Mal 😈🔥💀	+237657638781	\N	\N	2026-09-21 08:06:16.295	2026-09-21 08:06:16.295
cmuayo60f01wx71kev0327evx	cmu2kzqeu00055t7mrgmescc1	Le Mini Duc	+237654021385	\N	\N	2026-09-21 08:06:16.432	2026-09-21 08:06:16.432
cmuayo60o01wz71ker2gfyqa3	cmu2kzqeu00055t7mrgmescc1	Le Mini Duc	+237654021385	\N	\N	2026-09-21 08:06:16.441	2026-09-21 08:06:16.441
cmuayo63y01x171kecv2mcmwp	cmu2kzqeu00055t7mrgmescc1	Le Mãgrééb	+237694514982	\N	\N	2026-09-21 08:06:16.558	2026-09-21 08:06:16.558
cmuayo64501x371kex7dp1wo0	cmu2kzqeu00055t7mrgmescc1	Le Mãgrééb	+237694514982	\N	\N	2026-09-21 08:06:16.566	2026-09-21 08:06:16.566
cmuayo67801x571kert5cnkny	cmu2kzqeu00055t7mrgmescc1	Le Prince	+23672192175	\N	\N	2026-09-21 08:06:16.677	2026-09-21 08:06:16.677
cmuayo67g01x771ke5ou5qazf	cmu2kzqeu00055t7mrgmescc1	Le Prince	+23672192175	\N	\N	2026-09-21 08:06:16.684	2026-09-21 08:06:16.684
cmuayo6bp01x971ke7aopoq0t	cmu2kzqeu00055t7mrgmescc1	Le Prince 10	+23750954507	\N	\N	2026-09-21 08:06:16.837	2026-09-21 08:06:16.837
cmuayo6bx01xb71kelv7arlav	cmu2kzqeu00055t7mrgmescc1	Le Prince 10	+23750954507	\N	\N	2026-09-21 08:06:16.845	2026-09-21 08:06:16.845
cmuayo6gh01xd71kehcub722w	cmu2kzqeu00055t7mrgmescc1	Le Silencieux	+22507920431	\N	\N	2026-09-21 08:06:17.01	2026-09-21 08:06:17.01
cmuayo6gs01xf71keamk9lqpj	cmu2kzqeu00055t7mrgmescc1	Le Silencieux	+22507920431	\N	\N	2026-09-21 08:06:17.02	2026-09-21 08:06:17.02
cmuayo6lr01xh71keapezgo2z	cmu2kzqeu00055t7mrgmescc1	Le Volume	+237696842610	\N	\N	2026-09-21 08:06:17.199	2026-09-21 08:06:17.199
cmuayo6m301xj71kebonrxfme	cmu2kzqeu00055t7mrgmescc1	Le Volume	+237696842610	\N	\N	2026-09-21 08:06:17.211	2026-09-21 08:06:17.211
cmuayo6rk01xl71ke49fkmbde	cmu2kzqeu00055t7mrgmescc1	Le titi🫠😁	+237690921401	\N	\N	2026-09-21 08:06:17.408	2026-09-21 08:06:17.408
cmuayo6rq01xn71kendvzoov5	cmu2kzqeu00055t7mrgmescc1	Le titi🫠😁	+237690921401	\N	\N	2026-09-21 08:06:17.415	2026-09-21 08:06:17.415
cmuayo6vc01xp71ke835kkt8g	cmu2kzqeu00055t7mrgmescc1	Le 😍😍😍😍	+2250702612369	\N	\N	2026-09-21 08:06:17.544	2026-09-21 08:06:17.544
cmuayo6vk01xr71keb5hr1hjq	cmu2kzqeu00055t7mrgmescc1	Le 😍😍😍😍	+2250702612369	\N	\N	2026-09-21 08:06:17.552	2026-09-21 08:06:17.552
cmuayo70s01xt71ke6rftgyib	cmu2kzqeu00055t7mrgmescc1	Leal	+237653036927	\N	\N	2026-09-21 08:06:17.74	2026-09-21 08:06:17.74
cmuayo70z01xv71keswbks74e	cmu2kzqeu00055t7mrgmescc1	Leal	+237653036927	\N	\N	2026-09-21 08:06:17.747	2026-09-21 08:06:17.747
cmuayo75n01xx71keepx92a5w	cmu2kzqeu00055t7mrgmescc1	Leane 🌸	+237692585545	\N	\N	2026-09-21 08:06:17.915	2026-09-21 08:06:17.915
cmuayo75z01xz71kednag6uso	cmu2kzqeu00055t7mrgmescc1	Leane 🌸	+237692585545	\N	\N	2026-09-21 08:06:17.927	2026-09-21 08:06:17.927
cmuayo7db01y171kecfs071g0	cmu2kzqeu00055t7mrgmescc1	Leen	+237681605059	\N	\N	2026-09-21 08:06:18.191	2026-09-21 08:06:18.191
cmuayo7dt01y371ke15j0sq7v	cmu2kzqeu00055t7mrgmescc1	Leen	+237681605059	\N	\N	2026-09-21 08:06:18.21	2026-09-21 08:06:18.21
cmuayo7jg01y571keuz11q8xg	cmu2kzqeu00055t7mrgmescc1	Lelong 207🇨🇲	+237672879626	\N	\N	2026-09-21 08:06:18.413	2026-09-21 08:06:18.413
cmuayo7jt01y771ke3xv5ytur	cmu2kzqeu00055t7mrgmescc1	Lelong 207🇨🇲	+237672879626	\N	\N	2026-09-21 08:06:18.425	2026-09-21 08:06:18.425
cmuayo7of01y971kehxui77oz	cmu2kzqeu00055t7mrgmescc1	Lena Nk🖇❤️	+237692318623	\N	\N	2026-09-21 08:06:18.591	2026-09-21 08:06:18.591
cmuayo7om01yb71keywk2qcgi	cmu2kzqeu00055t7mrgmescc1	Lena Nk🖇❤️	+237692318623	\N	\N	2026-09-21 08:06:18.598	2026-09-21 08:06:18.598
cmuayo7so01yd71kevnp4w1vt	cmu2kzqeu00055t7mrgmescc1	Lena🇨🇲	+237657302225	\N	\N	2026-09-21 08:06:18.745	2026-09-21 08:06:18.745
cmuayo7sz01yf71kefuyu9z59	cmu2kzqeu00055t7mrgmescc1	Lena🇨🇲	+237657302225	\N	\N	2026-09-21 08:06:18.755	2026-09-21 08:06:18.755
cmuayo7yx01yh71keiqqmyk3e	cmu2kzqeu00055t7mrgmescc1	Leonie	+237689283895	\N	\N	2026-09-21 08:06:18.969	2026-09-21 08:06:18.969
cmuayo7z901yj71kep17h7f42	cmu2kzqeu00055t7mrgmescc1	Leonie	+237689283895	\N	\N	2026-09-21 08:06:18.981	2026-09-21 08:06:18.981
cmuayo85y01yl71ke17h4v822	cmu2kzqeu00055t7mrgmescc1	Lesline ☘️	+237652061013	\N	\N	2026-09-21 08:06:19.222	2026-09-21 08:06:19.222
cmuayo86901yn71kekcvhtmiw	cmu2kzqeu00055t7mrgmescc1	Lesline ☘️	+237652061013	\N	\N	2026-09-21 08:06:19.233	2026-09-21 08:06:19.233
cmuayo8ar01yp71ken8dwv4ug	cmu2kzqeu00055t7mrgmescc1	Leticia	+237679660706	\N	\N	2026-09-21 08:06:19.395	2026-09-21 08:06:19.395
cmuayo8b001yr71key7tfbx88	cmu2kzqeu00055t7mrgmescc1	Leticia	+237679660706	\N	\N	2026-09-21 08:06:19.404	2026-09-21 08:06:19.404
cmuayo8l901yt71ke65iz7aq5	cmu2kzqeu00055t7mrgmescc1	Lety	+237675153027	\N	\N	2026-09-21 08:06:19.773	2026-09-21 08:06:19.773
cmuayo8lg01yv71ke9s9o7wjy	cmu2kzqeu00055t7mrgmescc1	Lety	+237675153027	\N	\N	2026-09-21 08:06:19.78	2026-09-21 08:06:19.78
cmuayo8oq01yx71kect3m6o7n	cmu2kzqeu00055t7mrgmescc1	Lety~chou❤️	+237697707696	\N	\N	2026-09-21 08:06:19.898	2026-09-21 08:06:19.898
cmuayo8oy01yz71kewpv4cm3h	cmu2kzqeu00055t7mrgmescc1	Lety~chou❤️	+237697707696	\N	\N	2026-09-21 08:06:19.906	2026-09-21 08:06:19.906
cmuayo93b01z171kenqqbbq19	cmu2kzqeu00055t7mrgmescc1	Le~14~Officiel....	+237696773765	\N	\N	2026-09-21 08:06:20.424	2026-09-21 08:06:20.424
cmuayo93i01z371kez91krs1o	cmu2kzqeu00055t7mrgmescc1	Le~14~Officiel....	+237696773765	\N	\N	2026-09-21 08:06:20.43	2026-09-21 08:06:20.43
cmuayo96x01z571ketghki9w2	cmu2kzqeu00055t7mrgmescc1	Lilan Angabung	+237678057291	\N	\N	2026-09-21 08:06:20.553	2026-09-21 08:06:20.553
cmuayo97601z771ke13oh6b3l	cmu2kzqeu00055t7mrgmescc1	Lilan Angabung	+237678057291	\N	\N	2026-09-21 08:06:20.562	2026-09-21 08:06:20.562
cmuayo9ap01z971kekqccq03i	cmu2kzqeu00055t7mrgmescc1	Lilcharles😎	+237695987125	\N	\N	2026-09-21 08:06:20.689	2026-09-21 08:06:20.689
cmuayo9b301zb71ke9wm6czju	cmu2kzqeu00055t7mrgmescc1	Lilcharles😎	+237695987125	\N	\N	2026-09-21 08:06:20.703	2026-09-21 08:06:20.703
cmuayo9em01zd71kegvffpwi2	cmu2kzqeu00055t7mrgmescc1	Limbe	+237677809124	\N	\N	2026-09-21 08:06:20.83	2026-09-21 08:06:20.83
cmuayo9ew01zf71kez4qnv7cq	cmu2kzqeu00055t7mrgmescc1	Limbe	+237677809124	\N	\N	2026-09-21 08:06:20.84	2026-09-21 08:06:20.84
cmuayo9id01zh71ke0nye7rzd	cmu2kzqeu00055t7mrgmescc1	Linda	+23709036096515	\N	\N	2026-09-21 08:06:20.965	2026-09-21 08:06:20.965
cmuayo9im01zj71kev6n08sa8	cmu2kzqeu00055t7mrgmescc1	Linda	+23709036096515	\N	\N	2026-09-21 08:06:20.975	2026-09-21 08:06:20.975
cmuayoa2501zl71kehs4ntlg9	cmu2kzqeu00055t7mrgmescc1	Lisa 😍🥰	+2348100771575	\N	\N	2026-09-21 08:06:21.677	2026-09-21 08:06:21.677
cmuayoa3201zn71ke7mq0ebcd	cmu2kzqeu00055t7mrgmescc1	Lisa 😍🥰	+2348100771575	\N	\N	2026-09-21 08:06:21.71	2026-09-21 08:06:21.71
cmuayoa6d01zp71kez9gogb20	cmu2kzqeu00055t7mrgmescc1	Lisa🤍	+237650069423	\N	\N	2026-09-21 08:06:21.829	2026-09-21 08:06:21.829
cmuayoa6m01zr71kefhck1llq	cmu2kzqeu00055t7mrgmescc1	Lisa🤍	+237650069423	\N	\N	2026-09-21 08:06:21.838	2026-09-21 08:06:21.838
cmuayoaab01zt71kew2l3vdha	cmu2kzqeu00055t7mrgmescc1	Lite Top	+237651701413	\N	\N	2026-09-21 08:06:21.972	2026-09-21 08:06:21.972
cmuayoaaj01zv71ke5vcfsdlr	cmu2kzqeu00055t7mrgmescc1	Lite Top	+237651701413	\N	\N	2026-09-21 08:06:21.979	2026-09-21 08:06:21.979
cmuayoae701zx71kenri2kzxy	cmu2kzqeu00055t7mrgmescc1	Lizou 😊	+237678272168	\N	\N	2026-09-21 08:06:22.112	2026-09-21 08:06:22.112
cmuayoaeh01zz71keewz374tt	cmu2kzqeu00055t7mrgmescc1	Lizou 😊	+237678272168	\N	\N	2026-09-21 08:06:22.121	2026-09-21 08:06:22.121
cmuayoahu020171keirfbnqy3	cmu2kzqeu00055t7mrgmescc1	Llil Priest	+237651522224	\N	\N	2026-09-21 08:06:22.242	2026-09-21 08:06:22.242
cmuayoai1020371ke91e5q6ro	cmu2kzqeu00055t7mrgmescc1	Llil Priest	+237651522224	\N	\N	2026-09-21 08:06:22.25	2026-09-21 08:06:22.25
cmuayoal4020571kedi3t0ina	cmu2kzqeu00055t7mrgmescc1	Rr	+237673164519	\N	\N	2026-09-21 08:06:22.36	2026-09-21 16:28:06.515
cmuayoale020771kemuipep91	cmu2kzqeu00055t7mrgmescc1	Lloyd🤳🏽	+237673164519	\N	\N	2026-09-21 08:06:22.37	2026-09-21 08:06:22.37
cmuayoaox020971ke7hiudeuf	cmu2kzqeu00055t7mrgmescc1	Loana	+237692290618	\N	\N	2026-09-21 08:06:22.497	2026-09-21 08:06:22.497
cmuayoap4020b71kebkwiytd3	cmu2kzqeu00055t7mrgmescc1	Loana	+237692290618	\N	\N	2026-09-21 08:06:22.505	2026-09-21 08:06:22.505
cmuayoasx020d71kel31bpxt4	cmu2kzqeu00055t7mrgmescc1	Local Host	+237678279957	\N	\N	2026-09-21 08:06:22.642	2026-09-21 08:06:22.642
cmuayoatc020f71keeanwaae7	cmu2kzqeu00055t7mrgmescc1	Local Host	+237678279957	\N	\N	2026-09-21 08:06:22.656	2026-09-21 08:06:22.656
cmuayoawm020h71ke7kbbamfw	cmu2kzqeu00055t7mrgmescc1	Logbaba	+237652406610	\N	\N	2026-09-21 08:06:22.775	2026-09-21 08:06:22.775
cmuayoax1020j71keazmw8m3v	cmu2kzqeu00055t7mrgmescc1	Logbaba	+237652406610	\N	\N	2026-09-21 08:06:22.789	2026-09-21 08:06:22.789
cmuayob01020l71kem15k7qel	cmu2kzqeu00055t7mrgmescc1	Lois 💕💕💕	+237654385419	\N	\N	2026-09-21 08:06:22.897	2026-09-21 08:06:22.897
cmuayob0a020n71kepscf5q4a	cmu2kzqeu00055t7mrgmescc1	Lois 💕💕💕	+237654385419	\N	\N	2026-09-21 08:06:22.907	2026-09-21 08:06:22.907
cmuayob3q020p71kefixu9hpd	cmu2kzqeu00055t7mrgmescc1	Lois🥰	+237673434034	\N	\N	2026-09-21 08:06:23.031	2026-09-21 08:06:23.031
cmuayob43020r71kejjvdje9y	cmu2kzqeu00055t7mrgmescc1	Lois🥰	+237673434034	\N	\N	2026-09-21 08:06:23.044	2026-09-21 08:06:23.044
cmuayob7o020t71keet6dl1ha	cmu2kzqeu00055t7mrgmescc1	Lorca Martinez🤍	+237653714099	\N	\N	2026-09-21 08:06:23.172	2026-09-21 08:06:23.172
cmuayob7v020v71ke32q0hjhv	cmu2kzqeu00055t7mrgmescc1	Lorca Martinez🤍	+237653714099	\N	\N	2026-09-21 08:06:23.179	2026-09-21 08:06:23.179
cmuayobbx020x71keuql019p1	cmu2kzqeu00055t7mrgmescc1	Louisa❤️	+237681134088	\N	\N	2026-09-21 08:06:23.325	2026-09-21 08:06:23.325
cmuayobc4020z71kema40jqzg	cmu2kzqeu00055t7mrgmescc1	Louisa❤️	+237681134088	\N	\N	2026-09-21 08:06:23.333	2026-09-21 08:06:23.333
cmuayobfh021171ke2zmbicgj	cmu2kzqeu00055t7mrgmescc1	Lpj🫥🫥	+237694239163	\N	\N	2026-09-21 08:06:23.453	2026-09-21 08:06:23.453
cmuayobfu021371keymibt8ll	cmu2kzqeu00055t7mrgmescc1	Lpj🫥🫥	+237694239163	\N	\N	2026-09-21 08:06:23.466	2026-09-21 08:06:23.466
cmuayobjb021571ke41ti3gig	cmu2kzqeu00055t7mrgmescc1	Promise 📳	+237652718645	\N	\N	2026-09-21 08:06:23.591	2026-09-21 16:28:04.635
cmuayobjk021771ken9vwf9km	cmu2kzqeu00055t7mrgmescc1	Luc Ifer	+237652718645	\N	\N	2026-09-21 08:06:23.601	2026-09-21 08:06:23.601
cmuayobmu021971ke8f458ljg	cmu2kzqeu00055t7mrgmescc1	Luc 🥶	+237679149375	\N	\N	2026-09-21 08:06:23.718	2026-09-21 08:06:23.718
cmuayobn7021b71kez7ccbyq2	cmu2kzqeu00055t7mrgmescc1	Luc 🥶	+237679149375	\N	\N	2026-09-21 08:06:23.731	2026-09-21 08:06:23.731
cmuayobqn021d71ke4q05v75v	cmu2kzqeu00055t7mrgmescc1	Lucas	+237690773336	\N	\N	2026-09-21 08:06:23.855	2026-09-21 08:06:23.855
cmuayobr2021f71ke8z2x6est	cmu2kzqeu00055t7mrgmescc1	Lucas	+237690773336	\N	\N	2026-09-21 08:06:23.87	2026-09-21 08:06:23.87
cmuayobu8021h71keg3oxd32h	cmu2kzqeu00055t7mrgmescc1	Lucky Dam’s🔥	+237683647741	\N	\N	2026-09-21 08:06:23.984	2026-09-21 08:06:23.984
cmuayobuf021j71kenwas1cot	cmu2kzqeu00055t7mrgmescc1	Lucky Dam’s🔥	+237683647741	\N	\N	2026-09-21 08:06:23.992	2026-09-21 08:06:23.992
cmuayobxl021l71keeersuzcj	cmu2kzqeu00055t7mrgmescc1	Luxury Cars	+923456278119	\N	\N	2026-09-21 08:06:24.105	2026-09-21 08:06:24.105
cmuayobxs021n71ked7b4sn83	cmu2kzqeu00055t7mrgmescc1	Luxury Cars	+923456278119	\N	\N	2026-09-21 08:06:24.112	2026-09-21 08:06:24.112
cmuayoc1i021p71keapjoyh23	cmu2kzqeu00055t7mrgmescc1	Lyndsay	+237672739883	\N	\N	2026-09-21 08:06:24.246	2026-09-21 08:06:24.246
cmuayoc1q021r71ke07mngdvl	cmu2kzqeu00055t7mrgmescc1	Lyndsay	+237672739883	\N	\N	2026-09-21 08:06:24.255	2026-09-21 08:06:24.255
cmuayoc4m021t71ke0b7caw32	cmu2kzqeu00055t7mrgmescc1	Lã Bløød Līñē	+237686945226	\N	\N	2026-09-21 08:06:24.359	2026-09-21 08:06:24.359
cmuayoc4v021v71ke3ftn6hcz	cmu2kzqeu00055t7mrgmescc1	Lã Bløød Līñē	+237686945226	\N	\N	2026-09-21 08:06:24.367	2026-09-21 08:06:24.367
cmuayoc8a021x71keg4e5m4fo	cmu2kzqeu00055t7mrgmescc1	Léa ❤️	+237682452521	\N	\N	2026-09-21 08:06:24.49	2026-09-21 08:06:24.49
cmuayoc8p021z71kec9e3512d	cmu2kzqeu00055t7mrgmescc1	Léa ❤️	+237682452521	\N	\N	2026-09-21 08:06:24.505	2026-09-21 08:06:24.505
cmuayocbz022171ker0qwowlo	cmu2kzqeu00055t7mrgmescc1	Lë PïRåTë 🏴‍☠️☠️❤️‍🩹	+2250507369430	\N	\N	2026-09-21 08:06:24.623	2026-09-21 08:06:24.623
cmuayocc6022371ke4e3s0wem	cmu2kzqeu00055t7mrgmescc1	Lë PïRåTë 🏴‍☠️☠️❤️‍🩹	+2250507369430	\N	\N	2026-09-21 08:06:24.63	2026-09-21 08:06:24.63
cmuayocfm022571ke893grz99	cmu2kzqeu00055t7mrgmescc1	Lë bøūrõ	+237683588172	\N	\N	2026-09-21 08:06:24.754	2026-09-21 08:06:24.754
cmuayocfu022771kewy5du0ly	cmu2kzqeu00055t7mrgmescc1	Lë bøūrõ	+237683588172	\N	\N	2026-09-21 08:06:24.762	2026-09-21 08:06:24.762
cmuayocin022971keo3pg51bj	cmu2kzqeu00055t7mrgmescc1	MACHE FALONNE	+237652287843	\N	\N	2026-09-21 08:06:24.863	2026-09-21 08:06:24.863
cmuayociw022b71ke10oh4zgf	cmu2kzqeu00055t7mrgmescc1	MACHE FALONNE	+237652287843	\N	\N	2026-09-21 08:06:24.872	2026-09-21 08:06:24.872
cmuayocmb022d71ke2f6rybm8	cmu2kzqeu00055t7mrgmescc1	MB Karisma	+237659336669	\N	\N	2026-09-21 08:06:24.995	2026-09-21 08:06:24.995
cmuayocmk022f71keylelwe54	cmu2kzqeu00055t7mrgmescc1	MB Karisma	+237659336669	\N	\N	2026-09-21 08:06:25.004	2026-09-21 08:06:25.004
cmuayocpv022h71ke1im8qqy9	cmu2kzqeu00055t7mrgmescc1	MICHELL TCHOUMKUE	+237688393314	\N	\N	2026-09-21 08:06:25.123	2026-09-21 08:06:25.123
cmuayocq2022j71keoafupuli	cmu2kzqeu00055t7mrgmescc1	MICHELL TCHOUMKUE	+237688393314	\N	\N	2026-09-21 08:06:25.13	2026-09-21 08:06:25.13
cmuayoctk022l71kergnm1x4t	cmu2kzqeu00055t7mrgmescc1	MIRANDA FOTSO	+237679744416	\N	\N	2026-09-21 08:06:25.256	2026-09-21 08:06:25.256
cmuayoctr022n71keum8ai6y4	cmu2kzqeu00055t7mrgmescc1	MIRANDA FOTSO	+237679744416	\N	\N	2026-09-21 08:06:25.263	2026-09-21 08:06:25.263
cmuayocxq022p71ke9g4mwwyr	cmu2kzqeu00055t7mrgmescc1	MJ	+237694903125	\N	\N	2026-09-21 08:06:25.406	2026-09-21 08:06:25.406
cmuayocxy022r71kezgd29fbn	cmu2kzqeu00055t7mrgmescc1	MJ	+237694903125	\N	\N	2026-09-21 08:06:25.414	2026-09-21 08:06:25.414
cmuayod14022t71keoyqrmavi	cmu2kzqeu00055t7mrgmescc1	MORBAD 🔥🔥🔥	+237672344539	\N	\N	2026-09-21 08:06:25.528	2026-09-21 08:06:25.528
cmuayod1b022v71ke1uswejpx	cmu2kzqeu00055t7mrgmescc1	MORBAD 🔥🔥🔥	+237672344539	\N	\N	2026-09-21 08:06:25.536	2026-09-21 08:06:25.536
cmuayod4z022x71kevkxrn7rm	cmu2kzqeu00055t7mrgmescc1	MR Raffayel 🤑	+237653562056	\N	\N	2026-09-21 08:06:25.667	2026-09-21 08:06:25.667
cmuayod58022z71ke0n5el95f	cmu2kzqeu00055t7mrgmescc1	MR Raffayel 🤑	+237653562056	\N	\N	2026-09-21 08:06:25.677	2026-09-21 08:06:25.677
cmuayodap023171keqqeisk1c	cmu2kzqeu00055t7mrgmescc1	Mah Shatou	+237679560966	\N	\N	2026-09-21 08:06:25.873	2026-09-21 16:27:53.429
cmuayodaw023371ke1ek5zvsk	cmu2kzqeu00055t7mrgmescc1	Ma Chateaux	+237679560966	\N	\N	2026-09-21 08:06:25.881	2026-09-21 08:06:25.881
cmuayodg5023571kejxalp4bb	cmu2kzqeu00055t7mrgmescc1	Ma Eru Azu	+237675344723	\N	\N	2026-09-21 08:06:26.07	2026-09-21 08:06:26.07
cmuayodgj023771ke3i34sh2y	cmu2kzqeu00055t7mrgmescc1	Ma Eru Azu	+237675344723	\N	\N	2026-09-21 08:06:26.084	2026-09-21 08:06:26.084
cmuayodu5023971ke6khuvl0l	cmu2kzqeu00055t7mrgmescc1	Ma Ginger Divine	+237699010036	\N	\N	2026-09-21 08:06:26.574	2026-09-21 08:06:26.574
cmuayodun023b71ke2gzeqgjz	cmu2kzqeu00055t7mrgmescc1	Ma Ginger Divine	+237699010036	\N	\N	2026-09-21 08:06:26.591	2026-09-21 08:06:26.591
cmuayodxz023d71ke9k33yof8	cmu2kzqeu00055t7mrgmescc1	Ma Gladys	+237679788185	\N	\N	2026-09-21 08:06:26.711	2026-09-21 08:06:26.711
cmuayody9023f71ke7mgxpljn	cmu2kzqeu00055t7mrgmescc1	Ma Gladys	+237679788185	\N	\N	2026-09-21 08:06:26.721	2026-09-21 08:06:26.721
cmuayoe39023h71ke0ev4wd37	cmu2kzqeu00055t7mrgmescc1	Ma Pru Aneambiri	+237677861594	\N	\N	2026-09-21 08:06:26.901	2026-09-21 08:06:26.901
cmuayoe3h023j71kej13wbve8	cmu2kzqeu00055t7mrgmescc1	Ma Pru Aneambiri	+237677861594	\N	\N	2026-09-21 08:06:26.91	2026-09-21 08:06:26.91
cmuayoe78023l71keakdxpodu	cmu2kzqeu00055t7mrgmescc1	Ma Rachelle Wata Yassa	+237677683745	\N	\N	2026-09-21 08:06:27.044	2026-09-21 08:06:27.044
cmuayoe7j023n71kesgbf6sjl	cmu2kzqeu00055t7mrgmescc1	Ma Rachelle Wata Yassa	+237677683745	\N	\N	2026-09-21 08:06:27.056	2026-09-21 08:06:27.056
cmuayoeb2023p71keydhaef8b	cmu2kzqeu00055t7mrgmescc1	Mac	+237237653	\N	\N	2026-09-21 08:06:27.182	2026-09-21 08:06:27.182
cmuayoeba023r71ke7i7uks0y	cmu2kzqeu00055t7mrgmescc1	Mac	+237237653	\N	\N	2026-09-21 08:06:27.19	2026-09-21 08:06:27.19
cmuayoeeg023t71keu810q793	cmu2kzqeu00055t7mrgmescc1	Maczine🥰	+237653596147	\N	\N	2026-09-21 08:06:27.304	2026-09-21 08:06:27.304
cmuayoeen023v71ke8k85brvr	cmu2kzqeu00055t7mrgmescc1	Maczine🥰	+237653596147	\N	\N	2026-09-21 08:06:27.311	2026-09-21 08:06:27.311
cmuayoehv023x71kehux6ylyu	cmu2kzqeu00055t7mrgmescc1	Maddison ⚽⚽⚽⚽	+2250747369753	\N	\N	2026-09-21 08:06:27.427	2026-09-21 08:06:27.427
cmuayoei4023z71kes0txiii4	cmu2kzqeu00055t7mrgmescc1	Maddison ⚽⚽⚽⚽	+2250747369753	\N	\N	2026-09-21 08:06:27.437	2026-09-21 08:06:27.437
cmuayoele024171kek2ysi4bu	cmu2kzqeu00055t7mrgmescc1	Made Easy Tech	+237654016097	\N	\N	2026-09-21 08:06:27.554	2026-09-21 08:06:27.554
cmuayoelm024371kez10q2whd	cmu2kzqeu00055t7mrgmescc1	Made Easy Tech	+237654016097	\N	\N	2026-09-21 08:06:27.562	2026-09-21 08:06:27.562
cmuayoepc024571ke2kx7vetj	cmu2kzqeu00055t7mrgmescc1	Made Salem📍	+237659132477	\N	\N	2026-09-21 08:06:27.697	2026-09-21 08:06:27.697
cmuayoepq024771keknemb6qd	cmu2kzqeu00055t7mrgmescc1	Made Salem📍	+237659132477	\N	\N	2026-09-21 08:06:27.71	2026-09-21 08:06:27.71
cmuayoesz024971kee3cmjiq1	cmu2kzqeu00055t7mrgmescc1	Maestro Warren🎶🎹❤️	+237681726452	\N	\N	2026-09-21 08:06:27.828	2026-09-21 08:06:27.828
cmuayoet8024b71kexd76084h	cmu2kzqeu00055t7mrgmescc1	Maestro Warren🎶🎹❤️	+237681726452	\N	\N	2026-09-21 08:06:27.836	2026-09-21 08:06:27.836
cmuayoewb024d71kelbtqv0dl	cmu2kzqeu00055t7mrgmescc1	Merveille⭐🥰	+237655896017	\N	\N	2026-09-21 08:06:27.947	2026-09-21 16:27:55.044
cmuayoewo024f71kea9e74gqj	cmu2kzqeu00055t7mrgmescc1	Maeva	+237655896017	\N	\N	2026-09-21 08:06:27.961	2026-09-21 08:06:27.961
cmuayoezx024h71ke5lmqwfml	cmu2kzqeu00055t7mrgmescc1	Magasco	+237651297968	\N	\N	2026-09-21 08:06:28.077	2026-09-21 08:06:28.077
cmuayof09024j71kexhyh71mn	cmu2kzqeu00055t7mrgmescc1	Magasco	+237651297968	\N	\N	2026-09-21 08:06:28.09	2026-09-21 08:06:28.09
cmuayofbm024l71ke73ue8y08	cmu2kzqeu00055t7mrgmescc1	Maike Kawua	+237654061095	\N	\N	2026-09-21 08:06:28.498	2026-09-21 08:06:28.498
cmuayofbv024n71kegz9us8nd	cmu2kzqeu00055t7mrgmescc1	Maike Kawua	+237654061095	\N	\N	2026-09-21 08:06:28.507	2026-09-21 08:06:28.507
cmuayofeu024p71kehdfrctag	cmu2kzqeu00055t7mrgmescc1	Makassa	+237692810056	\N	\N	2026-09-21 08:06:28.614	2026-09-21 08:06:28.614
cmuayoff3024r71ke3q3w734p	cmu2kzqeu00055t7mrgmescc1	Makassa	+237692810056	\N	\N	2026-09-21 08:06:28.623	2026-09-21 08:06:28.623
cmuayofih024t71keutclk3ep	cmu2kzqeu00055t7mrgmescc1	Mali Bouwa 😎	+22367509269	\N	\N	2026-09-21 08:06:28.745	2026-09-21 08:06:28.745
cmuayofit024v71ke1613mmy5	cmu2kzqeu00055t7mrgmescc1	Mali Bouwa 😎	+22367509269	\N	\N	2026-09-21 08:06:28.757	2026-09-21 08:06:28.757
cmuayoflr024x71ke4qupln3t	cmu2kzqeu00055t7mrgmescc1	Malikapay	+237682049518	\N	\N	2026-09-21 08:06:28.864	2026-09-21 08:06:28.864
cmuayofm1024z71ke0a7yjg5k	cmu2kzqeu00055t7mrgmescc1	Malikapay	+237682049518	\N	\N	2026-09-21 08:06:28.873	2026-09-21 08:06:28.873
cmuayofqx025171keilu1i7pe	cmu2kzqeu00055t7mrgmescc1	Mami Canada Yas	+237652314838	\N	\N	2026-09-21 08:06:29.049	2026-09-21 08:06:29.049
cmuayofr5025371ke3ndt0uhm	cmu2kzqeu00055t7mrgmescc1	Mami Canada Yas	+237652314838	\N	\N	2026-09-21 08:06:29.057	2026-09-21 08:06:29.057
cmuayofu8025571kear7iqbf6	cmu2kzqeu00055t7mrgmescc1	Mami Dibuncha	+237673293556	\N	\N	2026-09-21 08:06:29.168	2026-09-21 08:06:29.168
cmuayofuf025771ken0uylii0	cmu2kzqeu00055t7mrgmescc1	Mami Dibuncha	+237673293556	\N	\N	2026-09-21 08:06:29.176	2026-09-21 08:06:29.176
cmuayofy3025971keo3dfqnat	cmu2kzqeu00055t7mrgmescc1	Manfred Angah(Mentor)	+237654224353	\N	\N	2026-09-21 08:06:29.308	2026-09-21 08:06:29.308
cmuayofyh025b71kewzyw6x6z	cmu2kzqeu00055t7mrgmescc1	Manfred Angah(Mentor)	+237654224353	\N	\N	2026-09-21 08:06:29.321	2026-09-21 08:06:29.321
cmuayog1r025d71keuzne46lh	cmu2kzqeu00055t7mrgmescc1	Manu ☘️fille	+237697637523	\N	\N	2026-09-21 08:06:29.44	2026-09-21 08:06:29.44
cmuayog1z025f71keu5hj0yyd	cmu2kzqeu00055t7mrgmescc1	Manu ☘️fille	+237697637523	\N	\N	2026-09-21 08:06:29.447	2026-09-21 08:06:29.447
cmuayog55025h71kel1umov2d	cmu2kzqeu00055t7mrgmescc1	Manuella	+237657949941	\N	\N	2026-09-21 08:06:29.561	2026-09-21 08:06:29.561
cmuayog5h025j71kexnakxc0o	cmu2kzqeu00055t7mrgmescc1	Manuella	+237657949941	\N	\N	2026-09-21 08:06:29.574	2026-09-21 08:06:29.574
cmuayog8u025l71keat8gwhvw	cmu2kzqeu00055t7mrgmescc1	Manuella 🇨🇲🇨🇲	+237699354501	\N	\N	2026-09-21 08:06:29.694	2026-09-21 08:06:29.694
cmuayog97025n71kepqv9rap8	cmu2kzqeu00055t7mrgmescc1	Manuella 🇨🇲🇨🇲	+237699354501	\N	\N	2026-09-21 08:06:29.707	2026-09-21 08:06:29.707
cmuayogce025p71ke846abq52	cmu2kzqeu00055t7mrgmescc1	Manyo PJ	+237653896742	\N	\N	2026-09-21 08:06:29.823	2026-09-21 08:06:29.823
cmuayogcn025r71ke4r6avsnd	cmu2kzqeu00055t7mrgmescc1	Manyo PJ	+237653896742	\N	\N	2026-09-21 08:06:29.831	2026-09-21 08:06:29.831
cmuayogfu025t71kewlnm0zjv	cmu2kzqeu00055t7mrgmescc1	Mari_na🌬️🍃	+237691730419	\N	\N	2026-09-21 08:06:29.946	2026-09-21 08:06:29.946
cmuayogg3025v71kegs4cugin	cmu2kzqeu00055t7mrgmescc1	Mari_na🌬️🍃	+237691730419	\N	\N	2026-09-21 08:06:29.955	2026-09-21 08:06:29.955
cmuayogjh025x71kegfsjds6f	cmu2kzqeu00055t7mrgmescc1	Maria	+237671093236	\N	\N	2026-09-21 08:06:30.077	2026-09-21 08:06:30.077
cmuayogjt025z71ke4rv3stdv	cmu2kzqeu00055t7mrgmescc1	Maria	+237671093236	\N	\N	2026-09-21 08:06:30.089	2026-09-21 08:06:30.089
cmuayogn3026171ketur39sxr	cmu2kzqeu00055t7mrgmescc1	Marie Nakmanou CT	+237671315224	\N	\N	2026-09-21 08:06:30.208	2026-09-21 08:06:30.208
cmuayognf026371ke2b8w104r	cmu2kzqeu00055t7mrgmescc1	Marie Nakmanou CT	+237671315224	\N	\N	2026-09-21 08:06:30.219	2026-09-21 08:06:30.219
cmuayoh4t026571kelll9rzrf	cmu2kzqeu00055t7mrgmescc1	Marie Noelle	+237652861038	\N	\N	2026-09-21 08:06:30.845	2026-09-21 08:06:30.845
cmuayoh58026771ke0h2bizu2	cmu2kzqeu00055t7mrgmescc1	Marie Noelle	+237652861038	\N	\N	2026-09-21 08:06:30.86	2026-09-21 08:06:30.86
cmuayohb8026971kerzis4ojh	cmu2kzqeu00055t7mrgmescc1	Marie 🥰	+237657201028	\N	\N	2026-09-21 08:06:31.076	2026-09-21 08:06:31.076
cmuayohbj026b71kecrs8w1wz	cmu2kzqeu00055t7mrgmescc1	Marie 🥰	+237657201028	\N	\N	2026-09-21 08:06:31.088	2026-09-21 08:06:31.088
cmuayohew026d71keu2o1wkbj	cmu2kzqeu00055t7mrgmescc1	MarieNeol	+237650194593	\N	\N	2026-09-21 08:06:31.208	2026-09-21 08:06:31.208
cmuayohf7026f71kevcwoop5y	cmu2kzqeu00055t7mrgmescc1	MarieNeol	+237650194593	\N	\N	2026-09-21 08:06:31.219	2026-09-21 08:06:31.219
cmuayohip026h71kecorl4q6l	cmu2kzqeu00055t7mrgmescc1	Marone Fille💕	+237659197786	\N	\N	2026-09-21 08:06:31.345	2026-09-21 08:06:31.345
cmuayohj3026j71ke0iz00r4x	cmu2kzqeu00055t7mrgmescc1	Marone Fille💕	+237659197786	\N	\N	2026-09-21 08:06:31.359	2026-09-21 08:06:31.359
cmuayohme026l71ke0skct07x	cmu2kzqeu00055t7mrgmescc1	Marshall🇨🇲	+237679955459	\N	\N	2026-09-21 08:06:31.478	2026-09-21 08:06:31.478
cmuayohmm026n71kebkz8dvlu	cmu2kzqeu00055t7mrgmescc1	Marshall🇨🇲	+237679955459	\N	\N	2026-09-21 08:06:31.486	2026-09-21 08:06:31.486
cmuayohpk026p71kegeaukm4h	cmu2kzqeu00055t7mrgmescc1	Martin	+237655212353	\N	\N	2026-09-21 08:06:31.593	2026-09-21 08:06:31.593
cmuayohpt026r71kerd015mna	cmu2kzqeu00055t7mrgmescc1	Martin	+237655212353	\N	\N	2026-09-21 08:06:31.601	2026-09-21 08:06:31.601
cmuayohtm026t71kernxmz1d4	cmu2kzqeu00055t7mrgmescc1	Mavelus	+237654809882	\N	\N	2026-09-21 08:06:31.738	2026-09-21 16:27:54.549
cmuayohtt026v71keklzksb5e	cmu2kzqeu00055t7mrgmescc1	Marvelous	+237654809882	\N	\N	2026-09-21 08:06:31.745	2026-09-21 08:06:31.745
cmuayohxk026x71kejv1av1b9	cmu2kzqeu00055t7mrgmescc1	Marvesh🤳🏽	+237670085935	\N	\N	2026-09-21 08:06:31.881	2026-09-21 08:06:31.881
cmuayohxy026z71kexwyx4tb1	cmu2kzqeu00055t7mrgmescc1	Marvesh🤳🏽	+237670085935	\N	\N	2026-09-21 08:06:31.894	2026-09-21 08:06:31.894
cmuayoi55027171ke3zmobhgd	cmu2kzqeu00055t7mrgmescc1	Max Shopping	+2250544072708	\N	\N	2026-09-21 08:06:32.153	2026-09-21 08:06:32.153
cmuayoi5l027371ke26evkv9x	cmu2kzqeu00055t7mrgmescc1	Max Shopping	+2250544072708	\N	\N	2026-09-21 08:06:32.169	2026-09-21 08:06:32.169
cmuayoifj027571ke17y8yx04	cmu2kzqeu00055t7mrgmescc1	Mbakwa Apa	+237675188798	\N	\N	2026-09-21 08:06:32.527	2026-09-21 08:06:32.527
cmuayoify027771ken5m4ge4o	cmu2kzqeu00055t7mrgmescc1	Mbakwa Apa	+237675188798	\N	\N	2026-09-21 08:06:32.542	2026-09-21 08:06:32.542
cmuayoikp027971ke13zsbrml	cmu2kzqeu00055t7mrgmescc1	Mbopile 1	+237654163144	\N	\N	2026-09-21 08:06:32.713	2026-09-21 08:06:32.713
cmuayoikz027b71keveabkxjy	cmu2kzqeu00055t7mrgmescc1	Mbopile 1	+237654163144	\N	\N	2026-09-21 08:06:32.723	2026-09-21 08:06:32.723
cmuayoip5027d71ke9y9xvocp	cmu2kzqeu00055t7mrgmescc1	Mbopile Agent 1	+237674036200	\N	\N	2026-09-21 08:06:32.873	2026-09-21 08:06:32.873
cmuayoipc027f71kecue5msw9	cmu2kzqeu00055t7mrgmescc1	Mbopile Agent 1	+237674036200	\N	\N	2026-09-21 08:06:32.881	2026-09-21 08:06:32.881
cmuayoitb027h71kelm0s58m1	cmu2kzqeu00055t7mrgmescc1	Mc Carole	+237655964704	\N	\N	2026-09-21 08:06:33.024	2026-09-21 08:06:33.024
cmuayoitk027j71kew62ku8hf	cmu2kzqeu00055t7mrgmescc1	Mc Carole	+237655964704	\N	\N	2026-09-21 08:06:33.033	2026-09-21 08:06:33.033
cmuayoj2s027l71kedvw217c9	cmu2kzqeu00055t7mrgmescc1	Mc Silver	+237683216450	\N	\N	2026-09-21 08:06:33.364	2026-09-21 08:06:33.364
cmuayoj32027n71keplu5bxvg	cmu2kzqeu00055t7mrgmescc1	Mc Silver	+237683216450	\N	\N	2026-09-21 08:06:33.374	2026-09-21 08:06:33.374
cmuayoj6q027p71kerz0kidgf	cmu2kzqeu00055t7mrgmescc1	Mégane🌟🌹	+237679547346	\N	\N	2026-09-21 08:06:33.507	2026-09-21 08:06:33.507
cmuayoj6x027r71kenezqc4j4	cmu2kzqeu00055t7mrgmescc1	Mégane🌟🌹	+237679547346	\N	\N	2026-09-21 08:06:33.513	2026-09-21 08:06:33.513
cmuayojag027t71kehhtzntwg	cmu2kzqeu00055t7mrgmescc1	Mel_nailedit	+237657702706	\N	\N	2026-09-21 08:06:33.64	2026-09-21 08:06:33.64
cmuayojao027v71kes64hncm9	cmu2kzqeu00055t7mrgmescc1	Mel_nailedit	+237657702706	\N	\N	2026-09-21 08:06:33.649	2026-09-21 08:06:33.649
cmuayojeh027x71ketg7xmxik	cmu2kzqeu00055t7mrgmescc1	Mel~die	+237659161303	\N	\N	2026-09-21 08:06:33.785	2026-09-21 08:06:33.785
cmuayojet027z71ke7knphx3q	cmu2kzqeu00055t7mrgmescc1	Mel~die	+237659161303	\N	\N	2026-09-21 08:06:33.798	2026-09-21 08:06:33.798
cmuayojmg028171kezpee50xq	cmu2kzqeu00055t7mrgmescc1	Michelle	+237693135059	\N	\N	2026-09-21 08:06:34.072	2026-09-21 16:27:55.531
cmuayojmn028371kevt7sw7go	cmu2kzqeu00055t7mrgmescc1	Mich	+237693135059	\N	\N	2026-09-21 08:06:34.08	2026-09-21 08:06:34.08
cmuayojqc028571ke9yak6qf2	cmu2kzqeu00055t7mrgmescc1	Michael Scofield🍀🍀	+237659538926	\N	\N	2026-09-21 08:06:34.213	2026-09-21 16:27:55.432
cmuayojql028771ke3dj0gxx2	cmu2kzqeu00055t7mrgmescc1	Michael	+237659538926	\N	\N	2026-09-21 08:06:34.221	2026-09-21 08:06:34.221
cmuayojxg028971keefg1feco	cmu2kzqeu00055t7mrgmescc1	Miguel D	+237683403979	\N	\N	2026-09-21 08:06:34.468	2026-09-21 08:06:34.468
cmuayojxt028b71ke6g5xjj8o	cmu2kzqeu00055t7mrgmescc1	Miguel D	+237683403979	\N	\N	2026-09-21 08:06:34.481	2026-09-21 08:06:34.481
cmuayok1b028d71keo2d94lxo	cmu2kzqeu00055t7mrgmescc1	Mihz Leen ❤️🥰	+237682733952	\N	\N	2026-09-21 08:06:34.607	2026-09-21 08:06:34.607
cmuayok1j028f71ke95mvxwxi	cmu2kzqeu00055t7mrgmescc1	Mihz Leen ❤️🥰	+237682733952	\N	\N	2026-09-21 08:06:34.615	2026-09-21 08:06:34.615
cmuayok56028h71kextp4k7v8	cmu2kzqeu00055t7mrgmescc1	Mimi Black🤳🏽	+237683681708	\N	\N	2026-09-21 08:06:34.746	2026-09-21 08:06:34.746
cmuayok5g028j71ke58obuhgc	cmu2kzqeu00055t7mrgmescc1	Mimi Black🤳🏽	+237683681708	\N	\N	2026-09-21 08:06:34.756	2026-09-21 08:06:34.756
cmuayok8n028l71kesxp1515e	cmu2kzqeu00055t7mrgmescc1	Mimi Mefo Info	+237679135573	\N	\N	2026-09-21 08:06:34.871	2026-09-21 08:06:34.871
cmuayok8t028n71kelq885ldc	cmu2kzqeu00055t7mrgmescc1	Mimi Mefo Info	+237679135573	\N	\N	2026-09-21 08:06:34.878	2026-09-21 08:06:34.878
cmuayokby028p71ke82qhrw0e	cmu2kzqeu00055t7mrgmescc1	Min Solange	+23775878629	\N	\N	2026-09-21 08:06:34.991	2026-09-21 08:06:34.991
cmuayokca028r71ke0cgem9o4	cmu2kzqeu00055t7mrgmescc1	Min Solange	+23775878629	\N	\N	2026-09-21 08:06:35.002	2026-09-21 08:06:35.002
cmuayokg8028t71keeim9ueaf	cmu2kzqeu00055t7mrgmescc1	Mira	+2348082979605	\N	\N	2026-09-21 08:06:35.145	2026-09-21 08:06:35.145
cmuayokgi028v71ke20mbkfsa	cmu2kzqeu00055t7mrgmescc1	Mira	+2348082979605	\N	\N	2026-09-21 08:06:35.154	2026-09-21 08:06:35.154
cmuayokkl028x71keshrk0e5c	cmu2kzqeu00055t7mrgmescc1	Mirabelle Yas	+237683873234	\N	\N	2026-09-21 08:06:35.301	2026-09-21 08:06:35.301
cmuayokks028z71ke26ab4j61	cmu2kzqeu00055t7mrgmescc1	Mirabelle Yas	+237683873234	\N	\N	2026-09-21 08:06:35.309	2026-09-21 08:06:35.309
cmuayokp2029171keju9et9mr	cmu2kzqeu00055t7mrgmescc1	Mispa Mis P	+237671744939	\N	\N	2026-09-21 08:06:35.462	2026-09-21 08:06:35.462
cmuayokpa029371keh8x9pjym	cmu2kzqeu00055t7mrgmescc1	Mispa Mis P	+237671744939	\N	\N	2026-09-21 08:06:35.471	2026-09-21 08:06:35.471
cmuayoku1029571kezt6e8p7j	cmu2kzqeu00055t7mrgmescc1	Mk Choco ❤️😎	+237659151229	\N	\N	2026-09-21 08:06:35.642	2026-09-21 08:06:35.642
cmuayokub029771kelmdvuqz7	cmu2kzqeu00055t7mrgmescc1	Mk Choco ❤️😎	+237659151229	\N	\N	2026-09-21 08:06:35.652	2026-09-21 08:06:35.652
cmuayokz4029971kerhhsz1kf	cmu2kzqeu00055t7mrgmescc1	Mk Daina 😘	+237672963006	\N	\N	2026-09-21 08:06:35.824	2026-09-21 08:06:35.824
cmuayokzi029b71kemx0gub8q	cmu2kzqeu00055t7mrgmescc1	Mk Daina 😘	+237672963006	\N	\N	2026-09-21 08:06:35.838	2026-09-21 08:06:35.838
cmuayol57029d71keijmpw0yb	cmu2kzqeu00055t7mrgmescc1	Mk empire	+2348100602510	\N	\N	2026-09-21 08:06:36.043	2026-09-21 08:06:36.043
cmuayol5i029f71kexf1d2b88	cmu2kzqeu00055t7mrgmescc1	Mk empire	+2348100602510	\N	\N	2026-09-21 08:06:36.054	2026-09-21 08:06:36.054
cmuayolei029h71ke9hqgyxvc	cmu2kzqeu00055t7mrgmescc1	Mm Josepha Mutund	+237676704552	\N	\N	2026-09-21 08:06:36.378	2026-09-21 08:06:36.378
cmuayoleq029j71ke5n3ew4t4	cmu2kzqeu00055t7mrgmescc1	Mm Josepha Mutund	+237676704552	\N	\N	2026-09-21 08:06:36.386	2026-09-21 08:06:36.386
cmuayoli1029l71kev6kqukxt	cmu2kzqeu00055t7mrgmescc1	Mohamed	+237695162858	\N	\N	2026-09-21 08:06:36.505	2026-09-21 08:06:36.505
cmuayoli8029n71kepzencd6m	cmu2kzqeu00055t7mrgmescc1	Mohamed	+237695162858	\N	\N	2026-09-21 08:06:36.512	2026-09-21 08:06:36.512
cmuayollb029p71ke2svlcmhk	cmu2kzqeu00055t7mrgmescc1	Moise	+237640091168	\N	\N	2026-09-21 08:06:36.623	2026-09-21 08:06:36.623
cmuayollk029r71kecsrj5sxf	cmu2kzqeu00055t7mrgmescc1	Moise	+237640091168	\N	\N	2026-09-21 08:06:36.632	2026-09-21 08:06:36.632
cmuayolol029t71kerrk3rru5	cmu2kzqeu00055t7mrgmescc1	My Sweet Mum ❤️❤️	+237682752155	\N	\N	2026-09-21 08:06:36.741	2026-09-21 16:27:58.556
cmuayolov029v71ken3jbatl6	cmu2kzqeu00055t7mrgmescc1	Mom	+237682752155	\N	\N	2026-09-21 08:06:36.751	2026-09-21 08:06:36.751
cmuayolsj029x71ke3u4zfyi6	cmu2kzqeu00055t7mrgmescc1	Monica	+237673256911	\N	\N	2026-09-21 08:06:36.884	2026-09-21 08:06:36.884
cmuayolsr029z71ke9i32svm0	cmu2kzqeu00055t7mrgmescc1	Monica	+237673256911	\N	\N	2026-09-21 08:06:36.892	2026-09-21 08:06:36.892
cmuayolwa02a171kezajeixor	cmu2kzqeu00055t7mrgmescc1	Monsieur James	+237699948158	\N	\N	2026-09-21 08:06:37.019	2026-09-21 08:06:37.019
cmuayolwh02a371ke9k7eraz5	cmu2kzqeu00055t7mrgmescc1	Monsieur James	+237699948158	\N	\N	2026-09-21 08:06:37.026	2026-09-21 08:06:37.026
cmuayom1r02a571ke5gccd155	cmu2kzqeu00055t7mrgmescc1	Mourinho	+237680603207	\N	\N	2026-09-21 08:06:37.215	2026-09-21 08:06:37.215
cmuayom1z02a771ke5xfnxxw7	cmu2kzqeu00055t7mrgmescc1	Mourinho	+237680603207	\N	\N	2026-09-21 08:06:37.223	2026-09-21 08:06:37.223
cmuayom5i02a971key1agrrwo	cmu2kzqeu00055t7mrgmescc1	Mourinho	+2376806032072	\N	\N	2026-09-21 08:06:37.35	2026-09-21 08:06:37.35
cmuayom5p02ab71kev0mptb5c	cmu2kzqeu00055t7mrgmescc1	Mourinho	+2376806032072	\N	\N	2026-09-21 08:06:37.357	2026-09-21 08:06:37.357
cmuayom9202ad71ke8bov1yzy	cmu2kzqeu00055t7mrgmescc1	Moussa	+22948523074	\N	\N	2026-09-21 08:06:37.478	2026-09-21 08:06:37.478
cmuayom9c02af71ke6wuheae5	cmu2kzqeu00055t7mrgmescc1	Moussa	+22948523074	\N	\N	2026-09-21 08:06:37.488	2026-09-21 08:06:37.488
cmuayomcn02ah71kezxwnk4x7	cmu2kzqeu00055t7mrgmescc1	Mr Alushuce	+237654974991	\N	\N	2026-09-21 08:06:37.607	2026-09-21 08:06:37.607
cmuayomd002aj71keblnhzxnv	cmu2kzqeu00055t7mrgmescc1	Mr Alushuce	+237654974991	\N	\N	2026-09-21 08:06:37.621	2026-09-21 08:06:37.621
cmuayomgy02al71kefujh365v	cmu2kzqeu00055t7mrgmescc1	Mr Bill Blaise	+237674094646	\N	\N	2026-09-21 08:06:37.762	2026-09-21 08:06:37.762
cmuayomh802an71keya48hhjo	cmu2kzqeu00055t7mrgmescc1	Mr Bill Blaise	+237674094646	\N	\N	2026-09-21 08:06:37.772	2026-09-21 08:06:37.772
cmuayomlv02ap71ke941yjey8	cmu2kzqeu00055t7mrgmescc1	Mr Dems 🖖🏿	+237659865795	\N	\N	2026-09-21 08:06:37.939	2026-09-21 08:06:37.939
cmuayomm302ar71kepoxxcnrb	cmu2kzqeu00055t7mrgmescc1	Mr Dems 🖖🏿	+237659865795	\N	\N	2026-09-21 08:06:37.947	2026-09-21 08:06:37.947
cmuayompj02at71ke1n0kh24w	cmu2kzqeu00055t7mrgmescc1	Mr Edwige	+22770398626	\N	\N	2026-09-21 08:06:38.071	2026-09-21 08:06:38.071
cmuayompq02av71ke41s4k19d	cmu2kzqeu00055t7mrgmescc1	Mr Edwige	+22770398626	\N	\N	2026-09-21 08:06:38.078	2026-09-21 08:06:38.078
cmuayomtc02ax71ke37aw6w91	cmu2kzqeu00055t7mrgmescc1	Mr Fredrick	+237650849559	\N	\N	2026-09-21 08:06:38.209	2026-09-21 08:06:38.209
cmuayomtn02az71keof8brpey	cmu2kzqeu00055t7mrgmescc1	Mr Fredrick	+237650849559	\N	\N	2026-09-21 08:06:38.219	2026-09-21 08:06:38.219
cmuayon1x02b171ked69fa00y	cmu2kzqeu00055t7mrgmescc1	Mr Kamga	+237693117014	\N	\N	2026-09-21 08:06:38.517	2026-09-21 08:06:38.517
cmuayon2602b371ke8ot10exi	cmu2kzqeu00055t7mrgmescc1	Mr Kamga	+237693117014	\N	\N	2026-09-21 08:06:38.526	2026-09-21 08:06:38.526
cmuayon5a02b571kene28v1kx	cmu2kzqeu00055t7mrgmescc1	Mr Mk🇨🇲	+237690072288	\N	\N	2026-09-21 08:06:38.638	2026-09-21 08:06:38.638
cmuayon5i02b771ke0tgyp34r	cmu2kzqeu00055t7mrgmescc1	Mr Mk🇨🇲	+237690072288	\N	\N	2026-09-21 08:06:38.646	2026-09-21 08:06:38.646
cmuayon8m02b971ke4ywlh9n1	cmu2kzqeu00055t7mrgmescc1	Mr NØ BØDY	+237671565547	\N	\N	2026-09-21 08:06:38.758	2026-09-21 08:06:38.758
cmuayon8u02bb71ketgq5oubs	cmu2kzqeu00055t7mrgmescc1	Mr NØ BØDY	+237671565547	\N	\N	2026-09-21 08:06:38.766	2026-09-21 08:06:38.766
cmuayonw602bd71kenxw0htzp	cmu2kzqeu00055t7mrgmescc1	SCHRODINGER👑	+23778165083	\N	\N	2026-09-21 08:06:39.606	2026-09-21 16:28:06.845
cmuayonwk02bf71keqdk3l760	cmu2kzqeu00055t7mrgmescc1	Mr Petit Dapen Dappen, Jr.	+23778165083	\N	\N	2026-09-21 08:06:39.62	2026-09-21 08:06:39.62
cmuayonzx02bh71keb3y9bj06	cmu2kzqeu00055t7mrgmescc1	Mr Propre	+237657449267	\N	\N	2026-09-21 08:06:39.741	2026-09-21 08:06:39.741
cmuayoo0902bj71kepnilgn6m	cmu2kzqeu00055t7mrgmescc1	Mr Propre	+237657449267	\N	\N	2026-09-21 08:06:39.753	2026-09-21 08:06:39.753
cmuayoo3502bl71kes0u7w6tf	cmu2kzqeu00055t7mrgmescc1	Mr Smich Officiel	+237655782219	\N	\N	2026-09-21 08:06:39.857	2026-09-21 08:06:39.857
cmuayoo3d02bn71ke8xobtm5b	cmu2kzqeu00055t7mrgmescc1	Mr Smich Officiel	+237655782219	\N	\N	2026-09-21 08:06:39.865	2026-09-21 08:06:39.865
cmuayoo6g02bp71kehwghuw6y	cmu2kzqeu00055t7mrgmescc1	Mr Sterling 💷	+237697682285	\N	\N	2026-09-21 08:06:39.976	2026-09-21 08:06:39.976
cmuayoo6r02br71kequladdce	cmu2kzqeu00055t7mrgmescc1	Mr Sterling 💷	+237697682285	\N	\N	2026-09-21 08:06:39.987	2026-09-21 08:06:39.987
cmuayooa602bt71kep8offh03	cmu2kzqeu00055t7mrgmescc1	Mr Zen	+237658770071	\N	\N	2026-09-21 08:06:40.11	2026-09-21 08:06:40.11
cmuayooai02bv71kex64gddw6	cmu2kzqeu00055t7mrgmescc1	Mr Zen	+237658770071	\N	\N	2026-09-21 08:06:40.122	2026-09-21 08:06:40.122
cmuayoodp02bx71kerbhqko13	cmu2kzqeu00055t7mrgmescc1	Mr valpi	+2250711105037	\N	\N	2026-09-21 08:06:40.237	2026-09-21 08:06:40.237
cmuayoodx02bz71ke1iv93hnh	cmu2kzqeu00055t7mrgmescc1	Mr valpi	+2250711105037	\N	\N	2026-09-21 08:06:40.246	2026-09-21 08:06:40.246
cmuayoon402c171kediymwafp	cmu2kzqeu00055t7mrgmescc1	Mr Ãrnøl.K 💫😎	+237656461798	\N	\N	2026-09-21 08:06:40.576	2026-09-21 08:06:40.576
cmuayoond02c371kerdo59krk	cmu2kzqeu00055t7mrgmescc1	Mr Ãrnøl.K 💫😎	+237656461798	\N	\N	2026-09-21 08:06:40.585	2026-09-21 08:06:40.585
cmuayooq902c571ker5fowwbs	cmu2kzqeu00055t7mrgmescc1	Mr. A 8 Z	+237682835512	\N	\N	2026-09-21 08:06:40.69	2026-09-21 08:06:40.69
cmuayooqh02c771ketm3o6dpb	cmu2kzqeu00055t7mrgmescc1	Mr. A 8 Z	+237682835512	\N	\N	2026-09-21 08:06:40.697	2026-09-21 08:06:40.697
cmuayoovq02c971ke4ql0331l	cmu2kzqeu00055t7mrgmescc1	Mrs stella	+237687596929	\N	\N	2026-09-21 08:06:40.886	2026-09-21 08:06:40.886
cmuayoow402cb71keehr5v409	cmu2kzqeu00055t7mrgmescc1	Mrs stella	+237687596929	\N	\N	2026-09-21 08:06:40.9	2026-09-21 08:06:40.9
cmuayoozh02cd71kel2lu276t	cmu2kzqeu00055t7mrgmescc1	Mum  Ken	+27678132309	\N	\N	2026-09-21 08:06:41.021	2026-09-21 08:06:41.021
cmuayoozo02cf71kewy0p2eyi	cmu2kzqeu00055t7mrgmescc1	Mum  Ken	+27678132309	\N	\N	2026-09-21 08:06:41.029	2026-09-21 08:06:41.029
cmuayop2p02ch71ke3u6s8ug3	cmu2kzqeu00055t7mrgmescc1	My 3	+237672701198	\N	\N	2026-09-21 08:06:41.137	2026-09-21 08:06:41.137
cmuayop2v02cj71kena0vnj0h	cmu2kzqeu00055t7mrgmescc1	My 3	+237672701198	\N	\N	2026-09-21 08:06:41.143	2026-09-21 08:06:41.143
cmuayop5w02cl71kegym0nsap	cmu2kzqeu00055t7mrgmescc1	My Nigeria Number	+23707068462382	\N	\N	2026-09-21 08:06:41.252	2026-09-21 08:06:41.252
cmuayop6302cn71kea8xs6ckk	cmu2kzqeu00055t7mrgmescc1	My Nigeria Number	+23707068462382	\N	\N	2026-09-21 08:06:41.26	2026-09-21 08:06:41.26
cmuayop9c02cp71kezra5yhw8	cmu2kzqeu00055t7mrgmescc1	My Other WhatsApp	+237654250021	\N	\N	2026-09-21 08:06:41.376	2026-09-21 08:06:41.376
cmuayop9r02cr71ke95cwd74e	cmu2kzqeu00055t7mrgmescc1	My Other WhatsApp	+237654250021	\N	\N	2026-09-21 08:06:41.392	2026-09-21 08:06:41.392
cmuayopd202ct71kesh4abc5o	cmu2kzqeu00055t7mrgmescc1	My Private Teacher ✅	+237679200255	\N	\N	2026-09-21 08:06:41.51	2026-09-21 08:06:41.51
cmuayopd902cv71ke2yszye36	cmu2kzqeu00055t7mrgmescc1	My Private Teacher ✅	+237679200255	\N	\N	2026-09-21 08:06:41.517	2026-09-21 08:06:41.517
cmuayopio02cx71keq2ti6wwq	cmu2kzqeu00055t7mrgmescc1	ugahmarceline	+237670582673	\N	\N	2026-09-21 08:06:41.712	2026-09-21 16:28:18.456
cmuayopj202cz71kel2a2uvex	cmu2kzqeu00055t7mrgmescc1	My Sweet Mum❤️❤️❤️	+237670582673	\N	\N	2026-09-21 08:06:41.726	2026-09-21 08:06:41.726
cmuayopm002d171key4sycmk9	cmu2kzqeu00055t7mrgmescc1	Pastor Glory	+237670981149	\N	\N	2026-09-21 08:06:41.833	2026-09-21 16:28:02.349
cmuayopm702d371keybakmoh5	cmu2kzqeu00055t7mrgmescc1	Pastor My father	+237670981149	\N	\N	2026-09-21 08:06:41.839	2026-09-21 08:06:41.839
cmuayoppw02d571kev3axvwd6	cmu2kzqeu00055t7mrgmescc1	Mãx-węll🖤	+237687930715	\N	\N	2026-09-21 08:06:41.972	2026-09-21 08:06:41.972
cmuayopq202d771kexg0arvvz	cmu2kzqeu00055t7mrgmescc1	Mãx-węll🖤	+237687930715	\N	\N	2026-09-21 08:06:41.978	2026-09-21 08:06:41.978
cmuayopv402d971ke2brm52b0	cmu2kzqeu00055t7mrgmescc1	NEWTON ACHONDUH	+237691113445	\N	\N	2026-09-21 08:06:42.16	2026-09-21 08:06:42.16
cmuayopve02db71keuk47o3ld	cmu2kzqeu00055t7mrgmescc1	NEWTON ACHONDUH	+237691113445	\N	\N	2026-09-21 08:06:42.17	2026-09-21 08:06:42.17
cmuayopyr02dd71keg4bi50qh	cmu2kzqeu00055t7mrgmescc1	NK~Russell	+237651910091	\N	\N	2026-09-21 08:06:42.291	2026-09-21 08:06:42.291
cmuayopyz02df71ke132krixd	cmu2kzqeu00055t7mrgmescc1	NK~Russell	+237651910091	\N	\N	2026-09-21 08:06:42.299	2026-09-21 08:06:42.299
cmuayoq2m02dh71ke8h69r3je	cmu2kzqeu00055t7mrgmescc1	Na-na	+237677267507	\N	\N	2026-09-21 08:06:42.43	2026-09-21 08:06:42.43
cmuayoq3002dj71ked2o34rm9	cmu2kzqeu00055t7mrgmescc1	Na-na	+237677267507	\N	\N	2026-09-21 08:06:42.444	2026-09-21 08:06:42.444
cmuayoq6602dl71ke4hhlcy3m	cmu2kzqeu00055t7mrgmescc1	Nabat	+237658295368	\N	\N	2026-09-21 08:06:42.559	2026-09-21 08:06:42.559
cmuayoq6f02dn71ke0am4stbi	cmu2kzqeu00055t7mrgmescc1	Nabat	+237658295368	\N	\N	2026-09-21 08:06:42.568	2026-09-21 08:06:42.568
cmuayoq9z02dp71keuj3nfm7g	cmu2kzqeu00055t7mrgmescc1	Nach	+237655204773	\N	\N	2026-09-21 08:06:42.695	2026-09-21 08:06:42.695
cmuayoqa902dr71kegh0ahb19	cmu2kzqeu00055t7mrgmescc1	Nach	+237655204773	\N	\N	2026-09-21 08:06:42.705	2026-09-21 08:06:42.705
cmuayoqdv02dt71keo3aupxsu	cmu2kzqeu00055t7mrgmescc1	Nana	+237670950819	\N	\N	2026-09-21 08:06:42.835	2026-09-21 08:06:42.835
cmuayoqe202dv71kevr3krshf	cmu2kzqeu00055t7mrgmescc1	Nana	+237670950819	\N	\N	2026-09-21 08:06:42.842	2026-09-21 08:06:42.842
cmuayoqh902dx71kewonqo1wx	cmu2kzqeu00055t7mrgmescc1	Nana Ketchup	+237656324349	\N	\N	2026-09-21 08:06:42.957	2026-09-21 08:06:42.957
cmuayoqhj02dz71kefeu2tp42	cmu2kzqeu00055t7mrgmescc1	Nana Ketchup	+237656324349	\N	\N	2026-09-21 08:06:42.966	2026-09-21 08:06:42.966
cmuayoqks02e171kenuvr71oz	cmu2kzqeu00055t7mrgmescc1	Nancy Fille🧸❤️	+237694951032	\N	\N	2026-09-21 08:06:43.084	2026-09-21 08:06:43.084
cmuayoqkz02e371keab6eiaxr	cmu2kzqeu00055t7mrgmescc1	Nancy Fille🧸❤️	+237694951032	\N	\N	2026-09-21 08:06:43.091	2026-09-21 08:06:43.091
cmuayoqo702e571kerkmrvxx1	cmu2kzqeu00055t7mrgmescc1	Nancy~Mell❤️🍯	+237691603307	\N	\N	2026-09-21 08:06:43.207	2026-09-21 08:06:43.207
cmuayoqok02e771ke2ziro0n6	cmu2kzqeu00055t7mrgmescc1	Nancy~Mell❤️🍯	+237691603307	\N	\N	2026-09-21 08:06:43.221	2026-09-21 08:06:43.221
cmuayoqrs02e971kexskh80cm	cmu2kzqeu00055t7mrgmescc1	Nanou	+237673023722	\N	\N	2026-09-21 08:06:43.336	2026-09-21 08:06:43.336
cmuayoqrz02eb71kewrmfe3wn	cmu2kzqeu00055t7mrgmescc1	Nanou	+237673023722	\N	\N	2026-09-21 08:06:43.344	2026-09-21 08:06:43.344
cmuayoqvg02ed71keixnq49bt	cmu2kzqeu00055t7mrgmescc1	Nathan	+237683691886	\N	\N	2026-09-21 08:06:43.468	2026-09-21 08:06:43.468
cmuayoqvn02ef71kellsuy7zw	cmu2kzqeu00055t7mrgmescc1	Nathan	+237683691886	\N	\N	2026-09-21 08:06:43.475	2026-09-21 08:06:43.475
cmuayoqz802eh71ke12kwcbmv	cmu2kzqeu00055t7mrgmescc1	Nathan.M	+237657080812	\N	\N	2026-09-21 08:06:43.605	2026-09-21 08:06:43.605
cmuayoqzo02ej71keqp49l36n	cmu2kzqeu00055t7mrgmescc1	Nathan.M	+237657080812	\N	\N	2026-09-21 08:06:43.62	2026-09-21 08:06:43.62
cmuayor3302el71kewlycn5q6	cmu2kzqeu00055t7mrgmescc1	Nchotu Ulrich	+237682345198	\N	\N	2026-09-21 08:06:43.743	2026-09-21 16:27:59.894
cmuayor3d02en71ker19sdqhk	cmu2kzqeu00055t7mrgmescc1	Nchotu	+237682345198	\N	\N	2026-09-21 08:06:43.753	2026-09-21 08:06:43.753
cmuayor8w02ep71kelhgd1rv1	cmu2kzqeu00055t7mrgmescc1	Ndumu Regan	+23778498516	\N	\N	2026-09-21 08:06:43.952	2026-09-21 08:06:43.952
cmuayor9302er71keaym3bnku	cmu2kzqeu00055t7mrgmescc1	Ndumu Regan	+23778498516	\N	\N	2026-09-21 08:06:43.959	2026-09-21 08:06:43.959
cmuayorcr02et71kegidtpjcd	cmu2kzqeu00055t7mrgmescc1	Neighbors Motor Orange	+237695014854	\N	\N	2026-09-21 08:06:44.091	2026-09-21 08:06:44.091
cmuayorcz02ev71kedvr43py8	cmu2kzqeu00055t7mrgmescc1	Neighbors Motor Orange	+237695014854	\N	\N	2026-09-21 08:06:44.099	2026-09-21 08:06:44.099
cmuayorgi02ex71ke5yuvhhg8	cmu2kzqeu00055t7mrgmescc1	~DARIUS~🤩	+237692811576	\N	\N	2026-09-21 08:06:44.226	2026-09-21 16:28:18.703
cmuayorgr02ez71keyu3g0e7e	cmu2kzqeu00055t7mrgmescc1	Newton	+237692811576	\N	\N	2026-09-21 08:06:44.236	2026-09-21 08:06:44.236
cmuayos3q02f171ket26n6kh1	cmu2kzqeu00055t7mrgmescc1	Ng	+237694025677	\N	\N	2026-09-21 08:06:45.061	2026-09-21 08:06:45.061
cmuayos4002f371kewvbc4fbq	cmu2kzqeu00055t7mrgmescc1	Ng	+237694025677	\N	\N	2026-09-21 08:06:45.072	2026-09-21 08:06:45.072
cmuayos9y02f571ke2wb7y1pi	cmu2kzqeu00055t7mrgmescc1	Ni Barry	+237677564644	\N	\N	2026-09-21 08:06:45.287	2026-09-21 08:06:45.287
cmuayosab02f771kev4oa1l9f	cmu2kzqeu00055t7mrgmescc1	Ni Barry	+237677564644	\N	\N	2026-09-21 08:06:45.299	2026-09-21 08:06:45.299
cmuayosga02f971ketnq34nic	cmu2kzqeu00055t7mrgmescc1	Ni Sam	+237674828119	\N	\N	2026-09-21 08:06:45.515	2026-09-21 08:06:45.515
cmuayosgm02fb71kez6poj2b6	cmu2kzqeu00055t7mrgmescc1	Ni Sam	+237674828119	\N	\N	2026-09-21 08:06:45.526	2026-09-21 08:06:45.526
cmuayosmn02fd71keadyu2fh3	cmu2kzqeu00055t7mrgmescc1	Nk🇨🇲	+237696536735	\N	\N	2026-09-21 08:06:45.744	2026-09-21 08:06:45.744
cmuayosmz02ff71kebr34tg9i	cmu2kzqeu00055t7mrgmescc1	Nk🇨🇲	+237696536735	\N	\N	2026-09-21 08:06:45.755	2026-09-21 08:06:45.755
cmuayossj02fh71kemtq1k8rd	cmu2kzqeu00055t7mrgmescc1	Nk Léo 🤩😘	+237652931160	\N	\N	2026-09-21 08:06:45.955	2026-09-21 08:06:45.955
cmuayost002fj71key36skft4	cmu2kzqeu00055t7mrgmescc1	Nk Léo 🤩😘	+237652931160	\N	\N	2026-09-21 08:06:45.972	2026-09-21 08:06:45.972
cmuayosyn02fl71ke6p1cy6ey	cmu2kzqeu00055t7mrgmescc1	No Limts	+237695599387	\N	\N	2026-09-21 08:06:46.175	2026-09-21 08:06:46.175
cmuayosz002fn71ke08mfytse	cmu2kzqeu00055t7mrgmescc1	No Limts	+237695599387	\N	\N	2026-09-21 08:06:46.188	2026-09-21 08:06:46.188
cmuayot5502fp71kea8tfyu0w	cmu2kzqeu00055t7mrgmescc1	Nobell	+237672018360	\N	\N	2026-09-21 08:06:46.409	2026-09-21 08:06:46.409
cmuayot5h02fr71kes2q1e549	cmu2kzqeu00055t7mrgmescc1	Nobell	+237672018360	\N	\N	2026-09-21 08:06:46.422	2026-09-21 08:06:46.422
cmuayotbd02ft71keplo3oksl	cmu2kzqeu00055t7mrgmescc1	Nobody Mr Nobody	+237674332114	\N	\N	2026-09-21 08:06:46.633	2026-09-21 08:06:46.633
cmuayotbw02fv71kee8fro7uv	cmu2kzqeu00055t7mrgmescc1	Nobody Mr Nobody	+237674332114	\N	\N	2026-09-21 08:06:46.652	2026-09-21 08:06:46.652
cmuayoti002fx71kelmtx1xx1	cmu2kzqeu00055t7mrgmescc1	NoellyAkunji Miss P	+23774996298	\N	\N	2026-09-21 08:06:46.872	2026-09-21 08:06:46.872
cmuayotic02fz71kejrm2oera	cmu2kzqeu00055t7mrgmescc1	NoellyAkunji Miss P	+23774996298	\N	\N	2026-09-21 08:06:46.884	2026-09-21 08:06:46.884
cmuayotor02g171ke42zqwp9s	cmu2kzqeu00055t7mrgmescc1	Ntamen MD 💜🩵	+237657534011	\N	\N	2026-09-21 08:06:47.115	2026-09-21 08:06:47.115
cmuayotpv02g371kenbbvjgir	cmu2kzqeu00055t7mrgmescc1	Ntamen MD 💜🩵	+237657534011	\N	\N	2026-09-21 08:06:47.155	2026-09-21 08:06:47.155
cmuayotxa02g571ke5exxxjtr	cmu2kzqeu00055t7mrgmescc1	Nth+229	+22990331653	\N	\N	2026-09-21 08:06:47.422	2026-09-21 08:06:47.422
cmuayotxm02g771keiangwg27	cmu2kzqeu00055t7mrgmescc1	Nth+229	+22990331653	\N	\N	2026-09-21 08:06:47.435	2026-09-21 08:06:47.435
cmuayout902g971ke3adwmfsr	cmu2kzqeu00055t7mrgmescc1	Nto Audine🥰😘🫦	+237690510454	\N	\N	2026-09-21 08:06:48.573	2026-09-21 08:06:48.573
cmuayouu302gb71kehdk5r5gx	cmu2kzqeu00055t7mrgmescc1	Nto Audine🥰😘🫦	+237690510454	\N	\N	2026-09-21 08:06:48.603	2026-09-21 08:06:48.603
cmuayovab02gd71keym07umxl	cmu2kzqeu00055t7mrgmescc1	Nurse Ble Ble	+237681304239	\N	\N	2026-09-21 08:06:49.187	2026-09-21 08:06:49.187
cmuayovao02gf71kezbx5pou7	cmu2kzqeu00055t7mrgmescc1	Nurse Ble Ble	+237681304239	\N	\N	2026-09-21 08:06:49.2	2026-09-21 08:06:49.2
cmuayoviq02gh71kear4scx9k	cmu2kzqeu00055t7mrgmescc1	OFFSET NG📍	+237688606704	\N	\N	2026-09-21 08:06:49.49	2026-09-21 08:06:49.49
cmuayovj802gj71kekhvtb1la	cmu2kzqeu00055t7mrgmescc1	OFFSET NG📍	+237688606704	\N	\N	2026-09-21 08:06:49.508	2026-09-21 08:06:49.508
cmuayovrx02gl71ke6si1esc0	cmu2kzqeu00055t7mrgmescc1	Odg Boy 🌈🌈	+22654376912	\N	\N	2026-09-21 08:06:49.822	2026-09-21 08:06:49.822
cmuayovs402gn71ke6mwdsho7	cmu2kzqeu00055t7mrgmescc1	Odg Boy 🌈🌈	+22654376912	\N	\N	2026-09-21 08:06:49.828	2026-09-21 08:06:49.828
cmuayovyz02gp71keqqao0ctc	cmu2kzqeu00055t7mrgmescc1	Ofon	+24177342163	\N	\N	2026-09-21 08:06:50.075	2026-09-21 08:06:50.075
cmuayovzd02gr71kedfn3hthw	cmu2kzqeu00055t7mrgmescc1	Ofon	+24177342163	\N	\N	2026-09-21 08:06:50.089	2026-09-21 08:06:50.089
cmuayox4h02gt71ke1p0leuxy	cmu2kzqeu00055t7mrgmescc1	Oga Bou237	+237683215379	\N	\N	2026-09-21 08:06:51.569	2026-09-21 08:06:51.569
cmuayox5g02gv71ke0jalszzt	cmu2kzqeu00055t7mrgmescc1	Oga Bou237	+237683215379	\N	\N	2026-09-21 08:06:51.604	2026-09-21 08:06:51.604
cmuayoy0x02gx71keeq3mwya3	cmu2kzqeu00055t7mrgmescc1	Ohh	+237640739972	\N	\N	2026-09-21 08:06:52.738	2026-09-21 08:06:52.738
cmuayoy1e02gz71ke9wu8hm5h	cmu2kzqeu00055t7mrgmescc1	Ohh	+237640739972	\N	\N	2026-09-21 08:06:52.754	2026-09-21 08:06:52.754
cmuayoy8z02h171kec982eera	cmu2kzqeu00055t7mrgmescc1	Okarra	+237675141833	\N	\N	2026-09-21 08:06:53.027	2026-09-21 08:06:53.027
cmuayoy9902h371ke4mumyfn6	cmu2kzqeu00055t7mrgmescc1	Okarra	+237675141833	\N	\N	2026-09-21 08:06:53.037	2026-09-21 08:06:53.037
cmuayoyds02h571ke6w8wcebu	cmu2kzqeu00055t7mrgmescc1	Ondi	+237681469940	\N	\N	2026-09-21 08:06:53.2	2026-09-21 08:06:53.2
cmuayoye002h771kel3lstdpd	cmu2kzqeu00055t7mrgmescc1	Ondi	+237681469940	\N	\N	2026-09-21 08:06:53.208	2026-09-21 08:06:53.208
cmuayoyio02h971keuxls0vf4	cmu2kzqeu00055t7mrgmescc1	Online Job	+237672619649	\N	\N	2026-09-21 08:06:53.376	2026-09-21 08:06:53.376
cmuayoyj002hb71ke4bs5nyt0	cmu2kzqeu00055t7mrgmescc1	Online Job	+237672619649	\N	\N	2026-09-21 08:06:53.389	2026-09-21 08:06:53.389
cmuayoynb02hd71kejnffbjuk	cmu2kzqeu00055t7mrgmescc1	Orelie ❣️	+237651276381	\N	\N	2026-09-21 08:06:53.543	2026-09-21 08:06:53.543
cmuayoynl02hf71keha0uqwoq	cmu2kzqeu00055t7mrgmescc1	Orelie ❣️	+237651276381	\N	\N	2026-09-21 08:06:53.553	2026-09-21 08:06:53.553
cmuayoyr502hh71ke6rfcpa46	cmu2kzqeu00055t7mrgmescc1	P.Couthinio🖤🔥🔞	+237691909778	\N	\N	2026-09-21 08:06:53.681	2026-09-21 08:06:53.681
cmuayoyrc02hj71keplidtw69	cmu2kzqeu00055t7mrgmescc1	P.Couthinio🖤🔥🔞	+237691909778	\N	\N	2026-09-21 08:06:53.689	2026-09-21 08:06:53.689
cmuayoyvt02hl71kex7jda0ka	cmu2kzqeu00055t7mrgmescc1	PERRIER🤑🤑	+237689016517	\N	\N	2026-09-21 08:06:53.849	2026-09-21 08:06:53.849
cmuayoyys02hn71keqi5io2al	cmu2kzqeu00055t7mrgmescc1	PERRIER🤑🤑	+237689016517	\N	\N	2026-09-21 08:06:53.956	2026-09-21 08:06:53.956
cmuayoz8c02hp71keqia8b7bi	cmu2kzqeu00055t7mrgmescc1	PETROUCHKA ❣️❣️	+237693884272	\N	\N	2026-09-21 08:06:54.3	2026-09-21 08:06:54.3
cmuayoz8j02hr71kejf21y3tj	cmu2kzqeu00055t7mrgmescc1	PETROUCHKA ❣️❣️	+237693884272	\N	\N	2026-09-21 08:06:54.307	2026-09-21 08:06:54.307
cmuayozf102ht71ke5hho90cc	cmu2kzqeu00055t7mrgmescc1	Pa Garri	+237672917625	\N	\N	2026-09-21 08:06:54.542	2026-09-21 08:06:54.542
cmuayozfw02hv71kej1xrutkf	cmu2kzqeu00055t7mrgmescc1	Pa Garri	+237672917625	\N	\N	2026-09-21 08:06:54.572	2026-09-21 08:06:54.572
cmuayozmy02hx71ke873ouxlv	cmu2kzqeu00055t7mrgmescc1	Pa Manyo Mtn	+237672476799	\N	\N	2026-09-21 08:06:54.826	2026-09-21 08:06:54.826
cmuayozn702hz71kebom9yj6t	cmu2kzqeu00055t7mrgmescc1	Pa Manyo Mtn	+237672476799	\N	\N	2026-09-21 08:06:54.836	2026-09-21 08:06:54.836
cmuayoztp02i171kevfnjpf4r	cmu2kzqeu00055t7mrgmescc1	Pa Manyo Orange	+237699740878	\N	\N	2026-09-21 08:06:55.069	2026-09-21 08:06:55.069
cmuayozu202i371ke7z9y40d8	cmu2kzqeu00055t7mrgmescc1	Pa Manyo Orange	+237699740878	\N	\N	2026-09-21 08:06:55.082	2026-09-21 08:06:55.082
cmuayp02g02i571kegz2h395c	cmu2kzqeu00055t7mrgmescc1	Pa Yashuwa	+237683692198	\N	\N	2026-09-21 08:06:55.385	2026-09-21 08:06:55.385
cmuayp02o02i771ke13vnna1i	cmu2kzqeu00055t7mrgmescc1	Pa Yashuwa	+237683692198	\N	\N	2026-09-21 08:06:55.392	2026-09-21 08:06:55.392
cmuayp0b902i971ke3rcb6ejv	cmu2kzqeu00055t7mrgmescc1	Palo Junior	+237679026251	\N	\N	2026-09-21 08:06:55.701	2026-09-21 08:06:55.701
cmuayp0cn02ib71kev2gnhy2c	cmu2kzqeu00055t7mrgmescc1	Palo Junior	+237679026251	\N	\N	2026-09-21 08:06:55.751	2026-09-21 08:06:55.751
cmuayp1dw02id71kerxtvwvhu	cmu2kzqeu00055t7mrgmescc1	Paola Jessica 💝 💍	+23672924651	\N	\N	2026-09-21 08:06:57.092	2026-09-21 08:06:57.092
cmuayp1er02if71kewjr5zgxp	cmu2kzqeu00055t7mrgmescc1	Paola Jessica 💝 💍	+23672924651	\N	\N	2026-09-21 08:06:57.123	2026-09-21 08:06:57.123
cmuayp23o02ih71kevjv8ii6e	cmu2kzqeu00055t7mrgmescc1	Paola ❤️🧸	+237657919799	\N	\N	2026-09-21 08:06:58.021	2026-09-21 08:06:58.021
cmuayp24802ij71kegfi9aj9f	cmu2kzqeu00055t7mrgmescc1	Paola ❤️🧸	+237657919799	\N	\N	2026-09-21 08:06:58.04	2026-09-21 08:06:58.04
cmuayp2g202il71ke6jqr6hy0	cmu2kzqeu00055t7mrgmescc1	Papa God	+237699845854	\N	\N	2026-09-21 08:06:58.466	2026-09-21 08:06:58.466
cmuayp2gj02in71ke7gm9b9g2	cmu2kzqeu00055t7mrgmescc1	Papa God	+237699845854	\N	\N	2026-09-21 08:06:58.483	2026-09-21 08:06:58.483
cmuayp2xw02ip71kevwt4a6xd	cmu2kzqeu00055t7mrgmescc1	Papagod MASSO🙏	+237658780670	\N	\N	2026-09-21 08:06:59.108	2026-09-21 08:06:59.108
cmuayp2y602ir71kexw8ntn91	cmu2kzqeu00055t7mrgmescc1	Papagod MASSO🙏	+237658780670	\N	\N	2026-09-21 08:06:59.118	2026-09-21 08:06:59.118
cmuayp34m02it71keaosb543d	cmu2kzqeu00055t7mrgmescc1	Parle-G	+2348125857585	\N	\N	2026-09-21 08:06:59.35	2026-09-21 08:06:59.35
cmuayp34t02iv71keibxqwzuh	cmu2kzqeu00055t7mrgmescc1	Parle-G	+2348125857585	\N	\N	2026-09-21 08:06:59.358	2026-09-21 08:06:59.358
cmuayp3bo02ix71keantv03ts	cmu2kzqeu00055t7mrgmescc1	Parlons Business 🧠👙🍑👅🇨🇵	+33744299432	\N	\N	2026-09-21 08:06:59.604	2026-09-21 08:06:59.604
cmuayp3c402iz71keqj0gcm49	cmu2kzqeu00055t7mrgmescc1	Parlons Business 🧠👙🍑👅🇨🇵	+33744299432	\N	\N	2026-09-21 08:06:59.621	2026-09-21 08:06:59.621
cmuayp3gr02j171kejkemq8i6	cmu2kzqeu00055t7mrgmescc1	Parmuel	+237659283802	\N	\N	2026-09-21 08:06:59.787	2026-09-21 08:06:59.787
cmuayp3h402j371kelkw4dz60	cmu2kzqeu00055t7mrgmescc1	Parmuel	+237659283802	\N	\N	2026-09-21 08:06:59.8	2026-09-21 08:06:59.8
cmuayp3ly02j571kegt59uveq	cmu2kzqeu00055t7mrgmescc1	Passenger	+237654515916	\N	\N	2026-09-21 08:06:59.974	2026-09-21 08:06:59.974
cmuayp3mf02j771kenkem0pmd	cmu2kzqeu00055t7mrgmescc1	Passenger	+237654515916	\N	\N	2026-09-21 08:06:59.991	2026-09-21 08:06:59.991
cmuayp3uc02j971kenubzqqxk	cmu2kzqeu00055t7mrgmescc1	Pastor B Ndi	+237671141798	\N	\N	2026-09-21 08:07:00.276	2026-09-21 08:07:00.276
cmuayp3uq02jb71kelktu6p1z	cmu2kzqeu00055t7mrgmescc1	Pastor B Ndi	+237671141798	\N	\N	2026-09-21 08:07:00.29	2026-09-21 08:07:00.29
cmuayp3z702jd71kekg0fhoe0	cmu2kzqeu00055t7mrgmescc1	Pastor Basil 2	+237671116717	\N	\N	2026-09-21 08:07:00.451	2026-09-21 08:07:00.451
cmuayp3zd02jf71kewl7ncw1x	cmu2kzqeu00055t7mrgmescc1	Pastor Basil 2	+237671116717	\N	\N	2026-09-21 08:07:00.457	2026-09-21 08:07:00.457
cmuayp49d02jh71kebnue9jm3	cmu2kzqeu00055t7mrgmescc1	Pastor Basile	+23771116717	\N	\N	2026-09-21 08:07:00.817	2026-09-21 08:07:00.817
cmuayp49m02jj71ke455qk8xf	cmu2kzqeu00055t7mrgmescc1	Pastor Basile	+23771116717	\N	\N	2026-09-21 08:07:00.826	2026-09-21 08:07:00.826
cmuayp4go02jl71kez7mnxemj	cmu2kzqeu00055t7mrgmescc1	Pastor Basile	+237678311111	\N	\N	2026-09-21 08:07:01.08	2026-09-21 08:07:01.08
cmuayp4h002jn71keh2pd7fjh	cmu2kzqeu00055t7mrgmescc1	Pastor Basile	+237678311111	\N	\N	2026-09-21 08:07:01.092	2026-09-21 08:07:01.092
cmuayp4nv02jp71ked5ps2a17	cmu2kzqeu00055t7mrgmescc1	Pastor Bassel Ndi	+237676380355	\N	\N	2026-09-21 08:07:01.339	2026-09-21 08:07:01.339
cmuayp4oa02jr71ked8f3xp0k	cmu2kzqeu00055t7mrgmescc1	Pastor Bassel Ndi	+237676380355	\N	\N	2026-09-21 08:07:01.354	2026-09-21 08:07:01.354
cmuayp4vr02jt71kewmw2f96c	cmu2kzqeu00055t7mrgmescc1	Pastor Emma	+23777135609	\N	\N	2026-09-21 08:07:01.623	2026-09-21 08:07:01.623
cmuayp4w302jv71kebx324gxp	cmu2kzqeu00055t7mrgmescc1	Pastor Emma	+23777135609	\N	\N	2026-09-21 08:07:01.635	2026-09-21 08:07:01.635
cmuayp53i02jx71keqa9yny25	cmu2kzqeu00055t7mrgmescc1	Pastor Fred SAVES !!	+23774298541	\N	\N	2026-09-21 08:07:01.902	2026-09-21 08:07:01.902
cmuayp53u02jz71kefm8sy2o9	cmu2kzqeu00055t7mrgmescc1	Pastor Fred SAVES !!	+23774298541	\N	\N	2026-09-21 08:07:01.914	2026-09-21 08:07:01.914
cmuayp5do02k171kec5bmvimg	cmu2kzqeu00055t7mrgmescc1	Pastor Joyce Nondia Mrs	+23774104268	\N	\N	2026-09-21 08:07:02.269	2026-09-21 08:07:02.269
cmuayp5e502k371kemy1z577k	cmu2kzqeu00055t7mrgmescc1	Pastor Joyce Nondia Mrs	+23774104268	\N	\N	2026-09-21 08:07:02.285	2026-09-21 08:07:02.285
cmuayp5pa02k571kevau0fh1q	cmu2kzqeu00055t7mrgmescc1	Patricia 🇨🇲🔥	+237697754165	\N	\N	2026-09-21 08:07:02.686	2026-09-21 08:07:02.686
cmuayp5pn02k771kegr48oyyc	cmu2kzqeu00055t7mrgmescc1	Patricia 🇨🇲🔥	+237697754165	\N	\N	2026-09-21 08:07:02.699	2026-09-21 08:07:02.699
cmuayp8fu02k971kejn78fyg1	cmu2kzqeu00055t7mrgmescc1	Patrick	+237673764803	\N	\N	2026-09-21 08:07:06.234	2026-09-21 08:07:06.234
cmuayp8ge02kb71kevweu6s6n	cmu2kzqeu00055t7mrgmescc1	Patrick	+237673764803	\N	\N	2026-09-21 08:07:06.254	2026-09-21 08:07:06.254
cmuayp8t602kd71ken1jwd40y	cmu2kzqeu00055t7mrgmescc1	Patrickkams💥🎶👨🏾‍💻🎻🪘💥☺️	+237673281383	\N	\N	2026-09-21 08:07:06.714	2026-09-21 08:07:06.714
cmuayp8u802kf71ke4bze3ell	cmu2kzqeu00055t7mrgmescc1	Patrickkams💥🎶👨🏾‍💻🎻🪘💥☺️	+237673281383	\N	\N	2026-09-21 08:07:06.752	2026-09-21 08:07:06.752
cmuayp9i102kh71kei4j4nns3	cmu2kzqeu00055t7mrgmescc1	Pecia🇨🇲	+237679114072	\N	\N	2026-09-21 08:07:07.61	2026-09-21 08:07:07.61
cmuayp9je02kj71kexryemgwj	cmu2kzqeu00055t7mrgmescc1	Pecia🇨🇲	+237679114072	\N	\N	2026-09-21 08:07:07.658	2026-09-21 08:07:07.658
cmuaypbas02kl71kec0cmi1gv	cmu2kzqeu00055t7mrgmescc1	Penn	+23778433883	\N	\N	2026-09-21 08:07:09.941	2026-09-21 08:07:09.941
cmuaypbbi02kn71keft2yevtj	cmu2kzqeu00055t7mrgmescc1	Penn	+23778433883	\N	\N	2026-09-21 08:07:09.966	2026-09-21 08:07:09.966
cmuaypd1l02kp71kedi0vl0we	cmu2kzqeu00055t7mrgmescc1	Peter Asogwi	+237653207969	\N	\N	2026-09-21 08:07:12.201	2026-09-21 08:07:12.201
cmuaypd7m02kr71ke8n8lpx90	cmu2kzqeu00055t7mrgmescc1	Peter Asogwi	+237653207969	\N	\N	2026-09-21 08:07:12.418	2026-09-21 08:07:12.418
cmuaypg9b02kt71ke4wpnk8dw	cmu2kzqeu00055t7mrgmescc1	Peter Claver royal	+243822966306	\N	\N	2026-09-21 08:07:16.367	2026-09-21 08:07:16.367
cmuaypg9t02kv71ke92tiqv9i	cmu2kzqeu00055t7mrgmescc1	Peter Claver royal	+243822966306	\N	\N	2026-09-21 08:07:16.385	2026-09-21 08:07:16.385
cmuaypgly02kx71ke1dsu2bmv	cmu2kzqeu00055t7mrgmescc1	Phenix 🐦‍🔥Dollar💸💎	+237696265721	\N	\N	2026-09-21 08:07:16.822	2026-09-21 08:07:16.822
cmuaypgmw02kz71keqs4lg83e	cmu2kzqeu00055t7mrgmescc1	Phenix 🐦‍🔥Dollar💸💎	+237696265721	\N	\N	2026-09-21 08:07:16.856	2026-09-21 08:07:16.856
cmuaypgx702l171ke3g30i728	cmu2kzqeu00055t7mrgmescc1	philipfon41	+237675710899	\N	\N	2026-09-21 08:07:17.227	2026-09-21 16:28:18.256
cmuaypgxv02l371kea19xxkz4	cmu2kzqeu00055t7mrgmescc1	Philiip Fon	+237675710899	\N	\N	2026-09-21 08:07:17.251	2026-09-21 08:07:17.251
cmuayphf302l571ke9psx17ad	cmu2kzqeu00055t7mrgmescc1	Phäręll Øffîcįël	+237653579597	\N	\N	2026-09-21 08:07:17.871	2026-09-21 08:07:17.871
cmuayphgg02l771kes8y69fth	cmu2kzqeu00055t7mrgmescc1	Phäręll Øffîcįël	+237653579597	\N	\N	2026-09-21 08:07:17.92	2026-09-21 08:07:17.92
cmuaypj6302l971kefvh5zg6s	cmu2kzqeu00055t7mrgmescc1	Phénomène	+237676554829	\N	\N	2026-09-21 08:07:20.139	2026-09-21 08:07:20.139
cmuaypjcy02lb71kec4bkgsce	cmu2kzqeu00055t7mrgmescc1	Phénomène	+237676554829	\N	\N	2026-09-21 08:07:20.386	2026-09-21 08:07:20.386
cmuaypnks02ld71keikewe238	cmu2kzqeu00055t7mrgmescc1	Piano Guy	+23707085763559	\N	\N	2026-09-21 08:07:25.852	2026-09-21 08:07:25.852
cmuaypnrc02lf71kedcbotuvc	cmu2kzqeu00055t7mrgmescc1	Piano Guy	+23707085763559	\N	\N	2026-09-21 08:07:26.088	2026-09-21 08:07:26.088
cmuaypqe302lh71kehj8xh4n2	cmu2kzqeu00055t7mrgmescc1	Poumegne Patricia Jessy	+237654211759	\N	\N	2026-09-21 08:07:29.499	2026-09-21 08:07:29.499
cmuaypqhr02lj71keeut47x7a	cmu2kzqeu00055t7mrgmescc1	Poumegne Patricia Jessy	+237654211759	\N	\N	2026-09-21 08:07:29.631	2026-09-21 08:07:29.631
cmuayprcy02ll71kedq17bv6w	cmu2kzqeu00055t7mrgmescc1	Precious 💖❤️‍🩹❤️‍🩹	+237672180561	\N	\N	2026-09-21 08:07:30.754	2026-09-21 08:07:30.754
cmuayprdr02ln71kepgnzbxqb	cmu2kzqeu00055t7mrgmescc1	Precious 💖❤️‍🩹❤️‍🩹	+237672180561	\N	\N	2026-09-21 08:07:30.783	2026-09-21 08:07:30.783
cmuayprrm02lp71kek9s5o4dd	cmu2kzqeu00055t7mrgmescc1	Preshbae Yewge	+237682480104	\N	\N	2026-09-21 08:07:31.282	2026-09-21 08:07:31.282
cmuayprs402lr71keg0euzmr8	cmu2kzqeu00055t7mrgmescc1	Preshbae Yewge	+237682480104	\N	\N	2026-09-21 08:07:31.3	2026-09-21 08:07:31.3
cmuaypsa102lt71kehtchuf5c	cmu2kzqeu00055t7mrgmescc1	Presi Atali	+23775113615	\N	\N	2026-09-21 08:07:31.945	2026-09-21 08:07:31.945
cmuaypsaf02lv71keyep5klp5	cmu2kzqeu00055t7mrgmescc1	Presi Atali	+23775113615	\N	\N	2026-09-21 08:07:31.959	2026-09-21 08:07:31.959
cmuaypu7n02lx71kewc2ll3dp	cmu2kzqeu00055t7mrgmescc1	barronpride965	+237677285308	\N	\N	2026-09-21 08:07:34.451	2026-09-21 16:28:16.73
cmuaypu7y02lz71ke8yau79oh	cmu2kzqeu00055t7mrgmescc1	Pride	+237677285308	\N	\N	2026-09-21 08:07:34.463	2026-09-21 08:07:34.463
cmuaypulu02m171kez3q61bze	cmu2kzqeu00055t7mrgmescc1	Prince Hakim	+237691991262	\N	\N	2026-09-21 08:07:34.963	2026-09-21 08:07:34.963
cmuaypunx02m371kesb5x9lkg	cmu2kzqeu00055t7mrgmescc1	Prince Hakim	+237691991262	\N	\N	2026-09-21 08:07:35.037	2026-09-21 08:07:35.037
cmuaypvp902m571ke3sd5s2dy	cmu2kzqeu00055t7mrgmescc1	Prince JJ	+237678089604	\N	\N	2026-09-21 08:07:36.382	2026-09-21 08:07:36.382
cmuaypvpg02m771kegk1olnu7	cmu2kzqeu00055t7mrgmescc1	Prince JJ	+237678089604	\N	\N	2026-09-21 08:07:36.388	2026-09-21 08:07:36.388
cmuaypvx902m971ke36mdnpsd	cmu2kzqeu00055t7mrgmescc1	Prince Junior	+237679650270	\N	\N	2026-09-21 08:07:36.669	2026-09-21 08:07:36.669
cmuaypvxz02mb71kef2t33iec	cmu2kzqeu00055t7mrgmescc1	Prince Junior	+237679650270	\N	\N	2026-09-21 08:07:36.695	2026-09-21 08:07:36.695
cmuaypwg502md71ker24pwx0f	cmu2kzqeu00055t7mrgmescc1	Princess🤳🏽	+237682711650	\N	\N	2026-09-21 08:07:37.35	2026-09-21 08:07:37.35
cmuaypwh702mf71kem3qat5fs	cmu2kzqeu00055t7mrgmescc1	Princess🤳🏽	+237682711650	\N	\N	2026-09-21 08:07:37.387	2026-09-21 08:07:37.387
cmuaypx7p02mh71ke6n2atygm	cmu2kzqeu00055t7mrgmescc1	Princess🥰	+237651557983	\N	\N	2026-09-21 08:07:38.341	2026-09-21 08:07:38.341
cmuaypx7x02mj71kebymgoaly	cmu2kzqeu00055t7mrgmescc1	Princess🥰	+237651557983	\N	\N	2026-09-21 08:07:38.349	2026-09-21 08:07:38.349
cmuaypxma02ml71kerfb5fyv8	cmu2kzqeu00055t7mrgmescc1	Printer	+237699595997	\N	\N	2026-09-21 08:07:38.866	2026-09-21 08:07:38.866
cmuaypxmr02mn71kem24d34cd	cmu2kzqeu00055t7mrgmescc1	Printer	+237699595997	\N	\N	2026-09-21 08:07:38.883	2026-09-21 08:07:38.883
cmuaypye102mp71keq5gpcn7u	cmu2kzqeu00055t7mrgmescc1	Printer	+237699595996	\N	\N	2026-09-21 08:07:39.865	2026-09-21 08:07:39.865
cmuaypyek02mr71kemgehg0f5	cmu2kzqeu00055t7mrgmescc1	Printer	+237699595996	\N	\N	2026-09-21 08:07:39.884	2026-09-21 08:07:39.884
cmuaypyq202mt71kem0xxo5gx	cmu2kzqeu00055t7mrgmescc1	Prisca	+237671143659	\N	\N	2026-09-21 08:07:40.298	2026-09-21 08:07:40.298
cmuaypyqi02mv71keaikgwu9q	cmu2kzqeu00055t7mrgmescc1	Prisca	+237671143659	\N	\N	2026-09-21 08:07:40.315	2026-09-21 08:07:40.315
cmuaypzz002mx71kej1pib9pc	cmu2kzqeu00055t7mrgmescc1	Prisca 🔥🌟	+237640651655	\N	\N	2026-09-21 08:07:41.916	2026-09-21 08:07:41.916
cmuayq00h02mz71kepexp9c5x	cmu2kzqeu00055t7mrgmescc1	Prisca 🔥🌟	+237640651655	\N	\N	2026-09-21 08:07:41.969	2026-09-21 08:07:41.969
cmuayq56x02n171kefwfj3odj	cmu2kzqeu00055t7mrgmescc1	PÃPLØ DØLLÃR	+237680823976	\N	\N	2026-09-21 08:07:48.681	2026-09-21 08:07:48.681
cmuayq58802n371ketjmz13lp	cmu2kzqeu00055t7mrgmescc1	PÃPLØ DØLLÃR	+237680823976	\N	\N	2026-09-21 08:07:48.728	2026-09-21 08:07:48.728
cmuayq62202n571ke7x83598i	cmu2kzqeu00055t7mrgmescc1	Quatre Serge •• 🙂	+237691194355	\N	\N	2026-09-21 08:07:49.802	2026-09-21 08:07:49.802
cmuayq62v02n771ke84ub4cwb	cmu2kzqeu00055t7mrgmescc1	Quatre Serge •• 🙂	+237691194355	\N	\N	2026-09-21 08:07:49.831	2026-09-21 08:07:49.831
cmuayq7us02n971ketc6mkv34	cmu2kzqeu00055t7mrgmescc1	Queen Bee❤️❤️	+237671757023	\N	\N	2026-09-21 08:07:52.132	2026-09-21 08:07:52.132
cmuayq7y202nb71ke9mij9h05	cmu2kzqeu00055t7mrgmescc1	Queen Bee❤️❤️	+237671757023	\N	\N	2026-09-21 08:07:52.25	2026-09-21 08:07:52.25
cmuayq8e402nd71ke6dhoqahx	cmu2kzqeu00055t7mrgmescc1	Queen Fille❤️	+237659426910	\N	\N	2026-09-21 08:07:52.828	2026-09-21 08:07:52.828
cmuayq8fn02nf71ke6q171rib	cmu2kzqeu00055t7mrgmescc1	Queen Fille❤️	+237659426910	\N	\N	2026-09-21 08:07:52.883	2026-09-21 08:07:52.883
cmuayq8vn02nh71keyt47oim5	cmu2kzqeu00055t7mrgmescc1	R.AYAH	+237681839026	\N	\N	2026-09-21 08:07:53.46	2026-09-21 08:07:53.46
cmuayq8vv02nj71kevgwkv34c	cmu2kzqeu00055t7mrgmescc1	R.AYAH	+237681839026	\N	\N	2026-09-21 08:07:53.467	2026-09-21 08:07:53.467
cmuayq92j02nl71ke2drwjk0a	cmu2kzqeu00055t7mrgmescc1	RACHIDI	+22955895961	\N	\N	2026-09-21 08:07:53.707	2026-09-21 08:07:53.707
cmuayq93302nn71kesda55bkh	cmu2kzqeu00055t7mrgmescc1	RACHIDI	+22955895961	\N	\N	2026-09-21 08:07:53.727	2026-09-21 08:07:53.727
cmuayq9sa02np71ke9ju3frwh	cmu2kzqeu00055t7mrgmescc1	REJOICE	+237688454003	\N	\N	2026-09-21 08:07:54.634	2026-09-21 08:07:54.634
cmuayq9sy02nr71kez7eugt30	cmu2kzqeu00055t7mrgmescc1	REJOICE	+237688454003	\N	\N	2026-09-21 08:07:54.658	2026-09-21 08:07:54.658
cmuayqa0302nt71kel7y1j202	cmu2kzqeu00055t7mrgmescc1	RSN	+237682961913	\N	\N	2026-09-21 08:07:54.915	2026-09-21 08:07:54.915
cmuayqa1z02nv71keitcdpbdj	cmu2kzqeu00055t7mrgmescc1	RSN	+237682961913	\N	\N	2026-09-21 08:07:54.983	2026-09-21 08:07:54.983
cmuayqa8002nx71kekl2dxgvw	cmu2kzqeu00055t7mrgmescc1	Ragouel Diff	+237694772319	\N	\N	2026-09-21 08:07:55.2	2026-09-21 08:07:55.2
cmuayqa8d02nz71kegcegqyms	cmu2kzqeu00055t7mrgmescc1	Ragouel Diff	+237694772319	\N	\N	2026-09-21 08:07:55.213	2026-09-21 08:07:55.213
cmuayqadd02o171ke9qymm63u	cmu2kzqeu00055t7mrgmescc1	Rahelle 🥰 👑	+237620968746	\N	\N	2026-09-21 08:07:55.393	2026-09-21 08:07:55.393
cmuayqads02o371keh373lmch	cmu2kzqeu00055t7mrgmescc1	Rahelle 🥰 👑	+237620968746	\N	\N	2026-09-21 08:07:55.409	2026-09-21 08:07:55.409
cmuayqaj802o571kew556kzgo	cmu2kzqeu00055t7mrgmescc1	Rahim Multi Service	+22667949826	\N	\N	2026-09-21 08:07:55.605	2026-09-21 08:07:55.605
cmuayqajg02o771keh5ql981f	cmu2kzqeu00055t7mrgmescc1	Rahim Multi Service	+22667949826	\N	\N	2026-09-21 08:07:55.612	2026-09-21 08:07:55.612
cmuayqdd902o971kezdyr6ppm	cmu2kzqeu00055t7mrgmescc1	Raissa Besty🥺	+237656427432	\N	\N	2026-09-21 08:07:59.277	2026-09-21 08:07:59.277
cmuayqddh02ob71ke3u33u6mz	cmu2kzqeu00055t7mrgmescc1	Raissa Besty🥺	+237656427432	\N	\N	2026-09-21 08:07:59.285	2026-09-21 08:07:59.285
cmuayqdi502od71ke4ggefwqm	cmu2kzqeu00055t7mrgmescc1	Raissaglory	+237651946390	\N	\N	2026-09-21 08:07:59.453	2026-09-21 08:07:59.453
cmuayqdie02of71kexnly097k	cmu2kzqeu00055t7mrgmescc1	Raissaglory	+237651946390	\N	\N	2026-09-21 08:07:59.462	2026-09-21 08:07:59.462
cmuayqdpd02oh71keo6ug8nxb	cmu2kzqeu00055t7mrgmescc1	Ralph Axel	+237691802761	\N	\N	2026-09-21 08:07:59.713	2026-09-21 08:07:59.713
cmuayqdqo02oj71kekciid26y	cmu2kzqeu00055t7mrgmescc1	Ralph Axel	+237691802761	\N	\N	2026-09-21 08:07:59.76	2026-09-21 08:07:59.76
cmuayqdyz02ol71ke5mq9kqqi	cmu2kzqeu00055t7mrgmescc1	Randy	+237678229137	\N	\N	2026-09-21 08:08:00.059	2026-09-21 08:08:00.059
cmuayqdzg02on71ke0qo64if7	cmu2kzqeu00055t7mrgmescc1	Randy	+237678229137	\N	\N	2026-09-21 08:08:00.076	2026-09-21 08:08:00.076
cmuayqeds02op71ke8kfetdkm	cmu2kzqeu00055t7mrgmescc1	Randy	+237654008749	\N	\N	2026-09-21 08:08:00.593	2026-09-21 08:08:00.593
cmuayqee002or71ke9d1l019t	cmu2kzqeu00055t7mrgmescc1	Randy	+237654008749	\N	\N	2026-09-21 08:08:00.6	2026-09-21 08:08:00.6
cmuayqeix02ot71kejqp045og	cmu2kzqeu00055t7mrgmescc1	Randy Louis Vuitton🍷 🖖🏽💸	+237655572257	\N	\N	2026-09-21 08:08:00.777	2026-09-21 08:08:00.777
cmuayqejb02ov71kes51u2xmk	cmu2kzqeu00055t7mrgmescc1	Randy Louis Vuitton🍷 🖖🏽💸	+237655572257	\N	\N	2026-09-21 08:08:00.791	2026-09-21 08:08:00.791
cmuayqeqb02ox71keyk085pnz	cmu2kzqeu00055t7mrgmescc1	Raphaëlle Bryanna	+33661286465	\N	\N	2026-09-21 08:08:01.043	2026-09-21 08:08:01.043
cmuayqeqm02oz71kepbj1k2u2	cmu2kzqeu00055t7mrgmescc1	Raphaëlle Bryanna	+33661286465	\N	\N	2026-09-21 08:08:01.054	2026-09-21 08:08:01.054
cmuayqeul02p171kejf891bmx	cmu2kzqeu00055t7mrgmescc1	Rayan Ngoune	+237696846554	\N	\N	2026-09-21 08:08:01.197	2026-09-21 08:08:01.197
cmuayqeuw02p371keg7e98xbs	cmu2kzqeu00055t7mrgmescc1	Rayan Ngoune	+237696846554	\N	\N	2026-09-21 08:08:01.208	2026-09-21 08:08:01.208
cmuayqeyt02p571kem4v7z640	cmu2kzqeu00055t7mrgmescc1	Redon	+237681629241	\N	\N	2026-09-21 08:08:01.349	2026-09-21 08:08:01.349
cmuayqez202p771keuvyrllkj	cmu2kzqeu00055t7mrgmescc1	Redon	+237681629241	\N	\N	2026-09-21 08:08:01.358	2026-09-21 08:08:01.358
cmuayqf4802p971kea8skvxi1	cmu2kzqeu00055t7mrgmescc1	Rena	+237674814880	\N	\N	2026-09-21 08:08:01.544	2026-09-21 08:08:01.544
cmuayqf4g02pb71kep8omoj77	cmu2kzqeu00055t7mrgmescc1	Rena	+237674814880	\N	\N	2026-09-21 08:08:01.552	2026-09-21 08:08:01.552
cmuayqf8w02pd71kefdz4izjg	cmu2kzqeu00055t7mrgmescc1	Rengo	+237697723146	\N	\N	2026-09-21 08:08:01.712	2026-09-21 08:08:01.712
cmuayqf9802pf71kefrz01ibd	cmu2kzqeu00055t7mrgmescc1	Rengo	+237697723146	\N	\N	2026-09-21 08:08:01.725	2026-09-21 08:08:01.725
cmuayqffo02ph71kelzgsz38h	cmu2kzqeu00055t7mrgmescc1	Richlande	+237681385237	\N	\N	2026-09-21 08:08:01.956	2026-09-21 08:08:01.956
cmuayqffw02pj71kewieouzmj	cmu2kzqeu00055t7mrgmescc1	Richlande	+237681385237	\N	\N	2026-09-21 08:08:01.964	2026-09-21 08:08:01.964
cmuayqflw02pl71kezeohhepr	cmu2kzqeu00055t7mrgmescc1	Ridaflora❤️💦	+237695336454	\N	\N	2026-09-21 08:08:02.18	2026-09-21 08:08:02.18
cmuayqfm702pn71keortboyv2	cmu2kzqeu00055t7mrgmescc1	Ridaflora❤️💦	+237695336454	\N	\N	2026-09-21 08:08:02.191	2026-09-21 08:08:02.191
cmuayqfr902pp71keld6xcyg2	cmu2kzqeu00055t7mrgmescc1	Roderick 👿👿🔥	+237679568489	\N	\N	2026-09-21 08:08:02.373	2026-09-21 08:08:02.373
cmuayqfrh02pr71ke1twxe4pc	cmu2kzqeu00055t7mrgmescc1	Roderick 👿👿🔥	+237679568489	\N	\N	2026-09-21 08:08:02.382	2026-09-21 08:08:02.382
cmuayqfxd02pt71ke59sdvwok	cmu2kzqeu00055t7mrgmescc1	Roi Drip	+237697369564	\N	\N	2026-09-21 08:08:02.593	2026-09-21 08:08:02.593
cmuayqfxp02pv71ketoyoazo7	cmu2kzqeu00055t7mrgmescc1	Roi Drip	+237697369564	\N	\N	2026-09-21 08:08:02.605	2026-09-21 08:08:02.605
cmuayqg4n02px71keodjo4vfy	cmu2kzqeu00055t7mrgmescc1	Roland Abunaya	+23775032887	\N	\N	2026-09-21 08:08:02.855	2026-09-21 08:08:02.855
cmuayqg4v02pz71kem0bm4pqp	cmu2kzqeu00055t7mrgmescc1	Roland Abunaya	+23775032887	\N	\N	2026-09-21 08:08:02.863	2026-09-21 08:08:02.863
cmuayqgj102q171ke7qu4m9f7	cmu2kzqeu00055t7mrgmescc1	Roland Pategou	+237640152176	\N	\N	2026-09-21 08:08:03.373	2026-09-21 08:08:03.373
cmuayqgjg02q371ketzm1k182	cmu2kzqeu00055t7mrgmescc1	Roland Pategou	+237640152176	\N	\N	2026-09-21 08:08:03.388	2026-09-21 08:08:03.388
cmuayqgp302q571keztff9l6h	cmu2kzqeu00055t7mrgmescc1	Rolf Coin237	+237676220524	\N	\N	2026-09-21 08:08:03.592	2026-09-21 08:08:03.592
cmuayqgpb02q771kenfmbuv0q	cmu2kzqeu00055t7mrgmescc1	Rolf Coin237	+237676220524	\N	\N	2026-09-21 08:08:03.599	2026-09-21 08:08:03.599
cmuayqgu302q971kek4c7cemh	cmu2kzqeu00055t7mrgmescc1	Rollins Stone	+237650667005	\N	\N	2026-09-21 08:08:03.771	2026-09-21 08:08:03.771
cmuayqguc02qb71ke2x0f6owv	cmu2kzqeu00055t7mrgmescc1	Rollins Stone	+237650667005	\N	\N	2026-09-21 08:08:03.78	2026-09-21 08:08:03.78
cmuayqgze02qd71ke21r02pcy	cmu2kzqeu00055t7mrgmescc1	Romael Fopa😌❤️🔥	+237658677363	\N	\N	2026-09-21 08:08:03.963	2026-09-21 08:08:03.963
cmuayqgzr02qf71ke1oae39z6	cmu2kzqeu00055t7mrgmescc1	Romael Fopa😌❤️🔥	+237658677363	\N	\N	2026-09-21 08:08:03.975	2026-09-21 08:08:03.975
cmuayqh5d02qh71kemfd3kvav	cmu2kzqeu00055t7mrgmescc1	Romaine	+237653258292	\N	\N	2026-09-21 08:08:04.178	2026-09-21 08:08:04.178
cmuayqh5m02qj71kehalvcu4h	cmu2kzqeu00055t7mrgmescc1	Romaine	+237653258292	\N	\N	2026-09-21 08:08:04.186	2026-09-21 08:08:04.186
cmuayqhb002ql71ke5k7bkhph	cmu2kzqeu00055t7mrgmescc1	Romial	+237652777196	\N	\N	2026-09-21 08:08:04.381	2026-09-21 08:08:04.381
cmuayqhba02qn71kefu2ro4u8	cmu2kzqeu00055t7mrgmescc1	Romial	+237652777196	\N	\N	2026-09-21 08:08:04.391	2026-09-21 08:08:04.391
cmuayqhfi02qp71kex7hab1i4	cmu2kzqeu00055t7mrgmescc1	Rose🇨🇲	+237672013867	\N	\N	2026-09-21 08:08:04.543	2026-09-21 08:08:04.543
cmuayqhfq02qr71kep91pdgxa	cmu2kzqeu00055t7mrgmescc1	Rose🇨🇲	+237672013867	\N	\N	2026-09-21 08:08:04.551	2026-09-21 08:08:04.551
cmuayqhjm02qt71ke2k3n0t0c	cmu2kzqeu00055t7mrgmescc1	Rose Fille🍀	+237694289363	\N	\N	2026-09-21 08:08:04.691	2026-09-21 08:08:04.691
cmuayqhjt02qv71kejpm5i8mf	cmu2kzqeu00055t7mrgmescc1	Rose Fille🍀	+237694289363	\N	\N	2026-09-21 08:08:04.698	2026-09-21 08:08:04.698
cmuayqhno02qx71ken446uest	cmu2kzqeu00055t7mrgmescc1	Rose Mb	+237693137652	\N	\N	2026-09-21 08:08:04.836	2026-09-21 08:08:04.836
cmuayqhnx02qz71keuji41ye0	cmu2kzqeu00055t7mrgmescc1	Rose Mb	+237693137652	\N	\N	2026-09-21 08:08:04.845	2026-09-21 08:08:04.845
cmuayqhr902r171kehcebtmv6	cmu2kzqeu00055t7mrgmescc1	Rose🌙	+237694481652	\N	\N	2026-09-21 08:08:04.965	2026-09-21 08:08:04.965
cmuayqhrj02r371keej52tifr	cmu2kzqeu00055t7mrgmescc1	Rose🌙	+237694481652	\N	\N	2026-09-21 08:08:04.975	2026-09-21 08:08:04.975
cmuayqhvd02r571ke7h4fgvzz	cmu2kzqeu00055t7mrgmescc1	Rostand	+237673773223	\N	\N	2026-09-21 08:08:05.113	2026-09-21 08:08:05.113
cmuayqhvn02r771keqp70jog3	cmu2kzqeu00055t7mrgmescc1	Rostand	+237673773223	\N	\N	2026-09-21 08:08:05.123	2026-09-21 08:08:05.123
cmuayqi5i02r971keal539td0	cmu2kzqeu00055t7mrgmescc1	Roy	+23709030282761	\N	\N	2026-09-21 08:08:05.478	2026-09-21 08:08:05.478
cmuayqi5t02rb71kep6vghfzt	cmu2kzqeu00055t7mrgmescc1	Roy	+23709030282761	\N	\N	2026-09-21 08:08:05.489	2026-09-21 08:08:05.489
cmuayqib702rd71kebdc41zbn	cmu2kzqeu00055t7mrgmescc1	Ruhanna Beauty Hair	+237694825062	\N	\N	2026-09-21 08:08:05.684	2026-09-21 08:08:05.684
cmuayqibf02rf71ke9pj4wx93	cmu2kzqeu00055t7mrgmescc1	Ruhanna Beauty Hair	+237694825062	\N	\N	2026-09-21 08:08:05.691	2026-09-21 08:08:05.691
cmuayqiez02rh71ke5eq8301n	cmu2kzqeu00055t7mrgmescc1	Ruth	+237653425372	\N	\N	2026-09-21 08:08:05.819	2026-09-21 08:08:05.819
cmuayqif602rj71kerig0uiid	cmu2kzqeu00055t7mrgmescc1	Ruth	+237653425372	\N	\N	2026-09-21 08:08:05.826	2026-09-21 08:08:05.826
cmuayqije02rl71ke6fib648c	cmu2kzqeu00055t7mrgmescc1	SANDRINE FLORENCE	+23592787594	\N	\N	2026-09-21 08:08:05.979	2026-09-21 08:08:05.979
cmuayqijm02rn71keq9qqqjcc	cmu2kzqeu00055t7mrgmescc1	SANDRINE FLORENCE	+23592787594	\N	\N	2026-09-21 08:08:05.986	2026-09-21 08:08:05.986
cmuayqio502rp71kenj6amutz	cmu2kzqeu00055t7mrgmescc1	Sarah 2	+237692162751	\N	\N	2026-09-21 08:08:06.149	2026-09-21 16:28:07.877
cmuayqiof02rr71ke2cuptcpe	cmu2kzqeu00055t7mrgmescc1	SARAH ❤️	+237692162751	\N	\N	2026-09-21 08:08:06.16	2026-09-21 08:08:06.16
cmuayqj7c02rt71ke5h5sy1k1	cmu2kzqeu00055t7mrgmescc1	SETONDJI	+22997457515	\N	\N	2026-09-21 08:08:06.84	2026-09-21 08:08:06.84
cmuayqj7j02rv71kes014fyye	cmu2kzqeu00055t7mrgmescc1	SETONDJI	+22997457515	\N	\N	2026-09-21 08:08:06.847	2026-09-21 08:08:06.847
cmuayqjd002rx71ke2vy0vr5o	cmu2kzqeu00055t7mrgmescc1	SN💜	+237681616081	\N	\N	2026-09-21 08:08:07.044	2026-09-21 08:08:07.044
cmuayqjd802rz71ke0iildatt	cmu2kzqeu00055t7mrgmescc1	SN💜	+237681616081	\N	\N	2026-09-21 08:08:07.052	2026-09-21 08:08:07.052
cmuayqji002s171kels0u1k9z	cmu2kzqeu00055t7mrgmescc1	SOCRATES ATL	+237680972331	\N	\N	2026-09-21 08:08:07.224	2026-09-21 08:08:07.224
cmuayqji702s371kemk9asn78	cmu2kzqeu00055t7mrgmescc1	SOCRATES ATL	+237680972331	\N	\N	2026-09-21 08:08:07.231	2026-09-21 08:08:07.231
cmuayqjma02s571keqydklucy	cmu2kzqeu00055t7mrgmescc1	SYLVIE ☺🦋🥀	+237680255902	\N	\N	2026-09-21 08:08:07.378	2026-09-21 08:08:07.378
cmuayqjmo02s771ke3fu7ksr3	cmu2kzqeu00055t7mrgmescc1	SYLVIE ☺🦋🥀	+237680255902	\N	\N	2026-09-21 08:08:07.392	2026-09-21 08:08:07.392
cmuayqjs702s971keuhroj4qx	cmu2kzqeu00055t7mrgmescc1	Sa Majesté Lohove 👑✨	+237692511539	\N	\N	2026-09-21 08:08:07.591	2026-09-21 08:08:07.591
cmuayqjsd02sb71kevtr9ycat	cmu2kzqeu00055t7mrgmescc1	Sa Majesté Lohove 👑✨	+237692511539	\N	\N	2026-09-21 08:08:07.598	2026-09-21 08:08:07.598
cmuayqjy502sd71kehl960zh1	cmu2kzqeu00055t7mrgmescc1	Saints Anorld King (son of fire)	+237656727447	\N	\N	2026-09-21 08:08:07.806	2026-09-21 08:08:07.806
cmuayqjyd02sf71kesn6xz2ne	cmu2kzqeu00055t7mrgmescc1	Saints Anorld King (son of fire)	+237656727447	\N	\N	2026-09-21 08:08:07.813	2026-09-21 08:08:07.813
cmuayqk3b02sh71kerwonbncx	cmu2kzqeu00055t7mrgmescc1	Saitama	+237677371809	\N	\N	2026-09-21 08:08:07.991	2026-09-21 08:08:07.991
cmuayqk3j02sj71ke9e4ndmrj	cmu2kzqeu00055t7mrgmescc1	Saitama	+237677371809	\N	\N	2026-09-21 08:08:08	2026-09-21 08:08:08
cmuayqk7y02sl71kefg39hw6w	cmu2kzqeu00055t7mrgmescc1	Salao Cr	+23672071605	\N	\N	2026-09-21 08:08:08.158	2026-09-21 08:08:08.158
cmuayqk8702sn71kehva0eknq	cmu2kzqeu00055t7mrgmescc1	Salao Cr	+23672071605	\N	\N	2026-09-21 08:08:08.167	2026-09-21 08:08:08.167
cmuayqkd202sp71kegsmk0skt	cmu2kzqeu00055t7mrgmescc1	Sam	+237694941380	\N	\N	2026-09-21 08:08:08.343	2026-09-21 08:08:08.343
cmuayqkdg02sr71kesnmibau4	cmu2kzqeu00055t7mrgmescc1	Sam	+237694941380	\N	\N	2026-09-21 08:08:08.356	2026-09-21 08:08:08.356
cmuayqkjw02st71ke157ewpkc	cmu2kzqeu00055t7mrgmescc1	Sam Nd.	+237698105748	\N	\N	2026-09-21 08:08:08.588	2026-09-21 08:08:08.588
cmuayqkk602sv71keiekbjnp3	cmu2kzqeu00055t7mrgmescc1	Sam Nd.	+237698105748	\N	\N	2026-09-21 08:08:08.598	2026-09-21 08:08:08.598
cmuayqkpv02sx71ke6pqkimde	cmu2kzqeu00055t7mrgmescc1	Sama Joyce	+237653438238	\N	\N	2026-09-21 08:08:08.803	2026-09-21 08:08:08.803
cmuayqkq302sz71kej2w47nke	cmu2kzqeu00055t7mrgmescc1	Sama Joyce	+237653438238	\N	\N	2026-09-21 08:08:08.811	2026-09-21 08:08:08.811
cmuayqkw302t171kejl7pczdq	cmu2kzqeu00055t7mrgmescc1	Samira Andréa ♥️🥰	+237621548318	\N	\N	2026-09-21 08:08:09.027	2026-09-21 08:08:09.027
cmuayqkwf02t371kedn8wl7jr	cmu2kzqeu00055t7mrgmescc1	Samira Andréa ♥️🥰	+237621548318	\N	\N	2026-09-21 08:08:09.04	2026-09-21 08:08:09.04
cmuayql1p02t571ke7b1pemt8	cmu2kzqeu00055t7mrgmescc1	Sammy Akwagoh	+237681489508	\N	\N	2026-09-21 08:08:09.229	2026-09-21 08:08:09.229
cmuayql2302t771kedwmzlk1h	cmu2kzqeu00055t7mrgmescc1	Sammy Akwagoh	+237681489508	\N	\N	2026-09-21 08:08:09.243	2026-09-21 08:08:09.243
cmuayql9202t971kevpepsm1c	cmu2kzqeu00055t7mrgmescc1	Samsung 🤳📱	+237650901358	\N	\N	2026-09-21 08:08:09.495	2026-09-21 08:08:09.495
cmuayql9c02tb71kefx1n397u	cmu2kzqeu00055t7mrgmescc1	Samsung 🤳📱	+237650901358	\N	\N	2026-09-21 08:08:09.504	2026-09-21 08:08:09.504
cmuayqle202td71kem36aotcv	cmu2kzqeu00055t7mrgmescc1	Samuel Dilane	+237680137248	\N	\N	2026-09-21 08:08:09.675	2026-09-21 08:08:09.675
cmuayqlef02tf71ke135fh2vk	cmu2kzqeu00055t7mrgmescc1	Samuel Dilane	+237680137248	\N	\N	2026-09-21 08:08:09.687	2026-09-21 08:08:09.687
cmuayqlq302th71keyocr67kn	cmu2kzqeu00055t7mrgmescc1	Samydko	+237650023050	\N	\N	2026-09-21 08:08:10.107	2026-09-21 08:08:10.107
cmuayqlqa02tj71kem392cqvd	cmu2kzqeu00055t7mrgmescc1	Samydko	+237650023050	\N	\N	2026-09-21 08:08:10.114	2026-09-21 08:08:10.114
cmuayqlvf02tl71ker4pv2muc	cmu2kzqeu00055t7mrgmescc1	Sanchez	+237675390645	\N	\N	2026-09-21 08:08:10.298	2026-09-21 08:08:10.298
cmuayqlvq02tn71kewvur6xaj	cmu2kzqeu00055t7mrgmescc1	Sanchez	+237675390645	\N	\N	2026-09-21 08:08:10.31	2026-09-21 08:08:10.31
cmuayqmju02tp71kejz2ivlsq	cmu2kzqeu00055t7mrgmescc1	Sandy's Shop	+237657586225	\N	\N	2026-09-21 08:08:11.178	2026-09-21 08:08:11.178
cmuayqmk702tr71kex2bzjvh0	cmu2kzqeu00055t7mrgmescc1	Sandy's Shop	+237657586225	\N	\N	2026-09-21 08:08:11.191	2026-09-21 08:08:11.191
cmuayqmqc02tt71kej1mbkrle	cmu2kzqeu00055t7mrgmescc1	Sarah 1	+237676125500	\N	\N	2026-09-21 08:08:11.413	2026-09-21 08:08:11.413
cmuayqmqm02tv71kepm6ynayc	cmu2kzqeu00055t7mrgmescc1	Sarah 1	+237676125500	\N	\N	2026-09-21 08:08:11.423	2026-09-21 08:08:11.423
cmuayqmy202tx71kemd3qyiqv	cmu2kzqeu00055t7mrgmescc1	Sarah Ma Fille ☘️❤️	+237697375980	\N	\N	2026-09-21 08:08:11.69	2026-09-21 08:08:11.69
cmuayqmya02tz71kecrh0lmbx	cmu2kzqeu00055t7mrgmescc1	Sarah Ma Fille ☘️❤️	+237697375980	\N	\N	2026-09-21 08:08:11.698	2026-09-21 08:08:11.698
cmuayqn9l02u171kehyp2tekn	cmu2kzqeu00055t7mrgmescc1	Sarah Nk☘️💯	+237696066091	\N	\N	2026-09-21 08:08:12.105	2026-09-21 08:08:12.105
cmuayqn9t02u371keayt1wwbo	cmu2kzqeu00055t7mrgmescc1	Sarah Nk☘️💯	+237696066091	\N	\N	2026-09-21 08:08:12.113	2026-09-21 08:08:12.113
cmuayqnep02u571kekzt62s6n	cmu2kzqeu00055t7mrgmescc1	Saul~	+237689709291	\N	\N	2026-09-21 08:08:12.289	2026-09-21 08:08:12.289
cmuayqnew02u771ke7bgguipy	cmu2kzqeu00055t7mrgmescc1	Saul~	+237689709291	\N	\N	2026-09-21 08:08:12.297	2026-09-21 08:08:12.297
cmuayqniy02u971kerc3q4o0f	cmu2kzqeu00055t7mrgmescc1	Saurel	+237683684740	\N	\N	2026-09-21 08:08:12.442	2026-09-21 08:08:12.442
cmuayqnj602ub71kexovp4vp5	cmu2kzqeu00055t7mrgmescc1	Saurel	+237683684740	\N	\N	2026-09-21 08:08:12.45	2026-09-21 08:08:12.45
cmuayqno102ud71keg6wmqgrl	cmu2kzqeu00055t7mrgmescc1	Saïda	+237692248179	\N	\N	2026-09-21 08:08:12.625	2026-09-21 08:08:12.625
cmuayqnob02uf71kef5y578i9	cmu2kzqeu00055t7mrgmescc1	Saïda	+237692248179	\N	\N	2026-09-21 08:08:12.636	2026-09-21 08:08:12.636
cmuayqntp02uh71keptmgtas2	cmu2kzqeu00055t7mrgmescc1	Schekina	+237693555872	\N	\N	2026-09-21 08:08:12.829	2026-09-21 08:08:12.829
cmuayqntz02uj71keuvvf0bjp	cmu2kzqeu00055t7mrgmescc1	Schekina	+237693555872	\N	\N	2026-09-21 08:08:12.84	2026-09-21 08:08:12.84
cmuayqo0o02ul71kej7f5o9ow	cmu2kzqeu00055t7mrgmescc1	Scott Old Money💰💰💰	+237652172761	\N	\N	2026-09-21 08:08:13.08	2026-09-21 08:08:13.08
cmuayqo1002un71ket4lb5nx1	cmu2kzqeu00055t7mrgmescc1	Scott Old Money💰💰💰	+237652172761	\N	\N	2026-09-21 08:08:13.092	2026-09-21 08:08:13.092
cmuayqo7i02up71kejlhabkoo	cmu2kzqeu00055t7mrgmescc1	Seraphim	+23770536981	\N	\N	2026-09-21 08:08:13.327	2026-09-21 08:08:13.327
cmuayqo7x02ur71keckforl2t	cmu2kzqeu00055t7mrgmescc1	Seraphim	+23770536981	\N	\N	2026-09-21 08:08:13.341	2026-09-21 08:08:13.341
cmuayqodo02ut71kem2a3b3r8	cmu2kzqeu00055t7mrgmescc1	Serelya 🥰❤️🇮🇳	+22896874621	\N	\N	2026-09-21 08:08:13.548	2026-09-21 08:08:13.548
cmuayqodx02uv71ke4727mxoj	cmu2kzqeu00055t7mrgmescc1	Serelya 🥰❤️🇮🇳	+22896874621	\N	\N	2026-09-21 08:08:13.557	2026-09-21 08:08:13.557
cmuayqoil02ux71ke4l00lyk4	cmu2kzqeu00055t7mrgmescc1	Serena	+237683156674	\N	\N	2026-09-21 08:08:13.725	2026-09-21 08:08:13.725
cmuayqoit02uz71kez2hn489f	cmu2kzqeu00055t7mrgmescc1	Serena	+237683156674	\N	\N	2026-09-21 08:08:13.733	2026-09-21 08:08:13.733
cmuayqonl02v171keirl1lypu	cmu2kzqeu00055t7mrgmescc1	Serena Fille🔥❤️‍🔥	+237690972850	\N	\N	2026-09-21 08:08:13.905	2026-09-21 08:08:13.905
cmuayqons02v371kerr04t9sm	cmu2kzqeu00055t7mrgmescc1	Serena Fille🔥❤️‍🔥	+237690972850	\N	\N	2026-09-21 08:08:13.912	2026-09-21 08:08:13.912
cmuayqotr02v571ked9hgypyi	cmu2kzqeu00055t7mrgmescc1	Sergio Busquets❤️🇦🇷	+2250787088908	\N	\N	2026-09-21 08:08:14.127	2026-09-21 08:08:14.127
cmuayqou202v771kelr2036ia	cmu2kzqeu00055t7mrgmescc1	Sergio Busquets❤️🇦🇷	+2250787088908	\N	\N	2026-09-21 08:08:14.138	2026-09-21 08:08:14.138
cmuayqoz602v971keptax6142	cmu2kzqeu00055t7mrgmescc1	Servixa Hub	+237679127970	\N	\N	2026-09-21 08:08:14.322	2026-09-21 08:08:14.322
cmuayqozd02vb71ke1b0mb203	cmu2kzqeu00055t7mrgmescc1	Servixa Hub	+237679127970	\N	\N	2026-09-21 08:08:14.329	2026-09-21 08:08:14.329
cmuayqp5902vd71kegn4s5bkw	cmu2kzqeu00055t7mrgmescc1	Shanell ❤️❤️	+237671683243	\N	\N	2026-09-21 08:08:14.541	2026-09-21 08:08:14.541
cmuayqp5h02vf71ke6owwc7hl	cmu2kzqeu00055t7mrgmescc1	Shanell ❤️❤️	+237671683243	\N	\N	2026-09-21 08:08:14.55	2026-09-21 08:08:14.55
cmuayqpar02vh71kev9bvboww	cmu2kzqeu00055t7mrgmescc1	Sheney 🛸⚜️	+237657064644	\N	\N	2026-09-21 08:08:14.739	2026-09-21 08:08:14.739
cmuayqpb602vj71kehidbsqf9	cmu2kzqeu00055t7mrgmescc1	Sheney 🛸⚜️	+237657064644	\N	\N	2026-09-21 08:08:14.754	2026-09-21 08:08:14.754
cmuayqpg502vl71kexuiv35ew	cmu2kzqeu00055t7mrgmescc1	Shinichiro zil	+237671592870	\N	\N	2026-09-21 08:08:14.933	2026-09-21 08:08:14.933
cmuayqpge02vn71ketk9zyix6	cmu2kzqeu00055t7mrgmescc1	Shinichiro zil	+237671592870	\N	\N	2026-09-21 08:08:14.942	2026-09-21 08:08:14.942
cmuayqply02vp71kelc460myr	cmu2kzqeu00055t7mrgmescc1	Shirt Guy Ange Raphaël	+237691587208	\N	\N	2026-09-21 08:08:15.142	2026-09-21 08:08:15.142
cmuayqpm502vr71ke3kowktzh	cmu2kzqeu00055t7mrgmescc1	Shirt Guy Ange Raphaël	+237691587208	\N	\N	2026-09-21 08:08:15.149	2026-09-21 08:08:15.149
cmuayqprk02vt71keoyo8w19g	cmu2kzqeu00055t7mrgmescc1	Sįãgå Jõęl🎲🎲🎲🎲	+237698864003	\N	\N	2026-09-21 08:08:15.344	2026-09-21 08:08:15.344
cmuayqprt02vv71ke8ftx9n0y	cmu2kzqeu00055t7mrgmescc1	Sįãgå Jõęl🎲🎲🎲🎲	+237698864003	\N	\N	2026-09-21 08:08:15.353	2026-09-21 08:08:15.353
cmuayqpwt02vx71ke7ura7wf6	cmu2kzqeu00055t7mrgmescc1	Sifried	+237656125104	\N	\N	2026-09-21 08:08:15.534	2026-09-21 08:08:15.534
cmuayqpx102vz71kevj2pm7ct	cmu2kzqeu00055t7mrgmescc1	Sifried	+237656125104	\N	\N	2026-09-21 08:08:15.541	2026-09-21 08:08:15.541
cmuayqq2502w171keejohlzkr	cmu2kzqeu00055t7mrgmescc1	Silas	+237659677496	\N	\N	2026-09-21 08:08:15.725	2026-09-21 08:08:15.725
cmuayqq6602w371ketap85nuw	cmu2kzqeu00055t7mrgmescc1	Silas	+237659677496	\N	\N	2026-09-21 08:08:15.87	2026-09-21 08:08:15.87
cmuayqqfg02w571keyj0w7niw	cmu2kzqeu00055t7mrgmescc1	Singule 😈👿🔥	+237653176803	\N	\N	2026-09-21 08:08:16.204	2026-09-21 08:08:16.204
cmuayqqfm02w771kem2jwsrah	cmu2kzqeu00055t7mrgmescc1	Singule 😈👿🔥	+237653176803	\N	\N	2026-09-21 08:08:16.21	2026-09-21 08:08:16.21
cmuayqql402w971kezi41y21h	cmu2kzqeu00055t7mrgmescc1	Sinota. Notable	+237675503875	\N	\N	2026-09-21 08:08:16.409	2026-09-21 08:08:16.409
cmuayqqle02wb71kekdkhnga3	cmu2kzqeu00055t7mrgmescc1	Sinota. Notable	+237675503875	\N	\N	2026-09-21 08:08:16.418	2026-09-21 08:08:16.418
cmuayqqql02wd71kevv9f3amj	cmu2kzqeu00055t7mrgmescc1	Sir Abdoulaziz	+237656170749	\N	\N	2026-09-21 08:08:16.605	2026-09-21 08:08:16.605
cmuayqqr102wf71kevomj63oa	cmu2kzqeu00055t7mrgmescc1	Sir Abdoulaziz	+237656170749	\N	\N	2026-09-21 08:08:16.621	2026-09-21 08:08:16.621
cmuayqqvt02wh71ke7m0jdlcs	cmu2kzqeu00055t7mrgmescc1	Sir Brian Orange Cameroon	+237699948538	\N	\N	2026-09-21 08:08:16.793	2026-09-21 08:08:16.793
cmuayqqw302wj71kejmeipael	cmu2kzqeu00055t7mrgmescc1	Sir Brian Orange Cameroon	+237699948538	\N	\N	2026-09-21 08:08:16.804	2026-09-21 08:08:16.804
cmuayqr0w02wl71kevrotdn25	cmu2kzqeu00055t7mrgmescc1	Sir Sam	+237681258674	\N	\N	2026-09-21 08:08:16.976	2026-09-21 08:08:16.976
cmuayqr1402wn71ke92wm1y6p	cmu2kzqeu00055t7mrgmescc1	Sir Sam	+237681258674	\N	\N	2026-09-21 08:08:16.984	2026-09-21 08:08:16.984
cmuayqr6r02wp71ke2addxqsk	cmu2kzqeu00055t7mrgmescc1	Sirri 😊❤️🥰	+237673626143	\N	\N	2026-09-21 08:08:17.187	2026-09-21 08:08:17.187
cmuayqr6x02wr71ke1qma4hv6	cmu2kzqeu00055t7mrgmescc1	Sirri 😊❤️🥰	+237673626143	\N	\N	2026-09-21 08:08:17.194	2026-09-21 08:08:17.194
cmuayqrb502wt71ke29ab7eoq	cmu2kzqeu00055t7mrgmescc1	Sis Alice	+237672081633	\N	\N	2026-09-21 08:08:17.345	2026-09-21 08:08:17.345
cmuayqrbf02wv71kebdmsk5bf	cmu2kzqeu00055t7mrgmescc1	Sis Alice	+237672081633	\N	\N	2026-09-21 08:08:17.355	2026-09-21 08:08:17.355
cmuayqrgj02wx71keh4vx0o00	cmu2kzqeu00055t7mrgmescc1	Sis EMMACULATE	+23770241829	\N	\N	2026-09-21 08:08:17.54	2026-09-21 08:08:17.54
cmuayqrgq02wz71kecj4gejmu	cmu2kzqeu00055t7mrgmescc1	Sis EMMACULATE	+23770241829	\N	\N	2026-09-21 08:08:17.547	2026-09-21 08:08:17.547
cmuayqrne02x171ker3xf97tg	cmu2kzqeu00055t7mrgmescc1	Sis Eliss	+237674505331	\N	\N	2026-09-21 08:08:17.787	2026-09-21 08:08:17.787
cmuayqrnm02x371ke3mdhwbh7	cmu2kzqeu00055t7mrgmescc1	Sis Eliss	+237674505331	\N	\N	2026-09-21 08:08:17.794	2026-09-21 08:08:17.794
cmuayqrwz02x571ke5sd533eq	cmu2kzqeu00055t7mrgmescc1	Sis Emelda Wata Yassa	+237673249189	\N	\N	2026-09-21 08:08:18.13	2026-09-21 08:08:18.13
cmuayqry602x771kezeov5geb	cmu2kzqeu00055t7mrgmescc1	Sis Emelda Wata Yassa	+237673249189	\N	\N	2026-09-21 08:08:18.174	2026-09-21 08:08:18.174
cmuayqs3502x971ke7ip0rh9w	cmu2kzqeu00055t7mrgmescc1	Sis Meveail My Helper	+237671206198	\N	\N	2026-09-21 08:08:18.353	2026-09-21 08:08:18.353
cmuayqs3c02xb71ke7vt7c8kr	cmu2kzqeu00055t7mrgmescc1	Sis Meveail My Helper	+237671206198	\N	\N	2026-09-21 08:08:18.36	2026-09-21 08:08:18.36
cmuayqs7x02xd71keih3gzzlr	cmu2kzqeu00055t7mrgmescc1	Sis Pascaline	+23778569204	\N	\N	2026-09-21 08:08:18.525	2026-09-21 08:08:18.525
cmuayqs8902xf71kegz5n83jk	cmu2kzqeu00055t7mrgmescc1	Sis Pascaline	+23778569204	\N	\N	2026-09-21 08:08:18.537	2026-09-21 08:08:18.537
cmuayqsco02xh71keieuf3ncm	cmu2kzqeu00055t7mrgmescc1	Sis Rita	+237674050317	\N	\N	2026-09-21 08:08:18.696	2026-09-21 08:08:18.696
cmuayqscz02xj71kezjip8lrj	cmu2kzqeu00055t7mrgmescc1	Sis Rita	+237674050317	\N	\N	2026-09-21 08:08:18.707	2026-09-21 08:08:18.707
cmuayqsi102xl71keox4bexyn	cmu2kzqeu00055t7mrgmescc1	Sister Naomie Choir Singer	+237682421785	\N	\N	2026-09-21 08:08:18.889	2026-09-21 08:08:18.889
cmuayqsi802xn71ke6fzlxo79	cmu2kzqeu00055t7mrgmescc1	Sister Naomie Choir Singer	+237682421785	\N	\N	2026-09-21 08:08:18.896	2026-09-21 08:08:18.896
cmuayqsmr02xp71keue82mh8x	cmu2kzqeu00055t7mrgmescc1	Sky-B	+237678551034	\N	\N	2026-09-21 08:08:19.059	2026-09-21 08:08:19.059
cmuayqsn102xr71ked4nlwjjo	cmu2kzqeu00055t7mrgmescc1	Sky-B	+237678551034	\N	\N	2026-09-21 08:08:19.069	2026-09-21 08:08:19.069
cmuayqswl02xt71keu5gf6492	cmu2kzqeu00055t7mrgmescc1	Skylla ❤️🥰	+237652835038	\N	\N	2026-09-21 08:08:19.413	2026-09-21 08:08:19.413
cmuayqswu02xv71kektko3f61	cmu2kzqeu00055t7mrgmescc1	Skylla ❤️🥰	+237652835038	\N	\N	2026-09-21 08:08:19.422	2026-09-21 08:08:19.422
cmuayqt1202xx71ke2319jhou	cmu2kzqeu00055t7mrgmescc1	Small Mami	+237677846594	\N	\N	2026-09-21 08:08:19.574	2026-09-21 08:08:19.574
cmuayqt1h02xz71ke4hrnc64z	cmu2kzqeu00055t7mrgmescc1	Small Mami	+237677846594	\N	\N	2026-09-21 08:08:19.59	2026-09-21 08:08:19.59
cmuayqt7402y171ket2fr6g09	cmu2kzqeu00055t7mrgmescc1	Smile Cg	+237674941066	\N	\N	2026-09-21 08:08:19.792	2026-09-21 08:08:19.792
cmuayqt7d02y371ke543h5dw4	cmu2kzqeu00055t7mrgmescc1	Smile Cg	+237674941066	\N	\N	2026-09-21 08:08:19.801	2026-09-21 08:08:19.801
cmuayqtba02y571ket2pndqhs	cmu2kzqeu00055t7mrgmescc1	Soh Talla Erick | BnM	+237690771391	\N	\N	2026-09-21 08:08:19.942	2026-09-21 08:08:19.942
cmuayqtbo02y771ke2ktd69li	cmu2kzqeu00055t7mrgmescc1	Soh Talla Erick | BnM	+237690771391	\N	\N	2026-09-21 08:08:19.956	2026-09-21 08:08:19.956
cmuayqtgo02y971ker17vauzh	cmu2kzqeu00055t7mrgmescc1	Solange😅👌	+237654370788	\N	\N	2026-09-21 08:08:20.136	2026-09-21 08:08:20.136
cmuayqtgv02yb71kewd0zmwri	cmu2kzqeu00055t7mrgmescc1	Solange😅👌	+237654370788	\N	\N	2026-09-21 08:08:20.143	2026-09-21 08:08:20.143
cmuayqtlc02yd71ket55a1o8x	cmu2kzqeu00055t7mrgmescc1	Sonia	+237686186662	\N	\N	2026-09-21 08:08:20.304	2026-09-21 08:08:20.304
cmuayqtlj02yf71ke1dv9rq56	cmu2kzqeu00055t7mrgmescc1	Sonia	+237686186662	\N	\N	2026-09-21 08:08:20.311	2026-09-21 08:08:20.311
cmuayqtqh02yh71ke4j6hsgsc	cmu2kzqeu00055t7mrgmescc1	Star Shopping	+237682478128	\N	\N	2026-09-21 08:08:20.489	2026-09-21 08:08:20.489
cmuayqtqp02yj71kewnd25jm4	cmu2kzqeu00055t7mrgmescc1	Star Shopping	+237682478128	\N	\N	2026-09-21 08:08:20.497	2026-09-21 08:08:20.497
cmuayqtuz02yl71ke7yc9prr5	cmu2kzqeu00055t7mrgmescc1	Stella	+237696020783	\N	\N	2026-09-21 08:08:20.652	2026-09-21 08:08:20.652
cmuayqtv702yn71kenj6200c7	cmu2kzqeu00055t7mrgmescc1	Stella	+237696020783	\N	\N	2026-09-21 08:08:20.659	2026-09-21 08:08:20.659
cmuayqtyx02yp71ke50ct4qy5	cmu2kzqeu00055t7mrgmescc1	Stella	+237672440270	\N	\N	2026-09-21 08:08:20.793	2026-09-21 08:08:20.793
cmuayqtza02yr71kevuqohoh4	cmu2kzqeu00055t7mrgmescc1	Stella	+237672440270	\N	\N	2026-09-21 08:08:20.807	2026-09-21 08:08:20.807
cmuayqu4f02yt71keb6nqdatx	cmu2kzqeu00055t7mrgmescc1	Stephie 🥰	+237683760727	\N	\N	2026-09-21 08:08:20.991	2026-09-21 08:08:20.991
cmuayqu4p02yv71kelulvuavt	cmu2kzqeu00055t7mrgmescc1	Stephie 🥰	+237683760727	\N	\N	2026-09-21 08:08:21.001	2026-09-21 08:08:21.001
cmuayqu8x02yx71ketcs5dats	cmu2kzqeu00055t7mrgmescc1	Stephie 🥰⭐	+237651114868	\N	\N	2026-09-21 08:08:21.153	2026-09-21 08:08:21.153
cmuayqu9402yz71kexmr22gvc	cmu2kzqeu00055t7mrgmescc1	Stephie 🥰⭐	+237651114868	\N	\N	2026-09-21 08:08:21.16	2026-09-21 08:08:21.16
cmuayquf702z171kex3znshhc	cmu2kzqeu00055t7mrgmescc1	Stupéfiant	+237650959149	\N	\N	2026-09-21 08:08:21.379	2026-09-21 08:08:21.379
cmuayqufv02z371ke578rp4bl	cmu2kzqeu00055t7mrgmescc1	Stupéfiant	+237650959149	\N	\N	2026-09-21 08:08:21.403	2026-09-21 08:08:21.403
cmuayqv4k02z571kesvhon21z	cmu2kzqeu00055t7mrgmescc1	Styve F	+237692669358	\N	\N	2026-09-21 08:08:22.293	2026-09-21 08:08:22.293
cmuayqv4u02z771kexgvcsl0z	cmu2kzqeu00055t7mrgmescc1	Styve F	+237692669358	\N	\N	2026-09-21 08:08:22.302	2026-09-21 08:08:22.302
cmuayqv8p02z971keqwiy7niy	cmu2kzqeu00055t7mrgmescc1	Stéphanie	+237671820704	\N	\N	2026-09-21 08:08:22.442	2026-09-21 08:08:22.442
cmuayqv8z02zb71kecb16vfgz	cmu2kzqeu00055t7mrgmescc1	Stéphanie	+237671820704	\N	\N	2026-09-21 08:08:22.451	2026-09-21 08:08:22.451
cmuayqvck02zd71ke1v2lgca6	cmu2kzqeu00055t7mrgmescc1	Stéphanie Dame	+237686249813	\N	\N	2026-09-21 08:08:22.58	2026-09-21 08:08:22.58
cmuayqvcu02zf71kelvpgatdv	cmu2kzqeu00055t7mrgmescc1	Stéphanie Dame	+237686249813	\N	\N	2026-09-21 08:08:22.59	2026-09-21 08:08:22.59
cmuayqvku02zh71ked99zuwle	cmu2kzqeu00055t7mrgmescc1	Stönę Bïõ	+237697505787	\N	\N	2026-09-21 08:08:22.879	2026-09-21 08:08:22.879
cmuayqvl802zj71ke0b12bzh9	cmu2kzqeu00055t7mrgmescc1	Stönę Bïõ	+237697505787	\N	\N	2026-09-21 08:08:22.892	2026-09-21 08:08:22.892
cmuayqvph02zl71kes8p8ot9p	cmu2kzqeu00055t7mrgmescc1	Sweet Mother	+237675852520	\N	\N	2026-09-21 08:08:23.045	2026-09-21 08:08:23.045
cmuayqvpr02zn71kemc7ye169	cmu2kzqeu00055t7mrgmescc1	Sweet Mother	+237675852520	\N	\N	2026-09-21 08:08:23.055	2026-09-21 08:08:23.055
cmuayqvu602zp71keyh7du5pu	cmu2kzqeu00055t7mrgmescc1	Sweet Mother	+237683397115	\N	\N	2026-09-21 08:08:23.214	2026-09-21 08:08:23.214
cmuayqvuf02zr71kefw8drl56	cmu2kzqeu00055t7mrgmescc1	Sweet Mother	+237683397115	\N	\N	2026-09-21 08:08:23.223	2026-09-21 08:08:23.223
cmuayqw2602zt71kewqwgqiaz	cmu2kzqeu00055t7mrgmescc1	Sweet Service	+237670805110	\N	\N	2026-09-21 08:08:23.502	2026-09-21 08:08:23.502
cmuayqw2l02zv71ke5wb8wm1v	cmu2kzqeu00055t7mrgmescc1	Sweet Service	+237670805110	\N	\N	2026-09-21 08:08:23.517	2026-09-21 08:08:23.517
cmuayqw7c02zx71ke01feoa50	cmu2kzqeu00055t7mrgmescc1	Sydo	+237676633726	\N	\N	2026-09-21 08:08:23.688	2026-09-21 08:08:23.688
cmuayqw7j02zz71kesyk8o38x	cmu2kzqeu00055t7mrgmescc1	Sydo	+237676633726	\N	\N	2026-09-21 08:08:23.695	2026-09-21 08:08:23.695
cmuayqwde030171keg9gold1l	cmu2kzqeu00055t7mrgmescc1	Sympa	+237697561064	\N	\N	2026-09-21 08:08:23.906	2026-09-21 08:08:23.906
cmuayqwdn030371kes5r2wgsq	cmu2kzqeu00055t7mrgmescc1	Sympa	+237697561064	\N	\N	2026-09-21 08:08:23.914	2026-09-21 08:08:23.914
cmuayqwi7030571kefkkttx21	cmu2kzqeu00055t7mrgmescc1	Synthia 🥰	+237678930560	\N	\N	2026-09-21 08:08:24.079	2026-09-21 08:08:24.079
cmuayqwih030771kei72w71j5	cmu2kzqeu00055t7mrgmescc1	Synthia 🥰	+237678930560	\N	\N	2026-09-21 08:08:24.089	2026-09-21 08:08:24.089
cmuayqwlv030971kerv6yp5az	cmu2kzqeu00055t7mrgmescc1	TEMOVA Tech	+237620579551	\N	\N	2026-09-21 08:08:24.211	2026-09-21 08:08:24.211
cmuayqwm3030b71keynpan4g4	cmu2kzqeu00055t7mrgmescc1	TEMOVA Tech	+237620579551	\N	\N	2026-09-21 08:08:24.219	2026-09-21 08:08:24.219
cmuayqwqc030d71kep8k0ua3w	cmu2kzqeu00055t7mrgmescc1	THED ALANE✝️🙏🧎🛐	+237698578738	\N	\N	2026-09-21 08:08:24.372	2026-09-21 08:08:24.372
cmuayqwqk030f71keb4qsk5nb	cmu2kzqeu00055t7mrgmescc1	THED ALANE✝️🙏🧎🛐	+237698578738	\N	\N	2026-09-21 08:08:24.379	2026-09-21 08:08:24.379
cmuayqwux030h71kelzuh4d4a	cmu2kzqeu00055t7mrgmescc1	Tadia🦋🖇️🕯️	+263716804086	\N	\N	2026-09-21 08:08:24.537	2026-09-21 08:08:24.537
cmuayqwvd030j71kejp7vsio1	cmu2kzqeu00055t7mrgmescc1	Tadia🦋🖇️🕯️	+263716804086	\N	\N	2026-09-21 08:08:24.554	2026-09-21 08:08:24.554
cmuayqx1f030l71keugylumzp	cmu2kzqeu00055t7mrgmescc1	Talla 🇨🇲	+237695847508	\N	\N	2026-09-21 08:08:24.771	2026-09-21 08:08:24.771
cmuayqx2a030n71kefjw5ahxk	cmu2kzqeu00055t7mrgmescc1	Talla 🇨🇲	+237695847508	\N	\N	2026-09-21 08:08:24.802	2026-09-21 08:08:24.802
cmuayqxf0030p71ke0xk1yiu2	cmu2kzqeu00055t7mrgmescc1	Tatiana	+237699511513	\N	\N	2026-09-21 08:08:25.26	2026-09-21 08:08:25.26
cmuayqxff030r71ketbzv7a5j	cmu2kzqeu00055t7mrgmescc1	Tatiana	+237699511513	\N	\N	2026-09-21 08:08:25.275	2026-09-21 08:08:25.275
cmuayqxo5030t71ke8jfi1ltd	cmu2kzqeu00055t7mrgmescc1	Tatiana Stratège en Ingénierie de la Décision appliquée au Mkg et à la vte	+237656103620	\N	\N	2026-09-21 08:08:25.589	2026-09-21 08:08:25.589
cmuayqxog030v71keuslg7ltj	cmu2kzqeu00055t7mrgmescc1	Tatiana Stratège en Ingénierie de la Décision appliquée au Mkg et à la vte	+237656103620	\N	\N	2026-09-21 08:08:25.6	2026-09-21 08:08:25.6
cmuayqy0c030x71ke3ifxfdpr	cmu2kzqeu00055t7mrgmescc1	Taykun	+237680517411	\N	\N	2026-09-21 08:08:26.028	2026-09-21 08:08:26.028
cmuayqy1j030z71ke1jd04jue	cmu2kzqeu00055t7mrgmescc1	Taykun	+237680517411	\N	\N	2026-09-21 08:08:26.071	2026-09-21 08:08:26.071
cmuayqyl6031171ke4o7kmv5o	cmu2kzqeu00055t7mrgmescc1	Teacher Fuh	+237681449905	\N	\N	2026-09-21 08:08:26.779	2026-09-21 08:08:26.779
cmuayqylu031371kein06glpc	cmu2kzqeu00055t7mrgmescc1	Teacher Fuh	+237681449905	\N	\N	2026-09-21 08:08:26.803	2026-09-21 08:08:26.803
cmuayqz1j031571keuvdkgnr9	cmu2kzqeu00055t7mrgmescc1	Technician	+237694911629	\N	\N	2026-09-21 08:08:27.367	2026-09-21 08:08:27.367
cmuayqz1t031771keajd8brni	cmu2kzqeu00055t7mrgmescc1	Technician	+237694911629	\N	\N	2026-09-21 08:08:27.378	2026-09-21 08:08:27.378
cmuayqz9v031971kegs6vf2ao	cmu2kzqeu00055t7mrgmescc1	Telegram Promoter	+923475038010	\N	\N	2026-09-21 08:08:27.667	2026-09-21 08:08:27.667
cmuayqza1031b71keyf6h6t3e	cmu2kzqeu00055t7mrgmescc1	Telegram Promoter	+923475038010	\N	\N	2026-09-21 08:08:27.674	2026-09-21 08:08:27.674
cmuayqzit031d71ke8ul3hgms	cmu2kzqeu00055t7mrgmescc1	Thanos 🥇🏆🥇🏀⚽️🏈🎾🥇🏆🎖🎖🏅	+237694413876	\N	\N	2026-09-21 08:08:27.99	2026-09-21 08:08:27.99
cmuayqzj2031f71kewdlhyh7p	cmu2kzqeu00055t7mrgmescc1	Thanos 🥇🏆🥇🏀⚽️🏈🎾🥇🏆🎖🎖🏅	+237694413876	\N	\N	2026-09-21 08:08:27.998	2026-09-21 08:08:27.998
cmuayqzpa031h71kegl3awi4l	cmu2kzqeu00055t7mrgmescc1	The Emperor	+237650767289	\N	\N	2026-09-21 08:08:28.222	2026-09-21 08:08:28.222
cmuayqzpi031j71ke18433wus	cmu2kzqeu00055t7mrgmescc1	The Emperor	+237650767289	\N	\N	2026-09-21 08:08:28.23	2026-09-21 08:08:28.23
cmuayr000031l71kec1zumroe	cmu2kzqeu00055t7mrgmescc1	The Fight Real 🇨🇲	+237621795230	\N	\N	2026-09-21 08:08:28.608	2026-09-21 08:08:28.608
cmuayr00j031n71kebajpktxf	cmu2kzqeu00055t7mrgmescc1	The Fight Real 🇨🇲	+237621795230	\N	\N	2026-09-21 08:08:28.627	2026-09-21 08:08:28.627
cmuayr0ec031p71ke99ubu3zm	cmu2kzqeu00055t7mrgmescc1	The Light	+237671103274	\N	\N	2026-09-21 08:08:29.124	2026-09-21 08:08:29.124
cmuayr0en031r71keg8h9g9qn	cmu2kzqeu00055t7mrgmescc1	The Light	+237671103274	\N	\N	2026-09-21 08:08:29.135	2026-09-21 08:08:29.135
cmuayr14q031t71kebbppgu8o	cmu2kzqeu00055t7mrgmescc1	Thelma	+237672577742	\N	\N	2026-09-21 08:08:30.074	2026-09-21 08:08:30.074
cmuayr155031v71keczgtcmmj	cmu2kzqeu00055t7mrgmescc1	Thelma	+237672577742	\N	\N	2026-09-21 08:08:30.089	2026-09-21 08:08:30.089
cmuayr3h4031x71ke62qbcugn	cmu2kzqeu00055t7mrgmescc1	Thomas Robert	+237698963847	\N	\N	2026-09-21 08:08:33.112	2026-09-21 08:08:33.112
cmuayr3km031z71keopy2csav	cmu2kzqeu00055t7mrgmescc1	Thomas Robert	+237698963847	\N	\N	2026-09-21 08:08:33.238	2026-09-21 08:08:33.238
cmuayr77x032171ketwni1em8	cmu2kzqeu00055t7mrgmescc1	Tinechung Na Paradise	+237677512877	\N	\N	2026-09-21 08:08:37.965	2026-09-21 08:08:37.965
cmuayr7ju032371kertq3ekzd	cmu2kzqeu00055t7mrgmescc1	Tinechung Na Paradise	+237677512877	\N	\N	2026-09-21 08:08:38.394	2026-09-21 08:08:38.394
cmuayr9zq032571kejqtz8qer	cmu2kzqeu00055t7mrgmescc1	Toby	+237671515550	\N	\N	2026-09-21 08:08:41.558	2026-09-21 08:08:41.558
cmuayrane032771kebdutk9q8	cmu2kzqeu00055t7mrgmescc1	Toby	+237671515550	\N	\N	2026-09-21 08:08:42.41	2026-09-21 08:08:42.41
cmuayrcbj032971keg59s28cn	cmu2kzqeu00055t7mrgmescc1	Tow Sweet	+2372680052750	\N	\N	2026-09-21 08:08:44.575	2026-09-21 08:08:44.575
cmuayrcn5032b71kepnvv83qc	cmu2kzqeu00055t7mrgmescc1	Tow Sweet	+2372680052750	\N	\N	2026-09-21 08:08:44.993	2026-09-21 08:08:44.993
cmuayreuo032d71kej02xdve0	cmu2kzqeu00055t7mrgmescc1	TraOre🇨🇮ZakAria❤️NinHo🇩🇪91	+2250501679961	\N	\N	2026-09-21 08:08:47.856	2026-09-21 08:08:47.856
cmuayrf07032f71ke97o2vmbq	cmu2kzqeu00055t7mrgmescc1	TraOre🇨🇮ZakAria❤️NinHo🇩🇪91	+2250501679961	\N	\N	2026-09-21 08:08:48.055	2026-09-21 08:08:48.055
cmuayrhzm032h71kewlqrnjq6	cmu2kzqeu00055t7mrgmescc1	Trafiquant Vestimentair	+237657200574	\N	\N	2026-09-21 08:08:51.922	2026-09-21 08:08:51.922
cmuayri1n032j71ke1lio9h9f	cmu2kzqeu00055t7mrgmescc1	Trafiquant Vestimentair	+237657200574	\N	\N	2026-09-21 08:08:51.995	2026-09-21 08:08:51.995
cmuayrj3h032l71keazu79hsv	cmu2kzqeu00055t7mrgmescc1	Tramadol	+237695944839	\N	\N	2026-09-21 08:08:53.357	2026-09-21 08:08:53.357
cmuayrj48032n71keoe39seww	cmu2kzqeu00055t7mrgmescc1	Tramadol	+237695944839	\N	\N	2026-09-21 08:08:53.384	2026-09-21 08:08:53.384
cmuayrjrt032p71kep4mfatxz	cmu2kzqeu00055t7mrgmescc1	Travis	+237696211137	\N	\N	2026-09-21 08:08:54.233	2026-09-21 08:08:54.233
cmuayrjsd032r71ke5z66fzqd	cmu2kzqeu00055t7mrgmescc1	Travis	+237696211137	\N	\N	2026-09-21 08:08:54.253	2026-09-21 08:08:54.253
cmuayrk2x032t71kekdqt76fe	cmu2kzqeu00055t7mrgmescc1	Treasure	+237673693110	\N	\N	2026-09-21 08:08:54.633	2026-09-21 08:08:54.633
cmuayrk38032v71ke6blkq0l7	cmu2kzqeu00055t7mrgmescc1	Treasure	+237673693110	\N	\N	2026-09-21 08:08:54.644	2026-09-21 08:08:54.644
cmuayrkd2032x71kehu82et2s	cmu2kzqeu00055t7mrgmescc1	Treasure 🔥🔥🔥	+237682763664	\N	\N	2026-09-21 08:08:54.998	2026-09-21 08:08:54.998
cmuayrkdm032z71ket8stkbxj	cmu2kzqeu00055t7mrgmescc1	Treasure 🔥🔥🔥	+237682763664	\N	\N	2026-09-21 08:08:55.018	2026-09-21 08:08:55.018
cmuayrkn8033171keaaut4js5	cmu2kzqeu00055t7mrgmescc1	Tresor bilbao⚛️	+237694572821	\N	\N	2026-09-21 08:08:55.364	2026-09-21 08:08:55.364
cmuayrko9033371kejpz8xevo	cmu2kzqeu00055t7mrgmescc1	Tresor bilbao⚛️	+237694572821	\N	\N	2026-09-21 08:08:55.401	2026-09-21 08:08:55.401
cmuayrl9o033571keg9zch15b	cmu2kzqeu00055t7mrgmescc1	Trinahke	+254742246426	\N	\N	2026-09-21 08:08:56.173	2026-09-21 08:08:56.173
cmuayrlal033771kehh69tm36	cmu2kzqeu00055t7mrgmescc1	Trinahke	+254742246426	\N	\N	2026-09-21 08:08:56.205	2026-09-21 08:08:56.205
cmuayrlng033971ke5y2hxgjb	cmu2kzqeu00055t7mrgmescc1	Trésõr Ãlbåtrøs	+237651793836	\N	\N	2026-09-21 08:08:56.668	2026-09-21 08:08:56.668
cmuayrlnr033b71ke47gl4q00	cmu2kzqeu00055t7mrgmescc1	Trésõr Ãlbåtrøs	+237651793836	\N	\N	2026-09-21 08:08:56.679	2026-09-21 08:08:56.679
cmuayrlt4033d71kerlyy19ol	cmu2kzqeu00055t7mrgmescc1	USA	+13014088297	\N	\N	2026-09-21 08:08:56.872	2026-09-21 08:08:56.872
cmuayrltd033f71keqb1xpny9	cmu2kzqeu00055t7mrgmescc1	USA	+13014088297	\N	\N	2026-09-21 08:08:56.881	2026-09-21 08:08:56.881
cmuayrlzi033h71kerb6hqg31	cmu2kzqeu00055t7mrgmescc1	USA1	+13014088295	\N	\N	2026-09-21 08:08:57.103	2026-09-21 08:08:57.103
cmuayrm03033j71kelcrdfil1	cmu2kzqeu00055t7mrgmescc1	USA1	+13014088295	\N	\N	2026-09-21 08:08:57.123	2026-09-21 08:08:57.123
cmuayrm6j033l71kedcqu327h	cmu2kzqeu00055t7mrgmescc1	Ulrich	+237679244433	\N	\N	2026-09-21 08:08:57.355	2026-09-21 08:08:57.355
cmuayrm6u033n71kebnf5th0d	cmu2kzqeu00055t7mrgmescc1	Ulrich	+237679244433	\N	\N	2026-09-21 08:08:57.366	2026-09-21 08:08:57.366
cmuayrmke033p71kesu1xwfoq	cmu2kzqeu00055t7mrgmescc1	Ulrich Bruh 🔥	+237679128832	\N	\N	2026-09-21 08:08:57.854	2026-09-21 08:08:57.854
cmuayrmkt033r71kehshdsbo4	cmu2kzqeu00055t7mrgmescc1	Ulrich Bruh 🔥	+237679128832	\N	\N	2026-09-21 08:08:57.869	2026-09-21 08:08:57.869
cmuayrmsj033t71kebsopxelo	cmu2kzqeu00055t7mrgmescc1	Ulrich Dzokou🦺	+237683671679	\N	\N	2026-09-21 08:08:58.147	2026-09-21 08:08:58.147
cmuayrmsq033v71kerkrokaoo	cmu2kzqeu00055t7mrgmescc1	Ulrich Dzokou🦺	+237683671679	\N	\N	2026-09-21 08:08:58.154	2026-09-21 08:08:58.154
cmuayrn0v033x71keashabhgn	cmu2kzqeu00055t7mrgmescc1	Ulrich😍	+237697810525	\N	\N	2026-09-21 08:08:58.447	2026-09-21 08:08:58.447
cmuayrn2c033z71ketkjvtkab	cmu2kzqeu00055t7mrgmescc1	Ulrich😍	+237697810525	\N	\N	2026-09-21 08:08:58.5	2026-09-21 08:08:58.5
cmuayrn9x034171ke0lr90zo9	cmu2kzqeu00055t7mrgmescc1	University 1	+237693417015	\N	\N	2026-09-21 08:08:58.773	2026-09-21 08:08:58.773
cmuayrna7034371kea9n6mbhs	cmu2kzqeu00055t7mrgmescc1	University 1	+237693417015	\N	\N	2026-09-21 08:08:58.783	2026-09-21 08:08:58.783
cmuayrnev034571ke06zt2yj1	cmu2kzqeu00055t7mrgmescc1	University 2	+237651692398	\N	\N	2026-09-21 08:08:58.951	2026-09-21 08:08:58.951
cmuayrnf4034771ke2buo3rqu	cmu2kzqeu00055t7mrgmescc1	University 2	+237651692398	\N	\N	2026-09-21 08:08:58.96	2026-09-21 08:08:58.96
cmuayrnle034971keeh9t8xc0	cmu2kzqeu00055t7mrgmescc1	Usambi Ken	+18329875253	\N	\N	2026-09-21 08:08:59.186	2026-09-21 08:08:59.186
cmuayrnlv034b71kef3n01qy1	cmu2kzqeu00055t7mrgmescc1	Usambi Ken	+18329875253	\N	\N	2026-09-21 08:08:59.204	2026-09-21 08:08:59.204
cmuayro0l034d71kezwhj3yy1	cmu2kzqeu00055t7mrgmescc1	VOLTAGE🤳🏽	+237654418868	\N	\N	2026-09-21 08:08:59.733	2026-09-21 08:08:59.733
cmuayro15034f71ke80ohvjg7	cmu2kzqeu00055t7mrgmescc1	VOLTAGE🤳🏽	+237654418868	\N	\N	2026-09-21 08:08:59.753	2026-09-21 08:08:59.753
cmuayro5b034h71ke9mmzfax3	cmu2kzqeu00055t7mrgmescc1	Vanessa Basille	+23774931479	\N	\N	2026-09-21 08:08:59.903	2026-09-21 08:08:59.903
cmuayro5j034j71ke9f7xsf0l	cmu2kzqeu00055t7mrgmescc1	Vanessa Basille	+23774931479	\N	\N	2026-09-21 08:08:59.911	2026-09-21 08:08:59.911
cmuayro9z034l71keivrvjk45	cmu2kzqeu00055t7mrgmescc1	Venom	+237671907843	\N	\N	2026-09-21 08:09:00.071	2026-09-21 08:09:00.071
cmuayroa8034n71ke9tajfoqk	cmu2kzqeu00055t7mrgmescc1	Venom	+237671907843	\N	\N	2026-09-21 08:09:00.08	2026-09-21 08:09:00.08
cmuayroek034p71keeu1vk5yh	cmu2kzqeu00055t7mrgmescc1	Vera Ginger	+237681487856	\N	\N	2026-09-21 08:09:00.237	2026-09-21 08:09:00.237
cmuayroet034r71keyb9irp8r	cmu2kzqeu00055t7mrgmescc1	Vera Ginger	+237681487856	\N	\N	2026-09-21 08:09:00.246	2026-09-21 08:09:00.246
cmuayroiu034t71kem3vskud6	cmu2kzqeu00055t7mrgmescc1	Viana Aseli	+237675302953	\N	\N	2026-09-21 08:09:00.39	2026-09-21 08:09:00.39
cmuayroj9034v71ke12uhovc9	cmu2kzqeu00055t7mrgmescc1	Viana Aseli	+237675302953	\N	\N	2026-09-21 08:09:00.405	2026-09-21 08:09:00.405
cmuayromt034x71kefwwukhll	cmu2kzqeu00055t7mrgmescc1	Vicky ❤️🥰	+237692423113	\N	\N	2026-09-21 08:09:00.533	2026-09-21 08:09:00.533
cmuayron1034z71ke4b2szrke	cmu2kzqeu00055t7mrgmescc1	Vicky ❤️🥰	+237692423113	\N	\N	2026-09-21 08:09:00.541	2026-09-21 08:09:00.541
cmuayroql035171kec97t8m08	cmu2kzqeu00055t7mrgmescc1	Victor	+237695140286	\N	\N	2026-09-21 08:09:00.669	2026-09-21 08:09:00.669
cmuayroqr035371kee2u71kui	cmu2kzqeu00055t7mrgmescc1	Victor	+237695140286	\N	\N	2026-09-21 08:09:00.675	2026-09-21 08:09:00.675
cmuayrox5035571keiy9mde32	cmu2kzqeu00055t7mrgmescc1	Vivian Ayendek Ayendek	+19379772411	\N	\N	2026-09-21 08:09:00.905	2026-09-21 16:28:13.572
cmuayroxl035771keemd242h4	cmu2kzqeu00055t7mrgmescc1	Vivian Anyendek	+19379772411	\N	\N	2026-09-21 08:09:00.921	2026-09-21 08:09:00.921
cmuayrpag035971keh92py9pv	cmu2kzqeu00055t7mrgmescc1	WILL ✨	+237691329899	\N	\N	2026-09-21 08:09:01.385	2026-09-21 08:09:01.385
cmuayrpat035b71keuj73cycw	cmu2kzqeu00055t7mrgmescc1	WILL ✨	+237691329899	\N	\N	2026-09-21 08:09:01.397	2026-09-21 08:09:01.397
cmuayrpp9035d71kecohrn41u	cmu2kzqeu00055t7mrgmescc1	WJ🖤	+237695014115	\N	\N	2026-09-21 08:09:01.917	2026-09-21 08:09:01.917
cmuayrppp035f71kez4esqxrg	cmu2kzqeu00055t7mrgmescc1	WJ🖤	+237695014115	\N	\N	2026-09-21 08:09:01.933	2026-09-21 08:09:01.933
cmuayrpx7035h71kegxjbp5tt	cmu2kzqeu00055t7mrgmescc1	Warano	+237621092130	\N	\N	2026-09-21 08:09:02.203	2026-09-21 08:09:02.203
cmuayrpxi035j71ke0562tmia	cmu2kzqeu00055t7mrgmescc1	Warano	+237621092130	\N	\N	2026-09-21 08:09:02.214	2026-09-21 08:09:02.214
cmuayrq3q035l71kedtspoejw	cmu2kzqeu00055t7mrgmescc1	Wassi Edwin	+237674069650	\N	\N	2026-09-21 08:09:02.438	2026-09-21 08:09:02.438
cmuayrq42035n71keslayzcaa	cmu2kzqeu00055t7mrgmescc1	Wassi Edwin	+237674069650	\N	\N	2026-09-21 08:09:02.45	2026-09-21 08:09:02.45
cmuayrtl4035p71ke74u90f26	cmu2kzqeu00055t7mrgmescc1	Wata Fat Yassa	+237678220949	\N	\N	2026-09-21 08:09:06.952	2026-09-21 08:09:06.952
cmuayrtlf035r71keuxlilkjt	cmu2kzqeu00055t7mrgmescc1	Wata Fat Yassa	+237678220949	\N	\N	2026-09-21 08:09:06.963	2026-09-21 08:09:06.963
cmuayrts4035t71kegc24fyp3	cmu2kzqeu00055t7mrgmescc1	Wilfred	+237678584310	\N	\N	2026-09-21 08:09:07.204	2026-09-21 08:09:07.204
cmuayrtsf035v71ke0f18x2j7	cmu2kzqeu00055t7mrgmescc1	Wilfred	+237678584310	\N	\N	2026-09-21 08:09:07.215	2026-09-21 08:09:07.215
cmuayrtyi035x71keorbc8jb9	cmu2kzqeu00055t7mrgmescc1	William🖤🚹	+237699884939	\N	\N	2026-09-21 08:09:07.434	2026-09-21 08:09:07.434
cmuayrtyt035z71keeudbnu0l	cmu2kzqeu00055t7mrgmescc1	William🖤🚹	+237699884939	\N	\N	2026-09-21 08:09:07.445	2026-09-21 08:09:07.445
cmuayrudg036171kel15al0x0	cmu2kzqeu00055t7mrgmescc1	Willyb	+237670334431	\N	\N	2026-09-21 08:09:07.972	2026-09-21 08:09:07.972
cmuayrue5036371ke3hglkwjz	cmu2kzqeu00055t7mrgmescc1	Willyb	+237670334431	\N	\N	2026-09-21 08:09:07.997	2026-09-21 08:09:07.997
cmuayruk9036571keh47m9l78	cmu2kzqeu00055t7mrgmescc1	Wilson New	+237691690982	\N	\N	2026-09-21 08:09:08.217	2026-09-21 08:09:08.217
cmuayrukr036771keq3stnny2	cmu2kzqeu00055t7mrgmescc1	Wilson New	+237691690982	\N	\N	2026-09-21 08:09:08.235	2026-09-21 08:09:08.235
cmuayrurp036971kegv27wxy5	cmu2kzqeu00055t7mrgmescc1	Winnela	+237651528106	\N	\N	2026-09-21 08:09:08.485	2026-09-21 08:09:08.485
cmuayrus2036b71kebbshpyil	cmu2kzqeu00055t7mrgmescc1	Winnela	+237651528106	\N	\N	2026-09-21 08:09:08.498	2026-09-21 08:09:08.498
cmuayrv61036d71keadarxbas	cmu2kzqeu00055t7mrgmescc1	Wrld Young	+237691535782	\N	\N	2026-09-21 08:09:09.001	2026-09-21 08:09:09.001
cmuayrv7c036f71ke4ern6o2q	cmu2kzqeu00055t7mrgmescc1	Wrld Young	+237691535782	\N	\N	2026-09-21 08:09:09.048	2026-09-21 08:09:09.048
cmuayrvx6036h71kej4ujtr8w	cmu2kzqeu00055t7mrgmescc1	XAVI~N	+237695712019	\N	\N	2026-09-21 08:09:09.978	2026-09-21 08:09:09.978
cmuayrvzn036j71kege43ie72	cmu2kzqeu00055t7mrgmescc1	XAVI~N	+237695712019	\N	\N	2026-09-21 08:09:10.067	2026-09-21 08:09:10.067
cmuayrw7j036l71kebphlt5er	cmu2kzqeu00055t7mrgmescc1	YEMINA 🥰	+237657430838	\N	\N	2026-09-21 08:09:10.351	2026-09-21 08:09:10.351
cmuayrw7x036n71keubjbu6j3	cmu2kzqeu00055t7mrgmescc1	YEMINA 🥰	+237657430838	\N	\N	2026-09-21 08:09:10.365	2026-09-21 08:09:10.365
cmuayrwdo036p71ke58ykzxh5	cmu2kzqeu00055t7mrgmescc1	YOU	+23670089004	\N	\N	2026-09-21 08:09:10.573	2026-09-21 08:09:10.573
cmuayrwdz036r71keofbvvyyi	cmu2kzqeu00055t7mrgmescc1	YOU	+23670089004	\N	\N	2026-09-21 08:09:10.583	2026-09-21 08:09:10.583
cmuayrwlr036t71kepil86by0	cmu2kzqeu00055t7mrgmescc1	Yannoush Biama	+2250576822902	\N	\N	2026-09-21 08:09:10.863	2026-09-21 08:09:10.863
cmuayrwm2036v71kefpfsrbda	cmu2kzqeu00055t7mrgmescc1	Yannoush Biama	+2250576822902	\N	\N	2026-09-21 08:09:10.874	2026-09-21 08:09:10.874
cmuayrwuc036x71ke1oa0grsf	cmu2kzqeu00055t7mrgmescc1	Yasmine💫❤️	+237692835583	\N	\N	2026-09-21 08:09:11.173	2026-09-21 08:09:11.173
cmuayrwun036z71kea28pzxyw	cmu2kzqeu00055t7mrgmescc1	Yasmine💫❤️	+237692835583	\N	\N	2026-09-21 08:09:11.183	2026-09-21 08:09:11.183
cmuayrx3g037171kepn6icv49	cmu2kzqeu00055t7mrgmescc1	Yaya	+237652341872	\N	\N	2026-09-21 08:09:11.5	2026-09-21 08:09:11.5
cmuayrx3v037371kewge6nxye	cmu2kzqeu00055t7mrgmescc1	Yaya	+237652341872	\N	\N	2026-09-21 08:09:11.515	2026-09-21 08:09:11.515
cmuayrxb9037571keikc8104n	cmu2kzqeu00055t7mrgmescc1	the Y.NBA	+237676110408	\N	\N	2026-09-21 08:09:11.781	2026-09-21 16:28:18.374
cmuayrxbi037771kerz5u3ssl	cmu2kzqeu00055t7mrgmescc1	Ynba	+237676110408	\N	\N	2026-09-21 08:09:11.791	2026-09-21 08:09:11.791
cmuayrxil037971kenvbbop28	cmu2kzqeu00055t7mrgmescc1	Yolanda Smith	+237655987912	\N	\N	2026-09-21 08:09:12.045	2026-09-21 08:09:12.045
cmuayrxiv037b71kegnedac4c	cmu2kzqeu00055t7mrgmescc1	Yolanda Smith	+237655987912	\N	\N	2026-09-21 08:09:12.056	2026-09-21 08:09:12.056
cmuayrxq7037d71keha7p6sca	cmu2kzqeu00055t7mrgmescc1	Yosimbom ♣️	+237679443906	\N	\N	2026-09-21 08:09:12.319	2026-09-21 08:09:12.319
cmuayrxqk037f71kelu5lsz1a	cmu2kzqeu00055t7mrgmescc1	Yosimbom ♣️	+237679443906	\N	\N	2026-09-21 08:09:12.332	2026-09-21 08:09:12.332
cmuayrxwq037h71kecawbo2lz	cmu2kzqeu00055t7mrgmescc1	Young Deals	+237678047994	\N	\N	2026-09-21 08:09:12.554	2026-09-21 08:09:12.554
cmuayrxx6037j71keoms0jt6x	cmu2kzqeu00055t7mrgmescc1	Young Deals	+237678047994	\N	\N	2026-09-21 08:09:12.57	2026-09-21 08:09:12.57
cmuayry8g037l71kesn66xpl0	cmu2kzqeu00055t7mrgmescc1	Youthup Buea	+237671702205	\N	\N	2026-09-21 08:09:12.976	2026-09-21 08:09:12.976
cmuayry8t037n71kecmggcdii	cmu2kzqeu00055t7mrgmescc1	Youthup Buea	+237671702205	\N	\N	2026-09-21 08:09:12.988	2026-09-21 08:09:12.988
cmuayryp9037p71keyxf058md	cmu2kzqeu00055t7mrgmescc1	Yvan Tatyom	+237699548976	\N	\N	2026-09-21 08:09:13.581	2026-09-21 08:09:13.581
cmuayryq4037r71ke9r1leik1	cmu2kzqeu00055t7mrgmescc1	Yvan Tatyom	+237699548976	\N	\N	2026-09-21 08:09:13.612	2026-09-21 08:09:13.612
cmuayrywb037t71kec1tks55d	cmu2kzqeu00055t7mrgmescc1	Yvana n	+237690841635	\N	\N	2026-09-21 08:09:13.835	2026-09-21 08:09:13.835
cmuayrywn037v71keh5g6whdc	cmu2kzqeu00055t7mrgmescc1	Yvana n	+237690841635	\N	\N	2026-09-21 08:09:13.847	2026-09-21 08:09:13.847
cmuayrza7037x71ke61xx6me6	cmu2kzqeu00055t7mrgmescc1	Yvanna babe	+237688440447	\N	\N	2026-09-21 08:09:14.335	2026-09-21 08:09:14.335
cmuayrzai037z71kexsdh1ca0	cmu2kzqeu00055t7mrgmescc1	Yvanna babe	+237688440447	\N	\N	2026-09-21 08:09:14.347	2026-09-21 08:09:14.347
cmuayrzgx038171ke9vlof6td	cmu2kzqeu00055t7mrgmescc1	‪+23796764603‬	+23796764603	\N	\N	2026-09-21 08:09:14.577	2026-09-21 16:28:19.075
cmuayrzh7038371kegwaik0jn	cmu2kzqeu00055t7mrgmescc1	Yvanna💕🎲🎲🎲	+23796764603	\N	\N	2026-09-21 08:09:14.587	2026-09-21 08:09:14.587
cmuayrzqn038571ke007awpog	cmu2kzqeu00055t7mrgmescc1	Yvies Bae❤️⚠️	+237692429277	\N	\N	2026-09-21 08:09:14.927	2026-09-21 16:28:16.159
cmuayrzr9038771kezaf79cg2	cmu2kzqeu00055t7mrgmescc1	Yvie Orlane ❤️❤️❤️❤️🫶	+237692429277	\N	\N	2026-09-21 08:09:14.949	2026-09-21 08:09:14.949
cmuays00v038971keg4uhiooz	cmu2kzqeu00055t7mrgmescc1	ZNAS LOVE 🥰	+237690128296	\N	\N	2026-09-21 08:09:15.295	2026-09-21 08:09:15.295
cmuays01j038b71kelf57epnz	cmu2kzqeu00055t7mrgmescc1	ZNAS LOVE 🥰	+237690128296	\N	\N	2026-09-21 08:09:15.319	2026-09-21 08:09:15.319
cmuays08v038d71kesrki2w7l	cmu2kzqeu00055t7mrgmescc1	Zamiel Intern	+237678677213	\N	\N	2026-09-21 08:09:15.583	2026-09-21 08:09:15.583
cmuays099038f71kew607kv0l	cmu2kzqeu00055t7mrgmescc1	Zamiel Intern	+237678677213	\N	\N	2026-09-21 08:09:15.597	2026-09-21 08:09:15.597
cmuays0i2038h71kevecz2rfh	cmu2kzqeu00055t7mrgmescc1	Zangi	+2374189325434	\N	\N	2026-09-21 08:09:15.914	2026-09-21 08:09:15.914
cmuays0in038j71kejxw5qtjl	cmu2kzqeu00055t7mrgmescc1	Zangi	+2374189325434	\N	\N	2026-09-21 08:09:15.935	2026-09-21 08:09:15.935
cmuays0yc038l71kesatvi7yf	cmu2kzqeu00055t7mrgmescc1	Zokou-MD	+237658771292	\N	\N	2026-09-21 08:09:16.5	2026-09-21 08:09:16.5
cmuays0yo038n71kef1g3beh2	cmu2kzqeu00055t7mrgmescc1	Zokou-MD	+237658771292	\N	\N	2026-09-21 08:09:16.513	2026-09-21 08:09:16.513
cmuays14t038p71kei3eu8qru	cmu2kzqeu00055t7mrgmescc1	_Mr Charef__4life_%^	+237698706481	\N	\N	2026-09-21 08:09:16.733	2026-09-21 08:09:16.733
cmuays156038r71keott6typi	cmu2kzqeu00055t7mrgmescc1	_Mr Charef__4life_%^	+237698706481	\N	\N	2026-09-21 08:09:16.746	2026-09-21 08:09:16.746
cmuays1aq038t71kegumrxe3z	cmu2kzqeu00055t7mrgmescc1	__SANTANA_WRLD_JAABAD	+2250710640355	\N	\N	2026-09-21 08:09:16.946	2026-09-21 08:09:16.946
cmuays1b1038v71kem66yy8m2	cmu2kzqeu00055t7mrgmescc1	__SANTANA_WRLD_JAABAD	+2250710640355	\N	\N	2026-09-21 08:09:16.958	2026-09-21 08:09:16.958
cmuays1h7038x71kev0ty5xkb	cmu2kzqeu00055t7mrgmescc1	abakwaboy805	+237682723284	\N	\N	2026-09-21 08:09:17.179	2026-09-21 08:09:17.179
cmuays1hh038z71kepv71lpy0	cmu2kzqeu00055t7mrgmescc1	abakwaboy805	+237682723284	\N	\N	2026-09-21 08:09:17.189	2026-09-21 08:09:17.189
cmuays1n9039171kem70tzbkm	cmu2kzqeu00055t7mrgmescc1	acheiromiseundi	+237653917482	\N	\N	2026-09-21 08:09:17.397	2026-09-21 08:09:17.397
cmuays1nn039371keuzp8fr02	cmu2kzqeu00055t7mrgmescc1	acheiromiseundi	+237653917482	\N	\N	2026-09-21 08:09:17.412	2026-09-21 08:09:17.412
cmuays1td039571ke5ljiwrm3	cmu2kzqeu00055t7mrgmescc1	achoitegemmerencia	+237679194911	\N	\N	2026-09-21 08:09:17.617	2026-09-21 08:09:17.617
cmuays1tp039771kec0nrfzp4	cmu2kzqeu00055t7mrgmescc1	achoitegemmerencia	+237679194911	\N	\N	2026-09-21 08:09:17.629	2026-09-21 08:09:17.629
cmuays2jw039971ke372p5ix1	cmu2kzqeu00055t7mrgmescc1	adore	+237678262280	\N	\N	2026-09-21 08:09:18.572	2026-09-21 08:09:18.572
cmuays2k8039b71kef686adnk	cmu2kzqeu00055t7mrgmescc1	adore	+237678262280	\N	\N	2026-09-21 08:09:18.584	2026-09-21 08:09:18.584
cmuays2up039d71kedq5wh83u	cmu2kzqeu00055t7mrgmescc1	adrienne.☘️	+237656728123	\N	\N	2026-09-21 08:09:18.961	2026-09-21 08:09:18.961
cmuays2uy039f71kerav01a3a	cmu2kzqeu00055t7mrgmescc1	adrienne.☘️	+237656728123	\N	\N	2026-09-21 08:09:18.97	2026-09-21 08:09:18.97
cmuays30r039h71ketddxbo5k	cmu2kzqeu00055t7mrgmescc1	aghambamonica	+237677304864	\N	\N	2026-09-21 08:09:19.179	2026-09-21 08:09:19.179
cmuays312039j71kebkc1ge4v	cmu2kzqeu00055t7mrgmescc1	aghambamonica	+237677304864	\N	\N	2026-09-21 08:09:19.19	2026-09-21 08:09:19.19
cmuays36e039l71kev2gsvpkn	cmu2kzqeu00055t7mrgmescc1	andykmr237	+237651911075	\N	\N	2026-09-21 08:09:19.382	2026-09-21 08:09:19.382
cmuays36q039n71kegi3yesww	cmu2kzqeu00055t7mrgmescc1	andykmr237	+237651911075	\N	\N	2026-09-21 08:09:19.394	2026-09-21 08:09:19.394
cmuays3c6039p71ke7dwbuyqn	cmu2kzqeu00055t7mrgmescc1	angabungf	+237654401857	\N	\N	2026-09-21 08:09:19.59	2026-09-21 08:09:19.59
cmuays3cg039r71keoc6vpjh7	cmu2kzqeu00055t7mrgmescc1	angabungf	+237654401857	\N	\N	2026-09-21 08:09:19.6	2026-09-21 08:09:19.6
cmuays3ja039t71keuz0paabo	cmu2kzqeu00055t7mrgmescc1	ogahantoinette7	+24107327697	\N	\N	2026-09-21 08:09:19.846	2026-09-21 16:28:18.193
cmuays3jo039v71keaa5hd6xk	cmu2kzqeu00055t7mrgmescc1	antoinette	+24107327697	\N	\N	2026-09-21 08:09:19.86	2026-09-21 08:09:19.86
cmuays3pt039x71keuga6vyfa	cmu2kzqeu00055t7mrgmescc1	aseliengowi	+237677783949	\N	\N	2026-09-21 08:09:20.081	2026-09-21 08:09:20.081
cmuays3q4039z71kearw14jsw	cmu2kzqeu00055t7mrgmescc1	aseliengowi	+237677783949	\N	\N	2026-09-21 08:09:20.092	2026-09-21 08:09:20.092
cmuays44m03a171kecqucmwvy	cmu2kzqeu00055t7mrgmescc1	athanasetchio237	+237680350540	\N	\N	2026-09-21 08:09:20.614	2026-09-21 08:09:20.614
cmuays44x03a371kenigwbcjh	cmu2kzqeu00055t7mrgmescc1	athanasetchio237	+237680350540	\N	\N	2026-09-21 08:09:20.625	2026-09-21 08:09:20.625
cmuays4qb03a571keloq1bp6m	cmu2kzqeu00055t7mrgmescc1	betrandberaz4	+237673531252	\N	\N	2026-09-21 08:09:21.396	2026-09-21 08:09:21.396
cmuays4qm03a771kezxcj1rsk	cmu2kzqeu00055t7mrgmescc1	betrandberaz4	+237673531252	\N	\N	2026-09-21 08:09:21.406	2026-09-21 08:09:21.406
cmuays4wt03a971kej6ge831j	cmu2kzqeu00055t7mrgmescc1	blanche	+237676626359	\N	\N	2026-09-21 08:09:21.629	2026-09-21 08:09:21.629
cmuays4x803ab71keljqk9wbj	cmu2kzqeu00055t7mrgmescc1	blanche	+237676626359	\N	\N	2026-09-21 08:09:21.644	2026-09-21 08:09:21.644
cmuays5aa03ad71kexqs3ne7v	cmu2kzqeu00055t7mrgmescc1	buriyamarceline481	+237672805477	\N	\N	2026-09-21 08:09:22.114	2026-09-21 08:09:22.114
cmuays5am03af71kebfzp4try	cmu2kzqeu00055t7mrgmescc1	buriyamarceline481	+237672805477	\N	\N	2026-09-21 08:09:22.126	2026-09-21 08:09:22.126
cmuays5gr03ah71ke61gqs7lb	cmu2kzqeu00055t7mrgmescc1	carelle	+237679148076	\N	\N	2026-09-21 08:09:22.347	2026-09-21 08:09:22.347
cmuays5h103aj71ke179jedh0	cmu2kzqeu00055t7mrgmescc1	carelle	+237679148076	\N	\N	2026-09-21 08:09:22.357	2026-09-21 08:09:22.357
cmuays5nb03al71ke9f4v35wy	cmu2kzqeu00055t7mrgmescc1	champiredollar	+237682457322	\N	\N	2026-09-21 08:09:22.583	2026-09-21 08:09:22.583
cmuays5np03an71ke13yqtb0g	cmu2kzqeu00055t7mrgmescc1	champiredollar	+237682457322	\N	\N	2026-09-21 08:09:22.597	2026-09-21 08:09:22.597
cmuays5ua03ap71ke21zo6mlb	cmu2kzqeu00055t7mrgmescc1	chanel	+237692553600	\N	\N	2026-09-21 08:09:22.834	2026-09-21 08:09:22.834
cmuays5uk03ar71kevnxoamgo	cmu2kzqeu00055t7mrgmescc1	chanel	+237692553600	\N	\N	2026-09-21 08:09:22.844	2026-09-21 08:09:22.844
cmuays6fk03at71ke47atn034	cmu2kzqeu00055t7mrgmescc1	christiantamaf	+237690554569	\N	\N	2026-09-21 08:09:23.6	2026-09-21 08:09:23.6
cmuays6fz03av71ke5bqrmegh	cmu2kzqeu00055t7mrgmescc1	christiantamaf	+237690554569	\N	\N	2026-09-21 08:09:23.615	2026-09-21 08:09:23.615
cmuays6ot03ax71kex9qtqot1	cmu2kzqeu00055t7mrgmescc1	christopherachonduh	+237674160197	\N	\N	2026-09-21 08:09:23.933	2026-09-21 08:09:23.933
cmuays6p603az71ke3eaviyd8	cmu2kzqeu00055t7mrgmescc1	christopherachonduh	+237674160197	\N	\N	2026-09-21 08:09:23.946	2026-09-21 08:09:23.946
cmuays6vu03b171keemomlzru	cmu2kzqeu00055t7mrgmescc1	christson1307	+237683555422	\N	\N	2026-09-21 08:09:24.186	2026-09-21 08:09:24.186
cmuays6w603b371ke4ujt9qc3	cmu2kzqeu00055t7mrgmescc1	christson1307	+237683555422	\N	\N	2026-09-21 08:09:24.198	2026-09-21 08:09:24.198
cmuays73z03b571key6ooqwy6	cmu2kzqeu00055t7mrgmescc1	constancemanli695	+237675417413	\N	\N	2026-09-21 08:09:24.479	2026-09-21 08:09:24.479
cmuays74903b771ke4e4ulvc9	cmu2kzqeu00055t7mrgmescc1	constancemanli695	+237675417413	\N	\N	2026-09-21 08:09:24.489	2026-09-21 08:09:24.489
cmuays7bf03b971ket2xhv32b	cmu2kzqeu00055t7mrgmescc1	daniel	+2349130369682	\N	\N	2026-09-21 08:09:24.747	2026-09-21 08:09:24.747
cmuays7bq03bb71kemym4aww9	cmu2kzqeu00055t7mrgmescc1	daniel	+2349130369682	\N	\N	2026-09-21 08:09:24.758	2026-09-21 08:09:24.758
cmuays7j803bd71kehmfy2v3j	cmu2kzqeu00055t7mrgmescc1	darell	+237621123582	\N	\N	2026-09-21 08:09:25.028	2026-09-21 08:09:25.028
cmuays7jj03bf71ke1bp4sftd	cmu2kzqeu00055t7mrgmescc1	darell	+237621123582	\N	\N	2026-09-21 08:09:25.039	2026-09-21 08:09:25.039
cmuays7zk03bh71keu82ipmcx	cmu2kzqeu00055t7mrgmescc1	darelldrec	+237689899145	\N	\N	2026-09-21 08:09:25.616	2026-09-21 08:09:25.616
cmuays80i03bj71kejvu3xru5	cmu2kzqeu00055t7mrgmescc1	darelldrec	+237689899145	\N	\N	2026-09-21 08:09:25.65	2026-09-21 08:09:25.65
cmuays87e03bl71ke9c17u61j	cmu2kzqeu00055t7mrgmescc1	dayou Kendra	+237697137828	\N	\N	2026-09-21 08:09:25.898	2026-09-21 08:09:25.898
cmuays87r03bn71keww22i777	cmu2kzqeu00055t7mrgmescc1	dayou Kendra	+237697137828	\N	\N	2026-09-21 08:09:25.911	2026-09-21 08:09:25.911
cmuays8es03bp71kesnlk88gx	cmu2kzqeu00055t7mrgmescc1	ekaimbakwa	+237677147475	\N	\N	2026-09-21 08:09:26.164	2026-09-21 08:09:26.164
cmuays8f803br71kerxmij0r4	cmu2kzqeu00055t7mrgmescc1	ekaimbakwa	+237677147475	\N	\N	2026-09-21 08:09:26.18	2026-09-21 08:09:26.18
cmuays8qb03bt71kecdkddv8l	cmu2kzqeu00055t7mrgmescc1	engwoibaalbertina	+23750421627	\N	\N	2026-09-21 08:09:26.579	2026-09-21 08:09:26.579
cmuays8qr03bv71kefh4pmb15	cmu2kzqeu00055t7mrgmescc1	engwoibaalbertina	+23750421627	\N	\N	2026-09-21 08:09:26.595	2026-09-21 08:09:26.595
cmuays8xc03bx71keltfbi71e	cmu2kzqeu00055t7mrgmescc1	esthereballe80	+237653982712	\N	\N	2026-09-21 08:09:26.832	2026-09-21 08:09:26.832
cmuays8y203bz71kehjby1x01	cmu2kzqeu00055t7mrgmescc1	esthereballe80	+237653982712	\N	\N	2026-09-21 08:09:26.858	2026-09-21 08:09:26.858
cmuays94m03c171kegw86t2s6	cmu2kzqeu00055t7mrgmescc1	eunicenyambi12 Eru	+237676218706	\N	\N	2026-09-21 08:09:27.094	2026-09-21 08:09:27.094
cmuays94z03c371ke1uj571xq	cmu2kzqeu00055t7mrgmescc1	eunicenyambi12 Eru	+237676218706	\N	\N	2026-09-21 08:09:27.107	2026-09-21 08:09:27.107
cmuays9br03c571keqrzy9216	cmu2kzqeu00055t7mrgmescc1	eyasarosita6	+237680155129	\N	\N	2026-09-21 08:09:27.351	2026-09-21 08:09:27.351
cmuays9c303c771keh3j60vxx	cmu2kzqeu00055t7mrgmescc1	eyasarosita6	+237680155129	\N	\N	2026-09-21 08:09:27.363	2026-09-21 08:09:27.363
cmuays9ju03c971kevv9bgd9d	cmu2kzqeu00055t7mrgmescc1	fochoangeline@gmail.com Mami Blee	+237675899433	\N	\N	2026-09-21 08:09:27.642	2026-09-21 08:09:27.642
cmuays9ka03cb71kemo03sxot	cmu2kzqeu00055t7mrgmescc1	fochoangeline@gmail.com Mami Blee	+237675899433	\N	\N	2026-09-21 08:09:27.658	2026-09-21 08:09:27.658
cmuaysajm03cd71keckqzg6vq	cmu2kzqeu00055t7mrgmescc1	fokoujoelmartiny	+237680146857	\N	\N	2026-09-21 08:09:28.93	2026-09-21 08:09:28.93
cmuaysand03cf71ke8k6r3ut7	cmu2kzqeu00055t7mrgmescc1	fokoujoelmartiny	+237680146857	\N	\N	2026-09-21 08:09:29.065	2026-09-21 08:09:29.065
cmuaysdut03ch71kecsu3fb4i	cmu2kzqeu00055t7mrgmescc1	grâce	+237686574715	\N	\N	2026-09-21 08:09:33.218	2026-09-21 08:09:33.218
cmuaysems03cj71ke2t43rtj5	cmu2kzqeu00055t7mrgmescc1	grâce	+237686574715	\N	\N	2026-09-21 08:09:34.228	2026-09-21 08:09:34.228
cmuaysj6403cl71ke482rkmpl	cmu2kzqeu00055t7mrgmescc1	himra la Machete 1x	+22676047991	\N	\N	2026-09-21 08:09:40.108	2026-09-21 08:09:40.108
cmuaysjm003cn71keydf9zcqp	cmu2kzqeu00055t7mrgmescc1	himra la Machete 1x	+22676047991	\N	\N	2026-09-21 08:09:40.68	2026-09-21 08:09:40.68
cmuaysl8u03cp71keht5g1iqb	cmu2kzqeu00055t7mrgmescc1	honorineakefack Ma Ono	+237653163475	\N	\N	2026-09-21 08:09:42.798	2026-09-21 08:09:42.798
cmuayslbo03cr71keqpbo2jqk	cmu2kzqeu00055t7mrgmescc1	honorineakefack Ma Ono	+237653163475	\N	\N	2026-09-21 08:09:42.9	2026-09-21 08:09:42.9
cmuayslpu03ct71keteouipnl	cmu2kzqeu00055t7mrgmescc1	ifugenumwicliff	+237673688163	\N	\N	2026-09-21 08:09:43.41	2026-09-21 08:09:43.41
cmuaysm1q03cv71keplt05242	cmu2kzqeu00055t7mrgmescc1	ifugenumwicliff	+237673688163	\N	\N	2026-09-21 08:09:43.838	2026-09-21 08:09:43.838
cmuaysmfe03cx71kex7s1vvr7	cmu2kzqeu00055t7mrgmescc1	iramkanoudieunedorking	+237670667813	\N	\N	2026-09-21 08:09:44.331	2026-09-21 08:09:44.331
cmuaysmgk03cz71ket8ghyhhg	cmu2kzqeu00055t7mrgmescc1	iramkanoudieunedorking	+237670667813	\N	\N	2026-09-21 08:09:44.372	2026-09-21 08:09:44.372
cmuaysmrw03d171kelt662vo9	cmu2kzqeu00055t7mrgmescc1	irisse ☘️🌊	+237694328769	\N	\N	2026-09-21 08:09:44.78	2026-09-21 08:09:44.78
cmuaysmt103d371ke8eos5plf	cmu2kzqeu00055t7mrgmescc1	irisse ☘️🌊	+237694328769	\N	\N	2026-09-21 08:09:44.821	2026-09-21 08:09:44.821
cmuaysn3k03d571kerwu9orne	cmu2kzqeu00055t7mrgmescc1	jacksonubeneku	+237679366534	\N	\N	2026-09-21 08:09:45.201	2026-09-21 08:09:45.201
cmuaysn4n03d771ke5alfpbxq	cmu2kzqeu00055t7mrgmescc1	jacksonubeneku	+237679366534	\N	\N	2026-09-21 08:09:45.24	2026-09-21 08:09:45.24
cmuaysnrn03d971ke5zcgjwol	cmu2kzqeu00055t7mrgmescc1	jacobachonduh	+237672906819	\N	\N	2026-09-21 08:09:46.066	2026-09-21 08:09:46.066
cmuaysnsp03db71kej4t6usct	cmu2kzqeu00055t7mrgmescc1	jacobachonduh	+237672906819	\N	\N	2026-09-21 08:09:46.105	2026-09-21 08:09:46.105
cmuayso2p03dd71kervte2o1a	cmu2kzqeu00055t7mrgmescc1	junior kamanda🇨🇲	+237695614443	\N	\N	2026-09-21 08:09:46.465	2026-09-21 08:09:46.465
cmuayso3z03df71kedx7hdxo0	cmu2kzqeu00055t7mrgmescc1	junior kamanda🇨🇲	+237695614443	\N	\N	2026-09-21 08:09:46.512	2026-09-21 08:09:46.512
cmuaysoei03dh71kelina4ydi	cmu2kzqeu00055t7mrgmescc1	keng Irene Anna	+237679362240	\N	\N	2026-09-21 08:09:46.89	2026-09-21 08:09:46.89
cmuaysofe03dj71kenk5c5mc8	cmu2kzqeu00055t7mrgmescc1	keng Irene Anna	+237679362240	\N	\N	2026-09-21 08:09:46.922	2026-09-21 08:09:46.922
cmuaysoql03dl71keyhlwxa5e	cmu2kzqeu00055t7mrgmescc1	lillianamichoh	+23777517092	\N	\N	2026-09-21 08:09:47.325	2026-09-21 08:09:47.325
cmuaysorp03dn71ke5ym708am	cmu2kzqeu00055t7mrgmescc1	lillianamichoh	+23777517092	\N	\N	2026-09-21 08:09:47.365	2026-09-21 08:09:47.365
cmuaysp1m03dp71kedhlhtbx4	cmu2kzqeu00055t7mrgmescc1	marius Bro	+237659817308	\N	\N	2026-09-21 08:09:47.723	2026-09-21 08:09:47.723
cmuaysp2q03dr71kefk039q8k	cmu2kzqeu00055t7mrgmescc1	marius Bro	+237659817308	\N	\N	2026-09-21 08:09:47.763	2026-09-21 08:09:47.763
cmuayspef03dt71kezx9k9h28	cmu2kzqeu00055t7mrgmescc1	maéva🍀	+237697645640	\N	\N	2026-09-21 08:09:48.183	2026-09-21 08:09:48.183
cmuayspfm03dv71keq2dkjyc1	cmu2kzqeu00055t7mrgmescc1	maéva🍀	+237697645640	\N	\N	2026-09-21 08:09:48.226	2026-09-21 08:09:48.226
cmuayspre03dx71ke1lytkld6	cmu2kzqeu00055t7mrgmescc1	mbkarisma2	+237672664005	\N	\N	2026-09-21 08:09:48.65	2026-09-21 08:09:48.65
cmuayspsi03dz71kei933i9qw	cmu2kzqeu00055t7mrgmescc1	mbkarisma2	+237672664005	\N	\N	2026-09-21 08:09:48.69	2026-09-21 08:09:48.69
cmuaysq2u03e171kermhd35bh	cmu2kzqeu00055t7mrgmescc1	medjeuwalrivaldese	+237681725931	\N	\N	2026-09-21 08:09:49.062	2026-09-21 08:09:49.062
cmuaysq4m03e371ke984qrlm1	cmu2kzqeu00055t7mrgmescc1	medjeuwalrivaldese	+237681725931	\N	\N	2026-09-21 08:09:49.126	2026-09-21 08:09:49.126
cmuaysqhf03e571ke3m85l9qk	cmu2kzqeu00055t7mrgmescc1	merveille 😇😍LaFortune 🥰💳😘	+237652344944	\N	\N	2026-09-21 08:09:49.587	2026-09-21 08:09:49.587
cmuaysqil03e771kelyv1dlxc	cmu2kzqeu00055t7mrgmescc1	merveille 😇😍LaFortune 🥰💳😘	+237652344944	\N	\N	2026-09-21 08:09:49.629	2026-09-21 08:09:49.629
cmuayssiu03e971ke0j8pn5uo	cmu2kzqeu00055t7mrgmescc1	mery Nassarwa	+23708035800279	\N	\N	2026-09-21 08:09:52.23	2026-09-21 08:09:52.23
cmuayssl303eb71keayywqfaj	cmu2kzqeu00055t7mrgmescc1	mery Nassarwa	+23708035800279	\N	\N	2026-09-21 08:09:52.311	2026-09-21 08:09:52.311
cmuayst0e03ed71ke0t1dv3ja	cmu2kzqeu00055t7mrgmescc1	mhidey	+2348127994625	\N	\N	2026-09-21 08:09:52.863	2026-09-21 08:09:52.863
cmuayst2603ef71ke9hrw0vyt	cmu2kzqeu00055t7mrgmescc1	mhidey	+2348127994625	\N	\N	2026-09-21 08:09:52.926	2026-09-21 08:09:52.926
cmuaystv903eh71kegy9u516d	cmu2kzqeu00055t7mrgmescc1	mkfrederickarthur	+237672097086	\N	\N	2026-09-21 08:09:53.973	2026-09-21 08:09:53.973
cmuaystym03ej71keghzl4t4x	cmu2kzqeu00055t7mrgmescc1	mkfrederickarthur	+237672097086	\N	\N	2026-09-21 08:09:54.094	2026-09-21 08:09:54.094
cmuaysu9f03el71kec0r99vhe	cmu2kzqeu00055t7mrgmescc1	moi orange	+237690535743	\N	\N	2026-09-21 08:09:54.483	2026-09-21 08:09:54.483
cmuaysuaq03en71keigmm6xlm	cmu2kzqeu00055t7mrgmescc1	moi orange	+237690535743	\N	\N	2026-09-21 08:09:54.53	2026-09-21 08:09:54.53
cmuaysukf03ep71kecapb3lat	cmu2kzqeu00055t7mrgmescc1	ngadjeumicheline	+237655849505	\N	\N	2026-09-21 08:09:54.879	2026-09-21 08:09:54.879
cmuaysum003er71kexdsjhpg8	cmu2kzqeu00055t7mrgmescc1	ngadjeumicheline	+237655849505	\N	\N	2026-09-21 08:09:54.936	2026-09-21 08:09:54.936
cmuaysuv503et71ke6aukmaa9	cmu2kzqeu00055t7mrgmescc1	nkemnkenggillian@gmail co	+23776553414	\N	\N	2026-09-21 08:09:55.265	2026-09-21 08:09:55.265
cmuaysv5n03ev71keyai5zuiz	cmu2kzqeu00055t7mrgmescc1	nkemnkenggillian@gmail co	+23776553414	\N	\N	2026-09-21 08:09:55.643	2026-09-21 08:09:55.643
cmuaysvta03ex71kee5g98znv	cmu2kzqeu00055t7mrgmescc1	serge	+22945547933	\N	\N	2026-09-21 08:09:56.494	2026-09-21 08:09:56.494
cmuaysvu203ez71ke5asq171k	cmu2kzqeu00055t7mrgmescc1	serge	+22945547933	\N	\N	2026-09-21 08:09:56.522	2026-09-21 08:09:56.522
cmuaysw4v03f171ke2luihxxf	cmu2kzqeu00055t7mrgmescc1	stainlesscharming7	+237682447053	\N	\N	2026-09-21 08:09:56.91	2026-09-21 08:09:56.91
cmuaysw6603f371keyv5zyj02	cmu2kzqeu00055t7mrgmescc1	stainlesscharming7	+237682447053	\N	\N	2026-09-21 08:09:56.958	2026-09-21 08:09:56.958
cmuayswo303f571kerw3zdl8t	cmu2kzqeu00055t7mrgmescc1	the Ynba	+237688830987	\N	\N	2026-09-21 08:09:57.603	2026-09-21 08:09:57.603
cmuayswoz03f771ke0nlv30zp	cmu2kzqeu00055t7mrgmescc1	the Ynba	+237688830987	\N	\N	2026-09-21 08:09:57.635	2026-09-21 08:09:57.635
cmuaysx4003f971kejim3xyje	cmu2kzqeu00055t7mrgmescc1	usateangela@gmail com	+237675265881	\N	\N	2026-09-21 08:09:58.176	2026-09-21 08:09:58.176
cmuaysx4w03fb71keft38wn8y	cmu2kzqeu00055t7mrgmescc1	usateangela@gmail com	+237675265881	\N	\N	2026-09-21 08:09:58.208	2026-09-21 08:09:58.208
cmuaysxf103fd71kefzhom9rh	cmu2kzqeu00055t7mrgmescc1	vannesaabanda	+237676664119	\N	\N	2026-09-21 08:09:58.572	2026-09-21 08:09:58.572
cmuaysxfo03ff71ke1ggbg6y3	cmu2kzqeu00055t7mrgmescc1	vannesaabanda	+237676664119	\N	\N	2026-09-21 08:09:58.596	2026-09-21 08:09:58.596
cmuaysxpq03fh71ke505g4dob	cmu2kzqeu00055t7mrgmescc1	wandjikelly3	+237678750339	\N	\N	2026-09-21 08:09:58.958	2026-09-21 08:09:58.958
cmuaysxqk03fj71kepyq15vy4	cmu2kzqeu00055t7mrgmescc1	wandjikelly3	+237678750339	\N	\N	2026-09-21 08:09:58.988	2026-09-21 08:09:58.988
cmuaysybz03fl71ke65elyd3w	cmu2kzqeu00055t7mrgmescc1	wilfredtimchou8	+237671193660	\N	\N	2026-09-21 08:09:59.759	2026-09-21 08:09:59.759
cmuaysyev03fn71kezh97ovag	cmu2kzqeu00055t7mrgmescc1	wilfredtimchou8	+237671193660	\N	\N	2026-09-21 08:09:59.863	2026-09-21 08:09:59.863
cmuaysz4j03fp71kefowikkcr	cmu2kzqeu00055t7mrgmescc1	willy	+237678661478	\N	\N	2026-09-21 08:10:00.787	2026-09-21 08:10:00.787
cmuaysz5803fr71keu3xank8a	cmu2kzqeu00055t7mrgmescc1	willy	+237678661478	\N	\N	2026-09-21 08:10:00.812	2026-09-21 08:10:00.812
cmuayszg903ft71kejpvepf3d	cmu2kzqeu00055t7mrgmescc1	~.Sky	+447848799877	\N	\N	2026-09-21 08:10:01.209	2026-09-21 08:10:01.209
cmuayszgw03fv71kecq2z74zp	cmu2kzqeu00055t7mrgmescc1	~.Sky	+447848799877	\N	\N	2026-09-21 08:10:01.232	2026-09-21 08:10:01.232
cmuayszqq03fx71ke9dpy0lvz	cmu2kzqeu00055t7mrgmescc1	~Annurh Lelouch	+237658472540	\N	\N	2026-09-21 08:10:01.586	2026-09-21 08:10:01.586
cmuayszre03fz71kejvy8j1yk	cmu2kzqeu00055t7mrgmescc1	~Annurh Lelouch	+237658472540	\N	\N	2026-09-21 08:10:01.61	2026-09-21 08:10:01.61
cmuayt01m03g171keuwat43gd	cmu2kzqeu00055t7mrgmescc1	~Conseil Jos 2.0~	+237652185822	\N	\N	2026-09-21 08:10:01.978	2026-09-21 08:10:01.978
cmuayt02d03g371keg93jubtd	cmu2kzqeu00055t7mrgmescc1	~Conseil Jos 2.0~	+237652185822	\N	\N	2026-09-21 08:10:02.005	2026-09-21 08:10:02.005
cmuayt12y03g571kewqrblruu	cmu2kzqeu00055t7mrgmescc1	~La_crime~(⁠*⁠_⁠*⁠)...🥷	+22770706277	\N	\N	2026-09-21 08:10:03.322	2026-09-21 08:10:03.322
cmuayt13l03g771kep9vhpb2m	cmu2kzqeu00055t7mrgmescc1	~La_crime~(⁠*⁠_⁠*⁠)...🥷	+22770706277	\N	\N	2026-09-21 08:10:03.345	2026-09-21 08:10:03.345
cmuayt1od03g971kec3aj0w7l	cmu2kzqeu00055t7mrgmescc1	~Lumiere☯️🤍🎧	+237655721610	\N	\N	2026-09-21 08:10:04.093	2026-09-21 08:10:04.093
cmuayt1oy03gb71kelfsnb19q	cmu2kzqeu00055t7mrgmescc1	~Lumiere☯️🤍🎧	+237655721610	\N	\N	2026-09-21 08:10:04.114	2026-09-21 08:10:04.114
cmuayt2t403gd71kemwcvjokr	cmu2kzqeu00055t7mrgmescc1	~Maéva	+237694066738	\N	\N	2026-09-21 08:10:05.56	2026-09-21 08:10:05.56
cmuayt2tx03gf71keeu7j8vwx	cmu2kzqeu00055t7mrgmescc1	~Maéva	+237694066738	\N	\N	2026-09-21 08:10:05.589	2026-09-21 08:10:05.589
cmuayt3a803gh71kewxfqv8jp	cmu2kzqeu00055t7mrgmescc1	~The Perfectionist	+237676489324	\N	\N	2026-09-21 08:10:06.176	2026-09-21 08:10:06.176
cmuayt3b303gj71kelt8jpiiu	cmu2kzqeu00055t7mrgmescc1	~The Perfectionist	+237676489324	\N	\N	2026-09-21 08:10:06.207	2026-09-21 08:10:06.207
cmuayt3lw03gl71ke8sznv7l0	cmu2kzqeu00055t7mrgmescc1	~Tvj	+22890716764	\N	\N	2026-09-21 08:10:06.596	2026-09-21 08:10:06.596
cmuayt3na03gn71kegqvlig9w	cmu2kzqeu00055t7mrgmescc1	~Tvj	+22890716764	\N	\N	2026-09-21 08:10:06.646	2026-09-21 08:10:06.646
cmuayt3z003gp71kehlixjg99	cmu2kzqeu00055t7mrgmescc1	~claire~💜	+237692651448	\N	\N	2026-09-21 08:10:07.067	2026-09-21 08:10:07.067
cmuayt40303gr71kemlq0nc81	cmu2kzqeu00055t7mrgmescc1	~claire~💜	+237692651448	\N	\N	2026-09-21 08:10:07.107	2026-09-21 08:10:07.107
cmuayt4e503gt71kebco4gy19	cmu2kzqeu00055t7mrgmescc1	Àññà	+237679528511	\N	\N	2026-09-21 08:10:07.613	2026-09-21 08:10:07.613
cmuayt4fl03gv71kez8mvagka	cmu2kzqeu00055t7mrgmescc1	Àññà	+237679528511	\N	\N	2026-09-21 08:10:07.665	2026-09-21 08:10:07.665
cmuayt4tc03gx71kegbu31hzv	cmu2kzqeu00055t7mrgmescc1	Émile	+237651763600	\N	\N	2026-09-21 08:10:08.161	2026-09-21 08:10:08.161
cmuayt4u403gz71keheqglwib	cmu2kzqeu00055t7mrgmescc1	Émile	+237651763600	\N	\N	2026-09-21 08:10:08.189	2026-09-21 08:10:08.189
cmuazao3i0001ua9ve1jfxgry	cmu2kzqeu00055t7mrgmescc1	Éric Cantona €$	+237655897524	\N	\N	2026-09-21 08:23:46.301	2026-09-21 08:23:46.301
cmuazao6l0003ua9vhb6t04mp	cmu2kzqeu00055t7mrgmescc1	ĂÎ	+2348082340588	\N	\N	2026-09-21 08:23:46.413	2026-09-21 08:23:46.413
cmuazao9z0005ua9vaxxlnbb5	cmu2kzqeu00055t7mrgmescc1	ෆລກစຜ~🎀	+237653129649	\N	\N	2026-09-21 08:23:46.535	2026-09-21 08:23:46.535
cmuazaod90007ua9vvkp8lq1o	cmu2kzqeu00055t7mrgmescc1	༒☬ 𝙇𝘼𝙀𝙑𝙊 𝘿𝙋 ☬༒	+34643250796	\N	\N	2026-09-21 08:23:46.653	2026-09-21 08:23:46.653
cmuazaogs0009ua9v46eo4ni0	cmu2kzqeu00055t7mrgmescc1	ẞËLÊSKY JÜÑÏØR	+237653110119	\N	\N	2026-09-21 08:23:46.781	2026-09-21 08:23:46.781
cmuazaojv000bua9vtgk8lfox	cmu2kzqeu00055t7mrgmescc1	…Brandon	+237659277684	\N	\N	2026-09-21 08:23:46.891	2026-09-21 08:23:46.891
cmuazaoql000dua9vwmah64dm	cmu2kzqeu00055t7mrgmescc1	☠️ Messi ⚽🥅	+237654773332	\N	\N	2026-09-21 08:23:47.134	2026-09-21 08:23:47.134
cmuazaou0000fua9vq9nlttug	cmu2kzqeu00055t7mrgmescc1	♣️phaël🃏	+237682644398	\N	\N	2026-09-21 08:23:47.256	2026-09-21 08:23:47.256
cmuazaox7000hua9vyndyn12c	cmu2kzqeu00055t7mrgmescc1	✨ 𝕻𝖗𝖎𝖉𝖊💦	+237678173896	\N	\N	2026-09-21 08:23:47.371	2026-09-21 08:23:47.371
cmuazap0h000jua9vkh1hi6uu	cmu2kzqeu00055t7mrgmescc1	✪Céline Dio𝐫. 𝐒𝐁☘️	+237693703544	\N	\N	2026-09-21 08:23:47.489	2026-09-21 08:23:47.489
cmuazap5q000lua9vz6mawbxz	cmu2kzqeu00055t7mrgmescc1	➪𝐌𝐑☛ 𝐘𝐕𝐈-𝐗𝐗 ➭⚡	+2250566313496	\N	\N	2026-09-21 08:23:47.678	2026-09-21 08:23:47.678
cmuazap8u000nua9vhn20o4fl	cmu2kzqeu00055t7mrgmescc1	『𝐋𝐀𝐄𝐕𝐎 𝐃𝐏』WOO	+34642312782	\N	\N	2026-09-21 08:23:47.79	2026-09-21 08:23:47.79
cmuazape0000pua9vmxlrm5pb	cmu2kzqeu00055t7mrgmescc1	𝐉𝐮𝐬𝐭_𝐦𝐞_𝐬𝐚𝐝	+2250779072323	\N	\N	2026-09-21 08:23:47.976	2026-09-21 08:23:47.976
cmuazapj6000rua9vzcmvgq0m	cmu2kzqeu00055t7mrgmescc1	𝑾𝒊𝒍𝒍𝒊𝒂𝒎 𝑪𝒖𝒓𝒓𝒚	+237695043491	\N	\N	2026-09-21 08:23:48.162	2026-09-21 08:23:48.162
cmuazapom000tua9v0v6sgjyh	cmu2kzqeu00055t7mrgmescc1	𝕊𝕥𝕒𝕟𝕝𝕖𝕪	+237678186094	\N	\N	2026-09-21 08:23:48.358	2026-09-21 08:23:48.358
cmuazapzg000vua9v4zjrgq58	cmu2kzqeu00055t7mrgmescc1	𝙄𝙎𝙈𝘼𝙀𝙇 𝙁𝙍𝙀𝙀 𝙎𝙐𝙍𝙁	+237653887880	\N	\N	2026-09-21 08:23:48.748	2026-09-21 08:23:48.748
cmuazaq29000xua9vsfv72hko	cmu2kzqeu00055t7mrgmescc1	🍧Ange Kezia 🥰🍫☘️❤️	+237687172933	\N	\N	2026-09-21 08:23:48.849	2026-09-21 08:23:48.849
cmuazaq5d000zua9vvovjiqdr	cmu2kzqeu00055t7mrgmescc1	🏦 🇩‌🇮‌🇱‌🇦‌🇳‌🇩‌🇴‌ ✈️	+237688670389	\N	\N	2026-09-21 08:23:48.96	2026-09-21 08:23:48.96
cmuazaqsy0011ua9vhm3t4mf5	cmu2kzqeu00055t7mrgmescc1	💎 L'hømmë Prødig� � 🍀📿	+237689740869	\N	\N	2026-09-21 08:23:49.811	2026-09-21 08:23:49.811
cmuazarfa0013ua9vohbqy85s	cmu2kzqeu00055t7mrgmescc1	💰💵MR SONY STORE APPLE🍎	+237693173507	\N	\N	2026-09-21 08:23:50.614	2026-09-21 08:23:50.614
cmuazarij0015ua9v3ndzpc2g	cmu2kzqeu00055t7mrgmescc1	📶📶	+237651277312	\N	\N	2026-09-21 08:23:50.732	2026-09-21 08:23:50.732
cmuazarln0017ua9v2525dad8	cmu2kzqeu00055t7mrgmescc1	🕸️~ÄÑØÑŸMÕŪS~🕸️	+237656743251	\N	\N	2026-09-21 08:23:50.844	2026-09-21 08:23:50.844
cmuazaroy0019ua9vh25umtyw	cmu2kzqeu00055t7mrgmescc1	😁	+237692576979	\N	\N	2026-09-21 08:23:50.962	2026-09-21 08:23:50.962
cmuazarry001bua9v7yvoawis	cmu2kzqeu00055t7mrgmescc1	😇 Diabaté	+237657214742	\N	\N	2026-09-21 08:23:51.071	2026-09-21 16:28:19.749
cmuazarx9001dua9vo1w0oj2k	cmu2kzqeu00055t7mrgmescc1	🥰ZNAS🥰love🥰	+237655146694	\N	\N	2026-09-21 08:23:51.261	2026-09-21 08:23:51.261
cmuazas0l001fua9v2r5p5vsk	cmu2kzqeu00055t7mrgmescc1	🥰ZNAS🥰love🥰	+237692415093	\N	\N	2026-09-21 08:23:51.381	2026-09-21 08:23:51.381
cmuazas44001hua9v60gxtt3u	cmu2kzqeu00055t7mrgmescc1	🦁Leo... 👴🏾Ndi 😇	+23779703325	\N	\N	2026-09-21 08:23:51.508	2026-09-21 08:23:51.508
cmuazas7h001jua9vxugohrll	cmu2kzqeu00055t7mrgmescc1	🧸Fadi Kenza💍🩷	+237658336011	\N	\N	2026-09-21 08:23:51.629	2026-09-21 08:23:51.629
cmuazash6001lua9vtspwjs0b	cmu2kzqeu00055t7mrgmescc1	+22394945111	+22394945111	\N	\N	2026-09-21 08:23:51.978	2026-09-21 08:23:51.978
cmuazaslf001nua9vkosbzm4d	cmu2kzqeu00055t7mrgmescc1	+224612220149	+224612220149	\N	\N	2026-09-21 08:23:52.131	2026-09-21 08:23:52.131
cmuazasvg001pua9vg8269rda	cmu2kzqeu00055t7mrgmescc1	+224661745939	+224661745939	\N	\N	2026-09-21 08:23:52.493	2026-09-21 08:23:52.493
cmuazat1s001rua9vznjuox5z	cmu2kzqeu00055t7mrgmescc1	+2250500972056	+2250500972056	\N	\N	2026-09-21 08:23:52.72	2026-09-21 08:23:52.72
cmuazat4u001tua9vdinnkja5	cmu2kzqeu00055t7mrgmescc1	+2250502246310	+2250502246310	\N	\N	2026-09-21 08:23:52.83	2026-09-21 08:23:52.83
cmuazatgg001vua9vqye72atn	cmu2kzqeu00055t7mrgmescc1	+2250799438621	+2250799438621	\N	\N	2026-09-21 08:23:53.248	2026-09-21 08:23:53.248
cmuv83rz100075ojbe4coxlyf	cmu2ivveg0001z8ddgxkvkvbc	Brayan Weko	+237690374420	securise	\N	2026-10-05 12:25:44.793	2026-10-05 12:25:44.793
cmuv83s1n00095ojb464qafy7	cmu2ivveg0001z8ddgxkvkvbc	Brianne	+237655442219	\N	\N	2026-10-05 12:25:44.892	2026-10-05 12:25:44.892
cmuv83sat000b5ojb6h5695n5	cmu2ivveg0001z8ddgxkvkvbc	Rostand	+237657004106	\N	\N	2026-10-05 12:25:45.222	2026-10-05 12:25:45.222
\.


--
-- Data for Name: Country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Country" (id, nom, "codePays", "estParDefaut") FROM stdin;
cmsyju7x40003icdyzt0zq5jx	Cameroun	+237	t
cmsysr3nb0006shwv50e806rk	Sénégal	+221	f
cmsysr3o10007shwvp6575aqi	Côte d'Ivoire	+225	f
cmsysr3oo0008shwvgwih75jz	Congo	+242	f
cmsysr3ph0009shwv0jmi4of8	Gabon	+241	f
cmsysr3q1000ashwvwbh7qrc5	Guinée	+224	f
cmsysr3qp000bshwvwv2nyrrj	Burkina Faso	+226	f
cmsysr3ra000cshwvdou3mlyy	Mali	+223	f
\.


--
-- Data for Name: Device; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Device" (id, "userId", identifiant, nom, "datePremiereConnexion", "dateDerniereConnexion") FROM stdin;
cmsysw7ei003c7jjyeltf3c86	cmsyslwua0003vlwm8lrfk563	android_device_user_1	Audit Terminal	2026-08-18 15:11:37.339	2026-08-28 01:44:53.231
cmsysw7f7003d7jjy58e56zjv	cmsysr3lw0004shwvpep5rkzu	ios_device_admin_1	Audit Terminal	2026-08-18 15:11:37.363	2026-08-28 01:46:08.09
cmszmfqev003cmurref4z29xy	cmsysr3ck0003shwv6ahorru0	partner_device_1	Audit Terminal	2026-08-19 04:58:37.304	2026-08-28 01:46:07.929
cmu2r7wty0003c2yylmpq5jc2	cmu2ivveg0001z8ddgxkvkvbc	kwismo-device-android	Appareil verifie	2026-09-15 14:15:31.318	2026-09-21 02:18:43.452
cmu408p5x0003ttqki2wqctz7	cmsysr3lw0004shwvpep5rkzu	web-device-vgx3oskbt-mu4085s2	Kwismo Web App	2026-09-16 11:15:50.757	2026-09-19 10:13:15.386
cmu71on3l0001x2oihre7nbr7	cmsysr3ck0003shwv6ahorru0	web-device-vgx3oskbt-mu4085s2	Kwismo Web App	2026-09-18 14:19:32.717	2026-09-18 14:19:32.717
cmuayfcwk000713hpjjjchbl5	cmu2kzqeu00055t7mrgmescc1	kwismo-device-android	Appareil verifie	2026-09-21 07:59:25.46	2026-09-21 07:59:25.46
cmuluciod0003lri5e9dnwsn1	cmu2ivveg0001z8ddgxkvkvbc	kwismo-dev-a662ce6f-9ee3-435a-83b9-5018b1456ed8	ANDROID Mobile App	2026-09-28 22:50:42.445	2026-10-05 11:04:44.299
\.


--
-- Data for Name: Feedback; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Feedback" (id, "reportId", "userId", "typeRetour", contenu, "dateCreation") FROM stdin;
cmsyswx26003io9qrvv8vndu9	cmsyswx1a003go9qrfg6hogaq	cmsysu4j8000t5wd78t6ej3gn	report	Merci beaucoup pour ce signalement, ce numero a aussi tente de m'appeler !	2026-08-18 15:12:10.591
cmsznq7bl005na683vf9o4dkd	cmsznpg720053a683y2yb6iaq	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS régulier	2026-08-19 05:34:45.393
cmsznvfpd0045yqsvhzk0jk72	cmsznuomp003lyqsv2e3dywrz	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS régulier	2026-08-19 05:38:49.537
cmszo6ym2004513adw1bur3do	cmszo62e5003l13adufbly1oz	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS régulier	2026-08-19 05:47:47.258
cmszocq5w0045w9rbmj4ns8vo	cmszobtvu003lw9rbxji3eltk	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS régulier	2026-08-19 05:52:16.245
cmszor4pl0047pn8cckf4g4at	cmszoq8f5003npn8c5um3epcg	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS régulier	2026-08-19 06:03:28.282
cmszoysmt004739b4vefvfm30	cmszoxwfc003n39b4l9ptgcbx	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS régulier	2026-08-19 06:09:25.878
cmszp5dbn0047woryghu4miy3	cmszp4h2a003nworyme0mst3x	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS régulier	2026-08-19 06:14:32.628
cmszpcz7p0047l94ln9ft7t3r	cmszpc2sw003nl94l4gjn4rnp	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS régulier	2026-08-19 06:20:27.59
cmszthm7x0057l94l8snca4uz	cmsztgpxj004nl94l1wi4zms5	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS régulier	2026-08-19 08:16:02.493
cmsztp3ob006bl94l4lgnfvcr	cmszto7bz005nl94lr6k6ibl3	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS répétitif	2026-08-19 08:21:51.708
cmsztsqk2004boqoeu16a9g61	cmsztrubk003noqoetgu26t49	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS répétitif	2026-08-19 08:24:41.33
cmszxk79x005joqoe5n89snsx	cmszxjayd004toqoei8ohkd7w	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS répétitif	2026-08-19 10:10:01.557
cmszxnsgo004b5rn22athvdke	cmszxmw2p003n5rn2dzby140i	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS répétitif	2026-08-19 10:12:48.984
cmszyco4i005h5rn2xu7k66ge	cmszybrvc004t5rn2rd2z4utj	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS répétitif	2026-08-19 10:32:09.762
cmszymuqt004dwb2vkg7rsxrk	cmszylyjo003nwb2vjfa8nmyt	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS répétitif	2026-08-19 10:40:04.901
cmszyvpkz005lwb2vjjbd0yvr	cmszyutei004vwb2vwgi5naq0	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS répétitif	2026-08-19 10:46:58.115
cmtcaiv47006twb2vi41vjt26	cmtcahyyv0063wb2v4klvvq8c	cmsyslwua0003vlwm8lrfk563	report	Report validated: Spam SMS répétitif	2026-08-28 01:46:08.264
\.


--
-- Data for Name: Kpi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Kpi" (id, "nomIndicateur", valeur, periode, portee, "partnerId") FROM stdin;
cmsyswx6w003po9qrdhp5bh6a	signalements_mensuels	1240	2026-08	global	\N
cmsyswx7j003qo9qr5z3cgalt	taux_resolution	94.5	2026-08	global	\N
cmsyswx84003ro9qr64ct4024	partenaire_transactions	850	2026-08	partner	cmsysmkt80003j5e86xht9bn4
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Notification" (id, "userId", texte, lu, date) FROM stdin;
cmsyswx5k003no9qrfdl1j68r	cmsyslwua0003vlwm8lrfk563	Bienvenue sur KWISMO ! Votre compte est maintenant protege.	t	2026-08-18 15:12:10.712
cmsyswx6b003oo9qr5h9rvujo	cmsyslwua0003vlwm8lrfk563	Alerte de securite : Un numero frauduleux a ete signale dans votre zone.	f	2026-08-18 15:12:10.739
cmsznq7b7005la683kcgwc3s6	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 05:34:45.379
cmsznvfp70043yqsvbkbmax1e	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 05:38:49.531
cmszo6ylv004313ad6dqw0g33	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 05:47:47.251
cmszocq5q0043w9rbrg4h333t	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 05:52:16.238
cmszor4pe0045pn8cxmxyls8w	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 06:03:28.275
cmszoysmo004539b428j06tjy	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 06:09:25.872
cmszp5dbd0045woryot9gd1wp	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 06:14:32.618
cmszpcz7h0045l94lo2bd6lvo	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 06:20:27.582
cmszthm7o0055l94llnhujt4y	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 08:16:02.485
cmsztp3o50069l94ljk8ccsrz	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 08:21:51.701
cmsztsqjv0049oqoe8gpo9fkf	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 08:24:41.323
cmszxk79r005hoqoe3ozyqfof	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 10:10:01.551
cmszxnsgi00495rn21ejl4lww	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 10:12:48.978
cmszyco4c005f5rn2rep12qw8	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 10:32:09.756
cmszymuqm004bwb2v3p3188wi	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 10:40:04.894
cmszyvpks005jwb2vxxrkqjkz	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-19 10:46:58.109
cmtcaiv40006rwb2vm2lkfxkd	cmsyslwua0003vlwm8lrfk563	Votre signalement a été validé par nos équipes.	f	2026-08-28 01:46:08.256
\.


--
-- Data for Name: Numero; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Numero" (id, valeur, "scoreRisque", statut, "dateDerniereVerification", "countryId", "operatorId", "createdAt", "updatedAt") FROM stdin;
cmsysulq50000laffaeyp1zo5	+237670000001	0.1	securise	2026-08-28 01:45:26.553	cmsyju7x40003icdyzt0zq5jx	cmsysr3sa000eshwv3qubm6ec	2026-08-18 15:10:22.59	2026-08-28 01:45:26.557
cmsysvmrn003cytq2lhfp9o5n	+237690000002	0	securise	\N	cmsyju7x40003icdyzt0zq5jx	cmsysr40h0012shwvm0evxmy8	2026-08-18 15:11:10.596	2026-08-18 15:11:10.596
cmsysvmsh003dytq2lj4qyoi0	+237677889900	0.7	frauduleux	2026-08-28 01:46:08.195	cmsyju7x40003icdyzt0zq5jx	cmsysr3sa000eshwv3qubm6ec	2026-08-18 15:11:10.626	2026-08-28 01:46:08.244
cmsysvmta003eytq2vwri2ll5	+237699001122	0	securise	\N	cmsyju7x40003icdyzt0zq5jx	cmsysr40h0012shwvm0evxmy8	2026-08-18 15:11:10.654	2026-08-18 15:11:10.654
cmsysvmtt003fytq2dh5rfnra	+237670999888	0.1	securise	2026-08-28 01:45:26.572	cmsyju7x40003icdyzt0zq5jx	cmsysr3sa000eshwv3qubm6ec	2026-08-18 15:11:10.673	2026-08-28 01:45:26.574
cmsysvmug003gytq2brri8s4c	+237699111222	65	a_signaler	\N	cmsyju7x40003icdyzt0zq5jx	cmsysr40h0012shwvm0evxmy8	2026-08-18 15:11:10.696	2026-08-18 15:11:10.696
cmtca93tp0001orivanejwims	+237690000000	0.1	securise	2026-08-28 01:38:32.987	cmsyju7x40003icdyzt0zq5jx	cmsysr40h0012shwvm0evxmy8	2026-08-28 01:38:32.99	2026-08-28 01:38:32.99
cmu2l3ujy00095t7m2q3zvscs	+237678688161	0.1	securise	2026-09-15 11:24:24.042	cmsyju7x40003icdyzt0zq5jx	cmsysr3sa000eshwv3qubm6ec	2026-09-15 11:24:24.046	2026-09-15 11:24:24.046
cmubg7gp40003zs52rvefq81q	+237680728787	0.1	securise	2026-09-21 16:17:10.193	cmsyju7x40003icdyzt0zq5jx	cmsysr3sa000eshwv3qubm6ec	2026-09-21 16:17:10.209	2026-09-21 16:17:10.209
cmubl3trf000bzs52edoqoxto	+15715309085	0.7	frauduleux	2026-09-21 18:34:18.597	cmsyju7x40003icdyzt0zq5jx	\N	2026-09-21 18:34:18.602	2026-09-21 18:34:18.602
cmubl8heu000dzs52ur9m6bnl	+237620132092	0.05	securise	2026-09-29 01:35:59.259	cmsyju7x40003icdyzt0zq5jx	cmsysr47w001oshwvguhqiu7q	2026-09-21 18:37:55.879	2026-09-29 01:35:59.264
cmuv97834000d5ojbrmzjr5tj	+237679660706	0.05	securise	2026-10-05 12:56:24.985	cmsyju7x40003icdyzt0zq5jx	cmsysr3sa000eshwv3qubm6ec	2026-10-05 12:56:25.264	2026-10-05 12:56:25.264
\.


--
-- Data for Name: Operator; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Operator" (id, nom, "countryId") FROM stdin;
cmsysr3sa000eshwv3qubm6ec	MTN Cameroun	cmsyju7x40003icdyzt0zq5jx
cmsysr40h0012shwvm0evxmy8	Orange Cameroun	cmsyju7x40003icdyzt0zq5jx
cmsysr47w001oshwvguhqiu7q	Camtel (Blue)	cmsyju7x40003icdyzt0zq5jx
cmsysr4a2001ushwvgyocad9e	Orange Sénégal	cmsysr3nb0006shwv50e806rk
cmsysr4c60020shwvl2zsp0ls	Free Sénégal	cmsysr3nb0006shwv50e806rk
cmsysr4dm0024shwvynwe6mh9	Expresso Sénégal	cmsysr3nb0006shwv50e806rk
cmsysr4fg0028shwvi9bgdp3z	MTN Côte d'Ivoire	cmsysr3o10007shwvp6575aqi
cmsysr4k7002kshwvekd2l9i7	Orange Côte d'Ivoire	cmsysr3o10007shwvp6575aqi
cmsysr4nz002wshwvl0ux89vb	Moov Africa Côte d'Ivoire	cmsysr3o10007shwvp6575aqi
cmsysr4ru0038shwvgjchqlip	MTN Congo	cmsysr3oo0008shwvgwih75jz
cmsysr4ty003eshwvp099zzj5	Airtel Congo	cmsysr3oo0008shwvgwih75jz
cmsysr4we003kshwvcjizd0tc	Airtel Gabon	cmsysr3ph0009shwv0jmi4of8
cmsysr4yf003qshwvcoe389c7	Moov Africa Gabon	cmsysr3ph0009shwv0jmi4of8
cmsysr50w003wshwvacfukvrj	Orange Guinée	cmsysr3q1000ashwvwbh7qrc5
cmsysr53e0042shwvtaoraf3q	MTN Guinée	cmsysr3q1000ashwvwbh7qrc5
cmsysr55e0048shwv704rvx8u	Orange Burkina Faso	cmsysr3qp000bshwvwv2nyrrj
cmsysr5aq004mshwvqd4wppll	MTN Cameroun	cmsysr3qp000bshwvwv2nyrrj
cmsysr5fw0050shwveejqp9v1	Orange Mali	cmsysr3ra000cshwvdou3mlyy
cmsysr5lt005ashwvky63t94y	Moov Africa Mali	cmsysr3ra000cshwvdou3mlyy
cmsznsio0002fyqsvr6ws2a5r	Moov Africa Burkina Faso	cmsysr3qp000bshwvwv2nyrrj
\.


--
-- Data for Name: OperatorPrefix; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OperatorPrefix" (id, "operatorId", prefixe) FROM stdin;
cmsysr3sz000gshwv8hz64nlb	cmsysr3sa000eshwv3qubm6ec	67
cmsysr3tq000ishwvuy53mtph	cmsysr3sa000eshwv3qubm6ec	650
cmsysr3uh000kshwv4d23jljo	cmsysr3sa000eshwv3qubm6ec	651
cmsysr3v6000mshwv17vytfnb	cmsysr3sa000eshwv3qubm6ec	652
cmsysr3vx000oshwvuz1khdvc	cmsysr3sa000eshwv3qubm6ec	653
cmsysr3wk000qshwvksreyz9p	cmsysr3sa000eshwv3qubm6ec	654
cmsysr3xa000sshwv8yqm4tgg	cmsysr3sa000eshwv3qubm6ec	680
cmsysr3xu000ushwvcfjjz1do	cmsysr3sa000eshwv3qubm6ec	681
cmsysr3yi000wshwvsxlwfddc	cmsysr3sa000eshwv3qubm6ec	682
cmsysr3z7000yshwvbyhy3iwy	cmsysr3sa000eshwv3qubm6ec	683
cmsysr3zt0010shwvm0ea758v	cmsysr3sa000eshwv3qubm6ec	684
cmsysr4160014shwv0o1lg03p	cmsysr40h0012shwvm0evxmy8	69
cmsysr41x0016shwvk9krwx2l	cmsysr40h0012shwvm0evxmy8	655
cmsysr42j0018shwvipl9ucy9	cmsysr40h0012shwvm0evxmy8	656
cmsysr436001ashwvx2rx7o1g	cmsysr40h0012shwvm0evxmy8	657
cmsysr43u001cshwvihgdsfyb	cmsysr40h0012shwvm0evxmy8	658
cmsysr44f001eshwvhe3pbzsd	cmsysr40h0012shwvm0evxmy8	659
cmsysr452001gshwv35ucjelr	cmsysr40h0012shwvm0evxmy8	686
cmsysr45r001ishwvp1ynk1qe	cmsysr40h0012shwvm0evxmy8	687
cmsysr46h001kshwvulq03704	cmsysr40h0012shwvm0evxmy8	688
cmsysr475001mshwv7rk8fx5y	cmsysr40h0012shwvm0evxmy8	689
cmsysr48o001qshwvy2awglh4	cmsysr47w001oshwvguhqiu7q	62
cmsysr49e001sshwvbzfzjjpt	cmsysr47w001oshwvguhqiu7q	66
cmsysr4at001wshwvpdgs3ekz	cmsysr4a2001ushwvgyocad9e	77
cmsysr4bg001yshwvgb5oj7g7	cmsysr4a2001ushwvgyocad9e	78
cmsysr4cx0022shwv8jutm30s	cmsysr4c60020shwvl2zsp0ls	76
cmsysr4el0026shwvyos9bxjr	cmsysr4dm0024shwvynwe6mh9	70
cmsysr4gd002ashwvf52dxyjm	cmsysr4fg0028shwvi9bgdp3z	05
cmsysr4h9002cshwvdguofygh	cmsysr4fg0028shwvi9bgdp3z	45
cmsysr4i4002eshwvv7ywnuy5	cmsysr4fg0028shwvi9bgdp3z	55
cmsysr4iv002gshwvdhumdeoa	cmsysr4fg0028shwvi9bgdp3z	65
cmsysr4jk002ishwvbaopbjkm	cmsysr4fg0028shwvi9bgdp3z	85
cmsysr4kv002mshwv1j2waj77	cmsysr4k7002kshwvekd2l9i7	07
cmsysr4lj002oshwv23zu6nwp	cmsysr4k7002kshwvekd2l9i7	47
cmsysr4m3002qshwvgxg8ut28	cmsysr4k7002kshwvekd2l9i7	57
cmsysr4ms002sshwvk07rlzpz	cmsysr4k7002kshwvekd2l9i7	67
cmsysr4ne002ushwvfk97hbca	cmsysr4k7002kshwvekd2l9i7	87
cmsysr4or002yshwv8syxrhyr	cmsysr4nz002wshwvl0ux89vb	01
cmsysr4pb0030shwvs4pb9v0b	cmsysr4nz002wshwvl0ux89vb	41
cmsysr4px0032shwv9rkpvxxj	cmsysr4nz002wshwvl0ux89vb	51
cmsysr4qk0034shwv8wubf14d	cmsysr4nz002wshwvl0ux89vb	61
cmsysr4ra0036shwv0t0c5vzy	cmsysr4nz002wshwvl0ux89vb	81
cmsysr4sh003ashwvh8otl4n7	cmsysr4ru0038shwvgjchqlip	06
cmsysr4ta003cshwvfhipmurg	cmsysr4ru0038shwvgjchqlip	05
cmsysr4uz003gshwvpcl22u1u	cmsysr4ty003eshwvp099zzj5	04
cmsysr4vq003ishwv7ome6ch4	cmsysr4ty003eshwvp099zzj5	07
cmsysr4x2003mshwvot1ytjds	cmsysr4we003kshwvcjizd0tc	07
cmsysr4xq003oshwv0n28t0f3	cmsysr4we003kshwvcjizd0tc	06
cmsysr4zh003sshwv27uv21ag	cmsysr4yf003qshwvcoe389c7	05
cmsysr505003ushwvqbdxr9bl	cmsysr4yf003qshwvcoe389c7	04
cmsysr51s003yshwv5lchor71	cmsysr50w003wshwvacfukvrj	62
cmsysr52l0040shwvhf2jraqj	cmsysr50w003wshwvacfukvrj	65
cmsysr53y0044shwv7snvj2as	cmsysr53e0042shwvtaoraf3q	63
cmsysr54q0046shwvyn2m2lov	cmsysr53e0042shwvtaoraf3q	66
cmsysr568004ashwvairqtbrv	cmsysr55e0048shwv704rvx8u	70
cmsysr572004cshwvmf6ynzw9	cmsysr55e0048shwv704rvx8u	71
cmsysr57p004eshwvvk2yjfzm	cmsysr55e0048shwv704rvx8u	72
cmsysr58n004gshwvugs8dbc7	cmsysr55e0048shwv704rvx8u	73
cmsysr59b004ishwvskv5bz2d	cmsysr55e0048shwv704rvx8u	74
cmsysr5a0004kshwv4doa0znz	cmsysr55e0048shwv704rvx8u	75
cmsysr5gm0052shwvnmyr0k5d	cmsysr5fw0050shwveejqp9v1	70
cmsysr5hl0054shwvlc013ez6	cmsysr5fw0050shwveejqp9v1	71
cmsysr5j80056shwvd7dq7mv4	cmsysr5fw0050shwveejqp9v1	72
cmsysr5kv0058shwvenebdgo8	cmsysr5fw0050shwveejqp9v1	73
cmsysr5mj005cshwvjt9aqh2h	cmsysr5lt005ashwvky63t94y	65
cmsysr5nc005eshwv0blkx6y2	cmsysr5lt005ashwvky63t94y	66
cmsysr5o7005gshwvjsri1kvf	cmsysr5lt005ashwvky63t94y	67
cmsznsio7002gyqsvrh7qezjb	cmsznsio0002fyqsvr6ws2a5r	60
cmsznsiog002hyqsv6zrz88p6	cmsznsio0002fyqsvr6ws2a5r	61
cmsznsioo002iyqsvejvifzxz	cmsznsio0002fyqsvr6ws2a5r	62
cmsznsiow002jyqsvqitpsnfe	cmsznsio0002fyqsvr6ws2a5r	63
cmsznsip4002kyqsvj058pxqf	cmsznsio0002fyqsvr6ws2a5r	64
cmsznsipc002lyqsv94t0wcdy	cmsznsio0002fyqsvr6ws2a5r	65
\.


--
-- Data for Name: OtpCode; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OtpCode" (id, "userId", "userPhoneId", code, canal, cible, "dateExpiration", "estUtilise", "createdAt") FROM stdin;
cmszmcfz4003da683by9ve0mw	cmsyslwua0003vlwm8lrfk563	\N	828745	email	user@kwismo.com	2026-08-19 05:01:03.806	f	2026-08-19 04:56:03.808
cmu2hu14i00037jqjk8tt4xrh	cmu2hu13j00017jqju6dvmafp	\N	654252	email	test_banal_1789465966@kwismo-test.org	2026-09-15 09:57:47.148	t	2026-09-15 09:52:47.154
cmu2hu6bg00057jqj28i95hlk	cmu2hu13j00017jqju6dvmafp	\N	288392	email	test_banal_1789465966@kwismo-test.org	2026-09-15 09:57:53.88	f	2026-09-15 09:52:53.884
cmu2huz1o00097jqj3kykveoe	cmu2huz1600077jqj8pwg0rg9	\N	925987	email	user_banal_1789466010@kwismo-test.org	2026-09-15 09:58:31.113	f	2026-09-15 09:53:31.117
cmu2hvip1000d7jqjtgdv4e3g	cmu2hvioj000b7jqjeazowfy5	\N	381454	email	user_banal_1789466036@kwismo-test.org	2026-09-15 09:58:56.578	f	2026-09-15 09:53:56.582
cmu2hxx0o000h7jqjjgrkfqup	cmu2hxx05000f7jqjb0yx35uy	\N	268182	email	user_banal_1789466148@kwismo-test.org	2026-09-15 10:00:48.451	f	2026-09-15 09:55:48.456
cmu2hyglp000l7jqj7sce945n	cmu2hygl6000j7jqjqx6z1wzb	\N	374512	email	user_banal_1789466173@kwismo-test.org	2026-09-15 10:01:13.833	t	2026-09-15 09:56:13.838
cmu2hyizm000n7jqjlc5q8szu	cmu2hygl6000j7jqjqx6z1wzb	\N	113655	email	user_banal_1789466173@kwismo-test.org	2026-09-15 10:01:16.928	f	2026-09-15 09:56:16.931
cmu2ivvf10003z8dd24lh1re1	cmu2ivveg0001z8ddgxkvkvbc	\N	112694	email	wekobrayan163@gmail.com	2026-09-15 10:27:12.682	t	2026-09-15 10:22:12.686
cmu2kbv6200035t7mn6q50jas	cmu2kbv5100015t7muyukztzb	\N	010275	email	lelouchloyd@gmail.com	2026-09-15 11:07:38.468	f	2026-09-15 11:02:38.475
cmu2kzqfl00075t7maze9l74u	cmu2kzqeu00055t7mrgmescc1	\N	617963	email	newtonachonduh46@gmail.com	2026-09-15 11:26:12.077	t	2026-09-15 11:21:12.081
cmu2lij9e000310iye83u7ige	cmu2lij8x000110iykz2s5bsp	\N	050084	email	unverified_f8ecd9a9@example.com	2026-09-15 11:40:49.248	t	2026-09-15 11:35:49.25
cmu2lima9000510iyszaee6q3	cmu2lij8x000110iykz2s5bsp	\N	221583	email	unverified_f8ecd9a9@example.com	2026-09-15 11:40:53.168	t	2026-09-15 11:35:53.17
cmu2liqq6000710iy2a8wcune	cmu2lij8x000110iykz2s5bsp	\N	694068	email	unverified_f8ecd9a9@example.com	2026-09-15 11:40:58.925	t	2026-09-15 11:35:58.927
cmu2litkn000910iy3r5cjgtd	cmu2lij8x000110iykz2s5bsp	\N	401900	email	unverified_f8ecd9a9@example.com	2026-09-15 11:41:02.614	f	2026-09-15 11:36:02.616
cmu2q0mhf000111w39x2lhdjp	cmu2ivveg0001z8ddgxkvkvbc	\N	520927	email	wekobrayan163@gmail.com	2026-09-15 13:46:51.689	t	2026-09-15 13:41:51.697
cmu2r71kv0001c2yy01pz7ace	cmu2ivveg0001z8ddgxkvkvbc	\N	475320	email	wekobrayan163@gmail.com	2026-09-15 14:19:50.804	t	2026-09-15 14:14:50.812
cmu3f1ozg000111kw3sr0xuep	cmu2ivveg0001z8ddgxkvkvbc	\N	580911	email	wekobrayan163@gmail.com	2026-09-16 01:27:31.985	t	2026-09-16 01:22:31.993
cmu3p3wvm000311kwasikfrpo	cmu2ivveg0001z8ddgxkvkvbc	\N	530310	email	wekobrayan163@gmail.com	2026-09-16 06:09:11.692	t	2026-09-16 06:04:11.698
cmu4086920001ttqke37m4okr	cmsysr3lw0004shwvpep5rkzu	\N	813636	email	admin@kwismo.com	2026-09-16 11:20:26.235	t	2026-09-16 11:15:26.243
cmu46r03y0005ttqkjn31juaf	cmu2ivveg0001z8ddgxkvkvbc	\N	672574	email	wekobrayan163@gmail.com	2026-09-16 14:23:02.435	t	2026-09-16 14:18:02.444
cmu4or5860007ttqk3n7wzc79	cmu2ivveg0001z8ddgxkvkvbc	\N	300123	email	wekobrayan163@gmail.com	2026-09-16 22:47:02.151	t	2026-09-16 22:42:02.165
cmu59a44p000114p2v7411bfl	cmu2ivveg0001z8ddgxkvkvbc	\N	577995	email	wekobrayan163@gmail.com	2026-09-17 08:21:39.516	t	2026-09-17 08:16:39.526
cmu5rvsxo000129emybl8sbvh	cmu2ivveg0001z8ddgxkvkvbc	\N	238070	email	wekobrayan163@gmail.com	2026-09-17 17:02:24.53	t	2026-09-17 16:57:24.537
cmuah9350000114ncs73isjj5	cmu2ivveg0001z8ddgxkvkvbc	\N	664174	email	wekobrayan163@gmail.com	2026-09-21 00:03:39.386	t	2026-09-20 23:58:39.395
cmuahqw65000314ncwwflp4nk	cmu2ivveg0001z8ddgxkvkvbc	\N	532862	email	wekobrayan163@gmail.com	2026-09-21 00:17:30.167	t	2026-09-21 00:12:30.173
cmuaj255y0001bgoapw05uyy8	cmu2ivveg0001z8ddgxkvkvbc	\N	694728	email	wekobrayan163@gmail.com	2026-09-21 00:54:14.657	t	2026-09-21 00:49:14.66
cmuaj44b10003bgoaf5045md6	cmu2ivveg0001z8ddgxkvkvbc	\N	925120	email	wekobrayan163@gmail.com	2026-09-21 00:55:46.857	t	2026-09-21 00:50:46.861
cmuaj4d100005bgoaglz10z2r	cmu2ivveg0001z8ddgxkvkvbc	\N	242071	email	wekobrayan163@gmail.com	2026-09-21 00:55:58.161	t	2026-09-21 00:50:58.164
cmuakdjw00007bgoa4juedhwx	cmu2ivveg0001z8ddgxkvkvbc	\N	944516	email	wekobrayan163@gmail.com	2026-09-21 01:31:06.571	t	2026-09-21 01:26:06.574
cmuaxsyy2000113hpd2f8v79d	cmu2kzqeu00055t7mrgmescc1	\N	281114	email	newtonachonduh46@gmail.com	2026-09-21 07:47:00.925	t	2026-09-21 07:42:00.931
cmuaxz121000313hpj1xgoabq	cmu2kzqeu00055t7mrgmescc1	\N	606995	email	newtonachonduh46@gmail.com	2026-09-21 07:51:43.595	t	2026-09-21 07:46:43.61
cmuayemsv000513hpreg6q3pv	cmu2kzqeu00055t7mrgmescc1	\N	502685	email	newtonachonduh46@gmail.com	2026-09-21 08:03:51.611	t	2026-09-21 07:58:51.63
cmub1rxk7000113mg8jeff4jw	cmu2ivveg0001z8ddgxkvkvbc	\N	400198	email	wekobrayan163@gmail.com	2026-09-21 09:38:10.942	t	2026-09-21 09:33:10.948
cmub5z0nr000399395iasbuh3	cmsyslwua0003vlwm8lrfk563	\N	344570	sms	+237690374420	2026-09-21 11:35:40.022	t	2026-09-21 11:30:40.024
cmub5z3t700079939f66xv28o	cmsyslwua0003vlwm8lrfk563	\N	335324	sms	+237676329084	2026-09-21 11:35:44.105	t	2026-09-21 11:30:44.107
cmub9ww670003qjom0us3ztmx	cmsyslwua0003vlwm8lrfk563	\N	501307	sms	+237690374420	2026-09-21 13:25:59.357	t	2026-09-21 13:20:59.359
cmub9wxco0007qjom4g8xmwfg	cmsyslwua0003vlwm8lrfk563	\N	131023	sms	+237676329084	2026-09-21 13:26:00.885	t	2026-09-21 13:21:00.888
cmubfnwe90001zs5282n20ga9	cmu2kzqeu00055t7mrgmescc1	\N	439862	email	newtonachonduh46@gmail.com	2026-09-21 16:06:57.421	t	2026-09-21 16:01:57.435
cmubgd5wh0007zs52os0x4aes	cmu2kzqeu00055t7mrgmescc1	cmubgd5vm0005zs52w0hs36wh	635747	sms	+237678688161	2026-09-21 16:26:36.156	f	2026-09-21 16:21:36.161
cmubkujem0009zs5216m5s4u9	cmu2ivveg0001z8ddgxkvkvbc	\N	005170	email	wekobrayan163@gmail.com	2026-09-21 18:32:05.272	t	2026-09-21 18:27:05.277
cmucdtdat0001lmr3e0wzpoll	cmu2ivveg0001z8ddgxkvkvbc	\N	543786	email	wekobrayan163@gmail.com	2026-09-22 08:02:59.563	t	2026-09-22 07:57:59.571
cmucdtmdj0003lmr3hhks2cfi	cmu2ivveg0001z8ddgxkvkvbc	\N	916284	email	wekobrayan163@gmail.com	2026-09-22 08:03:11.326	t	2026-09-22 07:58:11.335
cmukcyo610001cztbzpt0nvxj	cmu2ivveg0001z8ddgxkvkvbc	\N	668141	email	wekobrayan163@gmail.com	2026-09-27 22:01:16.717	t	2026-09-27 21:56:16.729
cmuky9fby0003cztby2aafto1	cmu2ivveg0001z8ddgxkvkvbc	\N	640754	email	wekobrayan163@gmail.com	2026-09-28 07:57:30.422	t	2026-09-28 07:52:30.428
cmulubnvl0001lri5mwinpyxz	cmu2ivveg0001z8ddgxkvkvbc	\N	256114	email	wekobrayan163@gmail.com	2026-09-28 22:55:02.512	t	2026-09-28 22:50:02.525
cmuv5b5sd00035ojby3bke40h	cmu2ivveg0001z8ddgxkvkvbc	cmuv5b5qn00015ojb080h494o	890575	sms	+237690374420	2026-10-05 11:12:30.431	t	2026-10-05 11:07:30.445
cmuv5bf6v00055ojb03w2trow	cmu2ivveg0001z8ddgxkvkvbc	cmuv5b5qn00015ojb080h494o	108142	sms	+237690374420	2026-10-05 11:12:42.617	t	2026-10-05 11:07:42.631
\.


--
-- Data for Name: Partner; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Partner" (id, "nomEntreprise", "typePartenariat", "dateAdhesion") FROM stdin;
cmsysmkt80003j5e86xht9bn4	KWISMO Partner Test	Fintech	2026-08-18 15:04:08.156
cmsysu4fk000r5wd7napvsy51	Orange Cameroun	Operator	2026-08-18 15:10:00.176
\.


--
-- Data for Name: PartnerRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PartnerRequest" (id, "nomContact", email, "nomEntreprise", "typePartenariat", telephone, message, statut, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Report; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Report" (id, "userId", "numeroId", motif, "dateSignalement", statut) FROM stdin;
cmsyswx1a003go9qrfg6hogaq	cmsyslwua0003vlwm8lrfk563	cmsysvmtt003fytq2dh5rfnra	Ce numero m'a envoye un SMS pretendant que mon compte MoMo etait bloque et exigeant mon PIN.	2026-08-18 15:12:10.558	validated
cmsyswx30003jo9qru2nwvi3p	cmsysu4j8000t5wd78t6ej3gn	cmsysvmug003gytq2brri8s4c	Appel suspect d'une personne se disant du support technique Orange Money.	2026-08-18 15:12:10.62	pending
cmszmu9jk004fa68383yg7awk	cmsyslwua0003vlwm8lrfk563	cmsysvmtt003fytq2dh5rfnra	Hameçonnage SMS	2026-08-19 05:09:55.28	pending
cmsznpg720053a683y2yb6iaq	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS régulier	2026-08-19 05:34:10.238	validated
cmsznuomp003lyqsv2e3dywrz	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS régulier	2026-08-19 05:38:14.449	validated
cmszo62e5003l13adufbly1oz	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS régulier	2026-08-19 05:47:05.502	validated
cmszobtvu003lw9rbxji3eltk	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS régulier	2026-08-19 05:51:34.41	validated
cmszoq8f5003npn8c5um3epcg	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS régulier	2026-08-19 06:02:46.434	validated
cmszoxwfc003n39b4l9ptgcbx	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS régulier	2026-08-19 06:08:44.136	validated
cmszp4h2a003nworyme0mst3x	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS régulier	2026-08-19 06:13:50.818	validated
cmszpc2sw003nl94l4gjn4rnp	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS régulier	2026-08-19 06:19:45.584	validated
cmsztgpxj004nl94l1wi4zms5	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS régulier	2026-08-19 08:15:20.648	validated
cmszto7bz005nl94lr6k6ibl3	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS répétitif	2026-08-19 08:21:09.791	validated
cmsztrubk003noqoetgu26t49	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS répétitif	2026-08-19 08:23:59.553	validated
cmszxjayd004toqoei8ohkd7w	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS répétitif	2026-08-19 10:09:19.67	validated
cmszxmw2p003n5rn2dzby140i	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS répétitif	2026-08-19 10:12:07.009	validated
cmszybrvc004t5rn2rd2z4utj	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS répétitif	2026-08-19 10:31:27.96	validated
cmszylyjo003nwb2vjfa8nmyt	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS répétitif	2026-08-19 10:39:23.173	validated
cmszyutei004vwb2vwgi5naq0	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS répétitif	2026-08-19 10:46:16.41	validated
cmtcahyyv0063wb2v4klvvq8c	cmsyslwua0003vlwm8lrfk563	cmsysvmsh003dytq2lj4qyoi0	Spam SMS répétitif	2026-08-28 01:45:26.599	validated
\.


--
-- Data for Name: ReportCategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ReportCategory" (id, "reportId", "scamCategoryId", "createdAt") FROM stdin;
cmsyswx1p003ho9qrisywx35y	cmsyswx1a003go9qrfg6hogaq	cmsyswwz0003co9qr41rlt9a5	2026-08-18 15:12:10.573
cmsyswx3h003ko9qr27o8s4ox	cmsyswx30003jo9qru2nwvi3p	cmsyswx07003eo9qrpcwecbir	2026-08-18 15:12:10.637
\.


--
-- Data for Name: Role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Role" (id, "nomRole", "partnerId") FROM stdin;
cmsyju7wa0000icdyjw9azk4t	user	\N
cmsyju7wn0001icdyf9ktv70l	partner	\N
cmsyju7ww0002icdy66jnbyqa	admin	\N
cmu6llcou0000ymv085kazhmu	super_admin	\N
cmu86witw000112ltd2hs693x	Test	cmsysmkt80003j5e86xht9bn4
\.


--
-- Data for Name: ScamCategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ScamCategory" (id, "nomCode", libelle, description, "createdAt") FROM stdin;
cmsyswwz0003co9qr41rlt9a5	phishing	Hameçonnage / Faux SMS Opérateur	SMS piégé demandant le code secret MoMo ou Orange Money.	2026-08-18 15:12:10.476
cmsyswwzn003do9qr33729vae	sim_swap	Usurpation de Carte SIM	Transfert frauduleux de ligne mobile vers une autre carte SIM.	2026-08-18 15:12:10.499
cmsyswx07003eo9qrpcwecbir	fake_operator	Faux Agent d'Assistance	Appel se réclamant du service client pour soutirer des données.	2026-08-18 15:12:10.519
cmsyswx0p003fo9qralqv8cgm	social_engineering	Faux Gain / Loterie	Message annonçant un gain fictif conditionné par un transfert d'argent.	2026-08-18 15:12:10.537
\.


--
-- Data for Name: Survey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Survey" (id, question, actif, "dateCreation") FROM stdin;
cmszwgitm003c8z41qf20sx7x	Comment évaluez-vous la précision des alertes anti-escroquerie KWISMO ?	t	2026-08-19 09:39:10.282
\.


--
-- Data for Name: SurveyResponse; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SurveyResponse" (id, "userId", "surveyId", reponse, "dateReponse") FROM stdin;
cmszxk6xu0055oqoecy3egs5p	cmsyslwua0003vlwm8lrfk563	cmszwgitm003c8z41qf20sx7x	Très satisfait	2026-08-19 10:10:01.123
\.


--
-- Data for Name: Transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Transaction" (id, "userId", "numeroId", "countryId", "operatorId", "ussdActionId", montant, "dateTransaction", statut, "niveauRisque", "codeUSSDGenere") FROM stdin;
cmsyswx43003lo9qr43ust2be	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	\N	\N	\N	15000	2026-08-18 15:12:10.659	confirmed	low	*126*15000*670000001#
cmsyswx4v003mo9qrmhqso473	cmsyslwua0003vlwm8lrfk563	cmsysvmtt003fytq2dh5rfnra	\N	\N	\N	50000	2026-08-18 15:12:10.687	cancelled	critical	\N
cmszn26v4004ta683d5t749ew	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	2500	2026-08-19 05:16:05.056	prepared	faible	*123#
cmsznq6wd0057a683nmblhxvc	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 05:34:44.845	prepared	faible	*123#
cmsznvfao003pyqsvk0mdjqjb	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 05:38:49.009	prepared	faible	*123#
cmszo6y7p003p13ado3a87hbu	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 05:47:46.741	prepared	faible	*123#
cmszocpo1003pw9rbwk6u48mq	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 05:52:15.601	prepared	faible	*123#
cmszor4bz003rpn8cinaarktv	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 06:03:27.792	prepared	faible	*123#
cmszoys9k003r39b44wg0ofs5	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 06:09:25.4	prepared	faible	*123#
cmszp5cvy003rworyfvt1eni2	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 06:14:32.062	prepared	faible	*123#
cmszpcyq2003rl94lfjam370z	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 06:20:26.955	prepared	faible	*123#
cmszthlrd004rl94l96csdfp6	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 08:16:01.897	prepared	faible	*123#
cmsztp365005rl94lvpluvm9s	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 08:21:51.053	prepared	faible	*123#
cmsztsq4l003roqoessgi1gw5	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 08:24:40.773	prepared	faible	*123#
cmszxk6ss004xoqoe6qt9iqxp	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 10:10:00.94	prepared	faible	*123#
cmszxnrwr003r5rn2i56ofpem	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 10:12:48.267	prepared	faible	*123#
cmszycnnu004x5rn2jo2z7qhg	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 10:32:09.163	prepared	faible	*123#
cmszymuax003rwb2vwzr9hj97	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 10:40:04.329	prepared	faible	*123#
cmszyvp4k004zwb2vaell5usp	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-19 10:46:57.525	prepared	faible	*123#
cmtcaiuo60067wb2vyb5iahf4	cmsyslwua0003vlwm8lrfk563	cmsysulq50000laffaeyp1zo5	cmsysr3qp000bshwvwv2nyrrj	cmsysr5aq004mshwvqd4wppll	cmsysr60u006ashwvcizbidra	1500	2026-08-28 01:46:07.686	prepared	faible	*123#
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, nom, prenom, email, "motDePasse", "emailVerifie", statut, langue, photo_url, "dateInscription", "updatedAt", "roleId", "partnerId") FROM stdin;
cmsyslwua0003vlwm8lrfk563	UserTestName	Test	user@kwismo.com	$argon2id$v=19$m=65536,t=3,p=4$oTO4L9rxIEYIuNf45ZvXNQ$Nzzd9UN9PYZl3FN4mR/haAU/buHL3UCTPGSMqYEvuKQ	t	active	fr	http://test.com/photo.jpg	2026-08-18 15:03:37.09	2026-09-21 08:50:50.015	cmsyju7wa0000icdyjw9azk4t	\N
cmsysr3ck0003shwv6ahorru0	Partner	Test	partner@kwismo.com	$argon2id$v=19$m=65536,t=3,p=4$iQcQ6jHucJf6CkmOwk6/2Q$aPxNqxv785iNHbrv3reouKMFA5C2ZoEOTmAqj/WItwU	t	active	fr	\N	2026-08-18 15:07:38.804	2026-08-18 15:07:38.804	cmsyju7wn0001icdyf9ktv70l	cmsysmkt80003j5e86xht9bn4
cmsysr3lw0004shwvpep5rkzu	KWISMO	Admin	admin@kwismo.com	$argon2id$v=19$m=65536,t=3,p=4$Txo6EdpZofrt6uya1MqznA$qmyfmJ55KlZi+2QpjxC7Dz5I+Wk8v573J8kVA3UUaMI	t	active	fr	\N	2026-08-18 15:07:39.14	2026-09-18 06:49:05.421	cmu6llcou0000ymv085kazhmu	\N
cmsysu4j8000t5wd78t6ej3gn	Douala	Paul	user2@kwismo.com	$argon2id$v=19$m=65536,t=3,p=4$jhRuM3TPQKAs+pR6QgoZmg$QCYW/9SYQinzIijmXwVv5zPrjmkdvqYVK66lkev1p3g	t	active	fr	\N	2026-08-18 15:10:00.309	2026-08-28 01:46:08.145	cmsyju7wa0000icdyjw9azk4t	\N
cmu2hu13j00017jqju6dvmafp	TestNom	TestPrenom	test_banal_1789465966@kwismo-test.org	$argon2id$v=19$m=65536,t=3,p=4$t3p4uI1f+cm1mEVIeXH/wQ$KBzrJRrdJAC/z1+09tiGg5wWXT8VDS+VM6XUttoKsDY	f	active	fr	\N	2026-09-15 09:52:47.117	2026-09-15 09:52:47.117	cmsyju7wa0000icdyjw9azk4t	\N
cmu2huz1600077jqj8pwg0rg9	Weko	Brayan	user_banal_1789466010@kwismo-test.org	$argon2id$v=19$m=65536,t=3,p=4$C4PkyX4cI/d5OLBoCWP19g$aVpgckdDaP1TCEUFaNMUvyDQzw0PSN9RneLv7tICI9M	f	active	fr	\N	2026-09-15 09:53:31.098	2026-09-15 09:53:31.098	cmsyju7wa0000icdyjw9azk4t	\N
cmu2hvioj000b7jqjeazowfy5	Weko	Brayan	user_banal_1789466036@kwismo-test.org	$argon2id$v=19$m=65536,t=3,p=4$syHCEM6ItsA+PYB4zBKA5g$oQ6oRfX3GGkl+oPIDrOQAq3S3q1OeOCWkkWaxCVtJxM	f	active	fr	\N	2026-09-15 09:53:56.563	2026-09-15 09:53:56.563	cmsyju7wa0000icdyjw9azk4t	\N
cmu2hxx05000f7jqjb0yx35uy	Weko	Brayan	user_banal_1789466148@kwismo-test.org	$argon2id$v=19$m=65536,t=3,p=4$GztxBu0GlceOD3VewjUSFw$j30aZG5Kn6NpWoq9jlBUAdRj88dZSO7mmw0W31lIg9A	f	active	fr	\N	2026-09-15 09:55:48.437	2026-09-15 09:55:48.437	cmsyju7wa0000icdyjw9azk4t	\N
cmu2hygl6000j7jqjqx6z1wzb	Weko	Brayan	user_banal_1789466173@kwismo-test.org	$argon2id$v=19$m=65536,t=3,p=4$ha4A9zmNWtN/teLulwYpDg$Idr5YVAWeHmXQ9qOEU3c6OsMl1beGFKN9E0UEfJaoxU	t	active	fr	\N	2026-09-15 09:56:13.817	2026-09-15 09:56:16.809	cmsyju7wa0000icdyjw9azk4t	\N
cmu2ivveg0001z8ddgxkvkvbc	Weko	Brayan	wekobrayan163@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$1CwnY//3ljmxnuTLk53RWA$yhSmp5vkIPyQetIhGTkktVoRedKQnHjFHTmZqp4FJBI	t	active	fr	\N	2026-09-15 10:22:12.661	2026-09-21 08:59:33.066	cmsyju7wa0000icdyjw9azk4t	\N
cmu2kbv5100015t7muyukztzb	Lelouch	Loyd	lelouchloyd@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$BHUqkWEj5Z1klIaewOb6DA$r/q3OAWI1QsylI5RUwqCnPfmvtyj+53ES/Ouf4zkBZ8	f	active	fr	\N	2026-09-15 11:02:38.434	2026-09-15 11:02:38.434	cmsyju7wa0000icdyjw9azk4t	\N
cmu2kzqeu00055t7mrgmescc1	Newton	Achonduh	newtonachonduh46@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$7BeC4OHeND2o+nFzp0qarw$V2x24JHnMbP1j1Hv1E0Q+2BGBn3141wheN8L9T0yLMA	t	active	en	\N	2026-09-15 11:21:12.05	2026-09-21 16:32:41.437	cmsyju7wa0000icdyjw9azk4t	\N
cmu2lij8x000110iykz2s5bsp	TestUpdated	UserUpdated	unverified_f8ecd9a9@example.com	$argon2id$v=19$m=65536,t=3,p=4$pDVUGbS5ieI2qNOPxqoH6g$F+yZzB8CFyN9IPVbHTxguQjR1+QMWqLu+X/jocbh51Y	t	active	fr	\N	2026-09-15 11:35:49.231	2026-09-15 11:36:02.504	cmsyju7wa0000icdyjw9azk4t	\N
\.


--
-- Data for Name: UserPhone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UserPhone" (id, "userId", valeur, "countryId", "operatorId", "numeroId", "estVerifie", "dateVerification", "estCompromis", "createdAt", "updatedAt") FROM stdin;
cmsysvmv1003hytq2tnxjycxx	cmsyslwua0003vlwm8lrfk563	+237670000001	cmsyju7x40003icdyzt0zq5jx	cmsysr3sa000eshwv3qubm6ec	cmsysulq50000laffaeyp1zo5	t	\N	t	2026-08-18 15:11:10.717	2026-08-19 05:03:27.56
cmsysvmvs003iytq2sa8gtvbq	cmsysr3ck0003shwv6ahorru0	+237690000002	cmsyju7x40003icdyzt0zq5jx	cmsysr40h0012shwvm0evxmy8	cmsysvmrn003cytq2lhfp9o5n	t	\N	f	2026-08-18 15:11:10.744	2026-08-18 15:11:10.744
cmsznu92p003hyqsv05am3gys	cmsyslwua0003vlwm8lrfk563	+237637281760	cmsyju7x40003icdyzt0zq5jx	\N	\N	f	\N	f	2026-08-19 05:37:54.289	2026-08-19 05:37:54.289
cmszo5cdy003h13adgwjrr53w	cmsyslwua0003vlwm8lrfk563	+237623162642	cmsyju7x40003icdyzt0zq5jx	cmsysr47w001oshwvguhqiu7q	\N	f	\N	f	2026-08-19 05:46:31.799	2026-08-19 05:46:31.799
cmszob42f003hw9rbtyc9kqg5	cmsyslwua0003vlwm8lrfk563	+237635268411	cmsyju7x40003icdyzt0zq5jx	\N	\N	f	\N	f	2026-08-19 05:51:00.952	2026-08-19 05:51:00.952
cmszopig8003hpn8cmhxatnyn	cmsyslwua0003vlwm8lrfk563	+237672039103	cmsyju7x40003icdyzt0zq5jx	cmsysr3sa000eshwv3qubm6ec	\N	f	\N	f	2026-08-19 06:02:12.776	2026-08-19 06:02:12.776
cmszox6e3003h39b4fiq8tewa	cmsyslwua0003vlwm8lrfk563	+237623359031	cmsyju7x40003icdyzt0zq5jx	cmsysr47w001oshwvguhqiu7q	\N	f	\N	f	2026-08-19 06:08:10.395	2026-08-19 06:08:10.395
cmszp3r1q003hworyw35amf8y	cmsyslwua0003vlwm8lrfk563	+237636842994	cmsyju7x40003icdyzt0zq5jx	\N	\N	f	\N	f	2026-08-19 06:13:17.102	2026-08-19 06:13:17.102
cmszpbcx6003hl94lfry59kun	cmsyslwua0003vlwm8lrfk563	+237679406486	cmsyju7x40003icdyzt0zq5jx	cmsysr3sa000eshwv3qubm6ec	\N	f	\N	f	2026-08-19 06:19:12.042	2026-08-19 06:19:12.042
cmsztfywo004hl94lsn6rqw5o	cmsyslwua0003vlwm8lrfk563	+237678619808	cmsyju7x40003icdyzt0zq5jx	cmsysr3sa000eshwv3qubm6ec	\N	f	\N	f	2026-08-19 08:14:45.624	2026-08-19 08:14:45.624
cmubgd5vm0005zs52w0hs36wh	cmu2kzqeu00055t7mrgmescc1	+237678688161	cmsyju7x40003icdyzt0zq5jx	cmsysr3sa000eshwv3qubm6ec	\N	t	2026-09-21 16:22:59.733	f	2026-09-21 16:21:36.129	2026-09-21 16:22:59.738
cmuv5b5qn00015ojb080h494o	cmu2ivveg0001z8ddgxkvkvbc	+237690374420	cmsyju7x40003icdyzt0zq5jx	cmsysr40h0012shwvm0evxmy8	\N	t	2026-10-05 11:08:21.879	f	2026-10-05 11:07:30.382	2026-10-05 11:08:21.885
\.


--
-- Data for Name: UssdAction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UssdAction" (id, "operatorId", "nomAction", "codeUSSD", format) FROM stdin;
cmsysr5ov005ishwvej6lambb	cmsysr3sa000eshwv3qubm6ec	Transfert Mobile Money	*126#	*126*1*{numero}*{montant}#
cmsysr5pn005kshwvk4x19qgt	cmsysr40h0012shwvm0evxmy8	Transfert Orange Money	#150#	#150*1*{numero}*{montant}#
cmsysr5qa005mshwvi4vt1zy2	cmsysr4a2001ushwvgyocad9e	Transfert Orange Money	#144#	#144*2*{numero}*{montant}#
cmsysr5r6005oshwvuh11njin	cmsysr4c60020shwvl2zsp0ls	Transfert Free Money	*555#	*555*1*{numero}*{montant}#
cmsysr5rx005qshwvwru8nf4x	cmsysr4fg0028shwvi9bgdp3z	Transfert Mobile Money	*133#	*133*1*{numero}*{montant}#
cmsysr5si005sshwvmav3a5oq	cmsysr4k7002kshwvekd2l9i7	Transfert Orange Money	#144#	#144*2*{numero}*{montant}#
cmsysr5t4005ushwv86rw52nv	cmsysr4nz002wshwvl0ux89vb	Transfert Flooz	*155#	*155*1*{numero}*{montant}#
cmsysr5tu005wshwv98cgk1cr	cmsysr4ru0038shwvgjchqlip	Transfert Mobile Money	*126#	*126*1*{numero}*{montant}#
cmsysr5uc005yshwvds50wv5r	cmsysr4ty003eshwvp099zzj5	Transfert Airtel Money	*500#	*500*1*{numero}*{montant}#
cmsysr5vc0060shwvx7x5307o	cmsysr4we003kshwvcjizd0tc	Transfert Airtel Money	*500#	*500*1*{numero}*{montant}#
cmsysr5w40062shwvxb31ycej	cmsysr4yf003qshwvcoe389c7	Transfert Moov Money	*155#	*155*1*{numero}*{montant}#
cmsysr5wr0064shwvsfj10z0i	cmsysr50w003wshwvacfukvrj	Transfert Orange Money	#144#	#144*2*{numero}*{montant}#
cmsysr5xn0066shwvfyn8hvri	cmsysr53e0042shwvtaoraf3q	Transfert Mobile Money	*126#	*126*1*{numero}*{montant}#
cmsysr5zg0068shwv0k10su0t	cmsysr55e0048shwv704rvx8u	Transfert Orange Money	#144#	#144*2*{numero}*{montant}#
cmsysr60u006ashwvcizbidra	cmsysr5aq004mshwvqd4wppll	Solde	*123#	*123#
cmsysr61v006cshwv55x3l8ox	cmsysr5fw0050shwveejqp9v1	Transfert Orange Money	#144#	#144*2*{numero}*{montant}#
cmsysr62g006eshwv59mo582m	cmsysr5lt005ashwvky63t94y	Transfert Flooz	*155#	*155*1*{numero}*{montant}#
cmsznsisg0039yqsvgr5wdrt5	cmsznsio0002fyqsvr6ws2a5r	Transfert Flooz	*155#	*155*1*{numero}*{montant}#
\.


--
-- Data for Name: WhatsAppAlert; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WhatsAppAlert" (id, "userId", "compromiseIncidentId", contenu, "dateEnvoi", statut) FROM stdin;
cmsztp38p005vl94ljmxuhvm2	cmsyslwua0003vlwm8lrfk563	cmszmlyds003za68336wc76ya	Compte WhatsApp compromis	2026-08-19 08:21:51.145	sent
cmsztsq6u003voqoewsxyuq96	cmsyslwua0003vlwm8lrfk563	cmszmlyds003za68336wc76ya	Compte WhatsApp compromis	2026-08-19 08:24:40.855	sent
cmszxk6v90051oqoetmbejg31	cmsyslwua0003vlwm8lrfk563	cmszmlyds003za68336wc76ya	Compte WhatsApp compromis	2026-08-19 10:10:01.029	sent
cmszxnrz1003v5rn2rqnaqzpt	cmsyslwua0003vlwm8lrfk563	cmszmlyds003za68336wc76ya	Compte WhatsApp compromis	2026-08-19 10:12:48.349	sent
cmszycnqc00515rn2kglinfdh	cmsyslwua0003vlwm8lrfk563	cmszmlyds003za68336wc76ya	Compte WhatsApp compromis	2026-08-19 10:32:09.252	sent
cmszymud6003vwb2vse8iid75	cmsyslwua0003vlwm8lrfk563	cmszmlyds003za68336wc76ya	Compte WhatsApp compromis	2026-08-19 10:40:04.41	sent
cmszyvp6v0053wb2vimaz59on	cmsyslwua0003vlwm8lrfk563	cmszmlyds003za68336wc76ya	Compte WhatsApp compromis	2026-08-19 10:46:57.608	sent
cmtcaiuqj006bwb2vr8qnx31w	cmsyslwua0003vlwm8lrfk563	cmszmlyds003za68336wc76ya	Compte WhatsApp compromis	2026-08-28 01:46:07.772	sent
\.


--
-- Data for Name: WhatsAppAlertRecipient; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WhatsAppAlertRecipient" (id, "whatsAppAlertId", "contactId", "statutAccuse") FROM stdin;
cmsztp38x005xl94l39a92cjn	cmsztp38p005vl94ljmxuhvm2	cmsztnhex005ll94l8j3etjbb	envoye
\.


--
-- Name: AccessRight AccessRight_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AccessRight"
    ADD CONSTRAINT "AccessRight_pkey" PRIMARY KEY (id);


--
-- Name: AffiliationRulePrefix AffiliationRulePrefix_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AffiliationRulePrefix"
    ADD CONSTRAINT "AffiliationRulePrefix_pkey" PRIMARY KEY (id);


--
-- Name: AffiliationRule AffiliationRule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AffiliationRule"
    ADD CONSTRAINT "AffiliationRule_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: CompromiseIncident CompromiseIncident_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CompromiseIncident"
    ADD CONSTRAINT "CompromiseIncident_pkey" PRIMARY KEY (id);


--
-- Name: Contact Contact_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contact"
    ADD CONSTRAINT "Contact_pkey" PRIMARY KEY (id);


--
-- Name: Country Country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Country"
    ADD CONSTRAINT "Country_pkey" PRIMARY KEY (id);


--
-- Name: Device Device_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Device"
    ADD CONSTRAINT "Device_pkey" PRIMARY KEY (id);


--
-- Name: Feedback Feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Feedback"
    ADD CONSTRAINT "Feedback_pkey" PRIMARY KEY (id);


--
-- Name: Kpi Kpi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Kpi"
    ADD CONSTRAINT "Kpi_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: Numero Numero_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Numero"
    ADD CONSTRAINT "Numero_pkey" PRIMARY KEY (id);


--
-- Name: OperatorPrefix OperatorPrefix_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OperatorPrefix"
    ADD CONSTRAINT "OperatorPrefix_pkey" PRIMARY KEY (id);


--
-- Name: Operator Operator_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Operator"
    ADD CONSTRAINT "Operator_pkey" PRIMARY KEY (id);


--
-- Name: OtpCode OtpCode_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OtpCode"
    ADD CONSTRAINT "OtpCode_pkey" PRIMARY KEY (id);


--
-- Name: PartnerRequest PartnerRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PartnerRequest"
    ADD CONSTRAINT "PartnerRequest_pkey" PRIMARY KEY (id);


--
-- Name: Partner Partner_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Partner"
    ADD CONSTRAINT "Partner_pkey" PRIMARY KEY (id);


--
-- Name: ReportCategory ReportCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ReportCategory"
    ADD CONSTRAINT "ReportCategory_pkey" PRIMARY KEY (id);


--
-- Name: Report Report_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_pkey" PRIMARY KEY (id);


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY (id);


--
-- Name: ScamCategory ScamCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ScamCategory"
    ADD CONSTRAINT "ScamCategory_pkey" PRIMARY KEY (id);


--
-- Name: SurveyResponse SurveyResponse_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyResponse"
    ADD CONSTRAINT "SurveyResponse_pkey" PRIMARY KEY (id);


--
-- Name: Survey Survey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Survey"
    ADD CONSTRAINT "Survey_pkey" PRIMARY KEY (id);


--
-- Name: Transaction Transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_pkey" PRIMARY KEY (id);


--
-- Name: UserPhone UserPhone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserPhone"
    ADD CONSTRAINT "UserPhone_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: UssdAction UssdAction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UssdAction"
    ADD CONSTRAINT "UssdAction_pkey" PRIMARY KEY (id);


--
-- Name: WhatsAppAlertRecipient WhatsAppAlertRecipient_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WhatsAppAlertRecipient"
    ADD CONSTRAINT "WhatsAppAlertRecipient_pkey" PRIMARY KEY (id);


--
-- Name: WhatsAppAlert WhatsAppAlert_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WhatsAppAlert"
    ADD CONSTRAINT "WhatsAppAlert_pkey" PRIMARY KEY (id);


--
-- Name: AccessRight_roleId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AccessRight_roleId_idx" ON public."AccessRight" USING btree ("roleId");


--
-- Name: AccessRight_roleId_permission_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "AccessRight_roleId_permission_key" ON public."AccessRight" USING btree ("roleId", permission);


--
-- Name: AffiliationRulePrefix_affiliationRuleId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AffiliationRulePrefix_affiliationRuleId_idx" ON public."AffiliationRulePrefix" USING btree ("affiliationRuleId");


--
-- Name: AffiliationRule_countryId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AffiliationRule_countryId_idx" ON public."AffiliationRule" USING btree ("countryId");


--
-- Name: AffiliationRule_partnerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AffiliationRule_partnerId_idx" ON public."AffiliationRule" USING btree ("partnerId");


--
-- Name: AuditLog_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_userId_idx" ON public."AuditLog" USING btree ("userId");


--
-- Name: CompromiseIncident_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CompromiseIncident_userId_idx" ON public."CompromiseIncident" USING btree ("userId");


--
-- Name: CompromiseIncident_userPhoneId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CompromiseIncident_userPhoneId_idx" ON public."CompromiseIncident" USING btree ("userPhoneId");


--
-- Name: Contact_numeroId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Contact_numeroId_idx" ON public."Contact" USING btree ("numeroId");


--
-- Name: Contact_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Contact_userId_idx" ON public."Contact" USING btree ("userId");


--
-- Name: Country_codePays_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Country_codePays_key" ON public."Country" USING btree ("codePays");


--
-- Name: Device_userId_identifiant_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Device_userId_identifiant_key" ON public."Device" USING btree ("userId", identifiant);


--
-- Name: Feedback_reportId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Feedback_reportId_idx" ON public."Feedback" USING btree ("reportId");


--
-- Name: Feedback_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Feedback_userId_idx" ON public."Feedback" USING btree ("userId");


--
-- Name: Kpi_partnerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Kpi_partnerId_idx" ON public."Kpi" USING btree ("partnerId");


--
-- Name: Notification_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Notification_userId_idx" ON public."Notification" USING btree ("userId");


--
-- Name: Numero_countryId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Numero_countryId_idx" ON public."Numero" USING btree ("countryId");


--
-- Name: Numero_operatorId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Numero_operatorId_idx" ON public."Numero" USING btree ("operatorId");


--
-- Name: Numero_valeur_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Numero_valeur_key" ON public."Numero" USING btree (valeur);


--
-- Name: OperatorPrefix_operatorId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OperatorPrefix_operatorId_idx" ON public."OperatorPrefix" USING btree ("operatorId");


--
-- Name: OperatorPrefix_operatorId_prefixe_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "OperatorPrefix_operatorId_prefixe_key" ON public."OperatorPrefix" USING btree ("operatorId", prefixe);


--
-- Name: Operator_countryId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Operator_countryId_idx" ON public."Operator" USING btree ("countryId");


--
-- Name: Operator_nom_countryId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Operator_nom_countryId_key" ON public."Operator" USING btree (nom, "countryId");


--
-- Name: OtpCode_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OtpCode_userId_idx" ON public."OtpCode" USING btree ("userId");


--
-- Name: OtpCode_userPhoneId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OtpCode_userPhoneId_idx" ON public."OtpCode" USING btree ("userPhoneId");


--
-- Name: ReportCategory_reportId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ReportCategory_reportId_idx" ON public."ReportCategory" USING btree ("reportId");


--
-- Name: ReportCategory_reportId_scamCategoryId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ReportCategory_reportId_scamCategoryId_key" ON public."ReportCategory" USING btree ("reportId", "scamCategoryId");


--
-- Name: ReportCategory_scamCategoryId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ReportCategory_scamCategoryId_idx" ON public."ReportCategory" USING btree ("scamCategoryId");


--
-- Name: Report_numeroId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Report_numeroId_idx" ON public."Report" USING btree ("numeroId");


--
-- Name: Report_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Report_userId_idx" ON public."Report" USING btree ("userId");


--
-- Name: Role_partnerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Role_partnerId_idx" ON public."Role" USING btree ("partnerId");


--
-- Name: ScamCategory_nomCode_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ScamCategory_nomCode_key" ON public."ScamCategory" USING btree ("nomCode");


--
-- Name: SurveyResponse_surveyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SurveyResponse_surveyId_idx" ON public."SurveyResponse" USING btree ("surveyId");


--
-- Name: SurveyResponse_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SurveyResponse_userId_idx" ON public."SurveyResponse" USING btree ("userId");


--
-- Name: SurveyResponse_userId_surveyId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SurveyResponse_userId_surveyId_key" ON public."SurveyResponse" USING btree ("userId", "surveyId");


--
-- Name: Transaction_numeroId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Transaction_numeroId_idx" ON public."Transaction" USING btree ("numeroId");


--
-- Name: Transaction_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Transaction_userId_idx" ON public."Transaction" USING btree ("userId");


--
-- Name: UserPhone_countryId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "UserPhone_countryId_idx" ON public."UserPhone" USING btree ("countryId");


--
-- Name: UserPhone_numeroId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "UserPhone_numeroId_idx" ON public."UserPhone" USING btree ("numeroId");


--
-- Name: UserPhone_operatorId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "UserPhone_operatorId_idx" ON public."UserPhone" USING btree ("operatorId");


--
-- Name: UserPhone_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "UserPhone_userId_idx" ON public."UserPhone" USING btree ("userId");


--
-- Name: UserPhone_valeur_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UserPhone_valeur_key" ON public."UserPhone" USING btree (valeur);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_partnerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_partnerId_idx" ON public."User" USING btree ("partnerId");


--
-- Name: User_roleId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_roleId_idx" ON public."User" USING btree ("roleId");


--
-- Name: UssdAction_operatorId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "UssdAction_operatorId_idx" ON public."UssdAction" USING btree ("operatorId");


--
-- Name: UssdAction_operatorId_nomAction_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UssdAction_operatorId_nomAction_key" ON public."UssdAction" USING btree ("operatorId", "nomAction");


--
-- Name: WhatsAppAlertRecipient_contactId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "WhatsAppAlertRecipient_contactId_idx" ON public."WhatsAppAlertRecipient" USING btree ("contactId");


--
-- Name: WhatsAppAlertRecipient_whatsAppAlertId_contactId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WhatsAppAlertRecipient_whatsAppAlertId_contactId_key" ON public."WhatsAppAlertRecipient" USING btree ("whatsAppAlertId", "contactId");


--
-- Name: WhatsAppAlertRecipient_whatsAppAlertId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "WhatsAppAlertRecipient_whatsAppAlertId_idx" ON public."WhatsAppAlertRecipient" USING btree ("whatsAppAlertId");


--
-- Name: WhatsAppAlert_compromiseIncidentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "WhatsAppAlert_compromiseIncidentId_idx" ON public."WhatsAppAlert" USING btree ("compromiseIncidentId");


--
-- Name: WhatsAppAlert_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "WhatsAppAlert_userId_idx" ON public."WhatsAppAlert" USING btree ("userId");


--
-- Name: AccessRight AccessRight_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AccessRight"
    ADD CONSTRAINT "AccessRight_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AffiliationRulePrefix AffiliationRulePrefix_affiliationRuleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AffiliationRulePrefix"
    ADD CONSTRAINT "AffiliationRulePrefix_affiliationRuleId_fkey" FOREIGN KEY ("affiliationRuleId") REFERENCES public."AffiliationRule"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AffiliationRule AffiliationRule_countryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AffiliationRule"
    ADD CONSTRAINT "AffiliationRule_countryId_fkey" FOREIGN KEY ("countryId") REFERENCES public."Country"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AffiliationRule AffiliationRule_partnerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AffiliationRule"
    ADD CONSTRAINT "AffiliationRule_partnerId_fkey" FOREIGN KEY ("partnerId") REFERENCES public."Partner"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CompromiseIncident CompromiseIncident_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CompromiseIncident"
    ADD CONSTRAINT "CompromiseIncident_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CompromiseIncident CompromiseIncident_userPhoneId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CompromiseIncident"
    ADD CONSTRAINT "CompromiseIncident_userPhoneId_fkey" FOREIGN KEY ("userPhoneId") REFERENCES public."UserPhone"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Contact Contact_numeroId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contact"
    ADD CONSTRAINT "Contact_numeroId_fkey" FOREIGN KEY ("numeroId") REFERENCES public."Numero"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Contact Contact_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contact"
    ADD CONSTRAINT "Contact_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Device Device_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Device"
    ADD CONSTRAINT "Device_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Feedback Feedback_reportId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Feedback"
    ADD CONSTRAINT "Feedback_reportId_fkey" FOREIGN KEY ("reportId") REFERENCES public."Report"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Feedback Feedback_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Feedback"
    ADD CONSTRAINT "Feedback_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Kpi Kpi_partnerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Kpi"
    ADD CONSTRAINT "Kpi_partnerId_fkey" FOREIGN KEY ("partnerId") REFERENCES public."Partner"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Notification Notification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Numero Numero_countryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Numero"
    ADD CONSTRAINT "Numero_countryId_fkey" FOREIGN KEY ("countryId") REFERENCES public."Country"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Numero Numero_operatorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Numero"
    ADD CONSTRAINT "Numero_operatorId_fkey" FOREIGN KEY ("operatorId") REFERENCES public."Operator"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: OperatorPrefix OperatorPrefix_operatorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OperatorPrefix"
    ADD CONSTRAINT "OperatorPrefix_operatorId_fkey" FOREIGN KEY ("operatorId") REFERENCES public."Operator"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Operator Operator_countryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Operator"
    ADD CONSTRAINT "Operator_countryId_fkey" FOREIGN KEY ("countryId") REFERENCES public."Country"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OtpCode OtpCode_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OtpCode"
    ADD CONSTRAINT "OtpCode_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OtpCode OtpCode_userPhoneId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OtpCode"
    ADD CONSTRAINT "OtpCode_userPhoneId_fkey" FOREIGN KEY ("userPhoneId") REFERENCES public."UserPhone"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ReportCategory ReportCategory_reportId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ReportCategory"
    ADD CONSTRAINT "ReportCategory_reportId_fkey" FOREIGN KEY ("reportId") REFERENCES public."Report"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ReportCategory ReportCategory_scamCategoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ReportCategory"
    ADD CONSTRAINT "ReportCategory_scamCategoryId_fkey" FOREIGN KEY ("scamCategoryId") REFERENCES public."ScamCategory"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Report Report_numeroId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_numeroId_fkey" FOREIGN KEY ("numeroId") REFERENCES public."Numero"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Report Report_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Role Role_partnerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_partnerId_fkey" FOREIGN KEY ("partnerId") REFERENCES public."Partner"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SurveyResponse SurveyResponse_surveyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyResponse"
    ADD CONSTRAINT "SurveyResponse_surveyId_fkey" FOREIGN KEY ("surveyId") REFERENCES public."Survey"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SurveyResponse SurveyResponse_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyResponse"
    ADD CONSTRAINT "SurveyResponse_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Transaction Transaction_countryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_countryId_fkey" FOREIGN KEY ("countryId") REFERENCES public."Country"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Transaction Transaction_numeroId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_numeroId_fkey" FOREIGN KEY ("numeroId") REFERENCES public."Numero"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Transaction Transaction_operatorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_operatorId_fkey" FOREIGN KEY ("operatorId") REFERENCES public."Operator"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Transaction Transaction_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Transaction Transaction_ussdActionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_ussdActionId_fkey" FOREIGN KEY ("ussdActionId") REFERENCES public."UssdAction"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserPhone UserPhone_countryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserPhone"
    ADD CONSTRAINT "UserPhone_countryId_fkey" FOREIGN KEY ("countryId") REFERENCES public."Country"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserPhone UserPhone_numeroId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserPhone"
    ADD CONSTRAINT "UserPhone_numeroId_fkey" FOREIGN KEY ("numeroId") REFERENCES public."Numero"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserPhone UserPhone_operatorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserPhone"
    ADD CONSTRAINT "UserPhone_operatorId_fkey" FOREIGN KEY ("operatorId") REFERENCES public."Operator"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserPhone UserPhone_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserPhone"
    ADD CONSTRAINT "UserPhone_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_partnerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_partnerId_fkey" FOREIGN KEY ("partnerId") REFERENCES public."Partner"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: User User_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UssdAction UssdAction_operatorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UssdAction"
    ADD CONSTRAINT "UssdAction_operatorId_fkey" FOREIGN KEY ("operatorId") REFERENCES public."Operator"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: WhatsAppAlertRecipient WhatsAppAlertRecipient_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WhatsAppAlertRecipient"
    ADD CONSTRAINT "WhatsAppAlertRecipient_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contact"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: WhatsAppAlertRecipient WhatsAppAlertRecipient_whatsAppAlertId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WhatsAppAlertRecipient"
    ADD CONSTRAINT "WhatsAppAlertRecipient_whatsAppAlertId_fkey" FOREIGN KEY ("whatsAppAlertId") REFERENCES public."WhatsAppAlert"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: WhatsAppAlert WhatsAppAlert_compromiseIncidentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WhatsAppAlert"
    ADD CONSTRAINT "WhatsAppAlert_compromiseIncidentId_fkey" FOREIGN KEY ("compromiseIncidentId") REFERENCES public."CompromiseIncident"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WhatsAppAlert WhatsAppAlert_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WhatsAppAlert"
    ADD CONSTRAINT "WhatsAppAlert_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict he6fz7xJkMlEfySvhBIFTCjfJArhdizPo6kEW5tRdrcG4if0ltvuiaEkuKhN2sp

